import React, { useState } from 'react';
import { 
  X, 
  Phone, 
  MapPin, 
  Mail, 
  Calendar, 
  Wrench, 
  User, 
  Laptop, 
  Printer, 
  MessageSquare, 
  Receipt,
  Edit3, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Plus,
  Send,
  DollarSign,
  ShieldCheck,
  Package
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus, ItemImage, GoogleDriveSettings } from '../types/workOrder';
import { formatCurrency, formatDateDisplay, getTodayDateStr } from '../services/storage';
import { getStatusBadgeConfig, getPriorityBadge } from './WorkOrderCard';
import { ImageAttachmentSection } from './ImageAttachmentSection';

interface WorkOrderDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder | null;
  onEdit: (order: WorkOrder) => void;
  onPrint: (order: WorkOrder) => void;
  onWhatsApp: (order: WorkOrder) => void;
  onSendBill: (order: WorkOrder) => void;
  onUpdateStatus: (id: string, status: WorkOrderStatus, note?: string) => void;
  onUpdateImages?: (id: string, images: ItemImage[]) => void;
  onDelete: (id: string) => void;
  googleDriveSettings?: GoogleDriveSettings;
  onOpenGoogleDriveSettings?: () => void;
}

export const WorkOrderDetailModal: React.FC<WorkOrderDetailModalProps> = ({
  isOpen,
  onClose,
  order,
  onEdit,
  onPrint,
  onWhatsApp,
  onSendBill,
  onUpdateStatus,
  onUpdateImages,
  onDelete,
  googleDriveSettings,
  onOpenGoogleDriveSettings
}) => {
  const [newNote, setNewNote] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<WorkOrderStatus>('pending');

  if (!isOpen || !order) return null;

  const statusCfg = getStatusBadgeConfig(order.status);
  const today = getTodayDateStr();
  const isOverdue = order.dueDate < today && order.status !== 'completed' && order.status !== 'delivered' && order.status !== 'cancelled';

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    onUpdateStatus(order.id, order.status, newNote.trim());
    setNewNote('');
  };

  const handleStatusChange = (newStatus: WorkOrderStatus) => {
    onUpdateStatus(order.id, newStatus, `Status changed to ${newStatus}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col max-h-[90vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-3">
            <span className="font-mono text-base font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-3 py-1 rounded-lg border border-blue-200 dark:border-blue-900/50">
              {order.orderNumber}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  {order.item.brand} {order.item.model}
                </h2>
                {getPriorityBadge(order.priority)}
                {isOverdue && (
                  <span className="text-[11px] font-semibold text-rose-600 bg-rose-50 dark:bg-rose-950 px-2 py-0.5 rounded">
                    Overdue
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Scheduled: {formatDateDisplay(order.scheduledDate)} · Due: {formatDateDisplay(order.dueDate)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSendBill(order)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 rounded-lg transition-colors border border-blue-200 dark:border-blue-900/60"
              title="Send digital bill copy via WhatsApp/Email/SMS"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Send Bill</span>
            </button>
            <button
              type="button"
              onClick={() => onEdit(order)}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="Edit Work Order"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onPrint(order)}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="Print Job Sheet / Tax Bill"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Status Quick Bar */}
          <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1">
                Current Pipeline Stage
              </span>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold px-3 py-1 rounded-full border ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}>
                  {statusCfg.label}
                </span>
                <span className="text-xs text-slate-500">
                  Assigned: <strong>{order.assignedTechnician}</strong>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Change Status:</span>
              <select
                value={order.status}
                onChange={(e) => handleStatusChange(e.target.value as WorkOrderStatus)}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500"
              >
                <option value="pending">Pending Intake</option>
                <option value="in_progress">In Progress</option>
                <option value="waiting_for_parts">Waiting for Parts</option>
                <option value="completed">Completed</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Customer & Asset Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Customer Box */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/50 space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-700/60">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  <span>Customer Contact</span>
                </div>
                <button
                  type="button"
                  onClick={() => onWhatsApp(order)}
                  className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                >
                  <MessageSquare className="w-3 h-3" />
                  <span>WhatsApp</span>
                </button>
              </div>

              <div className="text-sm font-bold text-slate-900 dark:text-white">
                {order.customer.name}
              </div>

              <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <a href={`tel:${order.customer.phone}`} className="font-mono hover:text-blue-600">
                    {order.customer.phone}
                  </a>
                  {order.customer.altPhone && (
                    <span className="text-slate-400 font-mono">(Alt: {order.customer.altPhone})</span>
                  )}
                </div>

                {order.customer.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>{order.customer.email}</span>
                  </div>
                )}

                <div className="flex items-start gap-2 pt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span>{order.customer.address}</span>
                </div>
              </div>
            </div>

            {/* Asset Box */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/50 space-y-2">
              <div className="pb-2 border-b border-slate-100 dark:border-slate-700/60 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                <Laptop className="w-3.5 h-3.5 text-blue-600" />
                <span>Equipment & Hardware</span>
              </div>

              <div className="text-sm font-bold text-slate-900 dark:text-white">
                {order.item.brand} {order.item.model}
              </div>

              <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                <div>Type: <span className="font-medium text-slate-800 dark:text-slate-200">{order.item.itemType}</span></div>
                <div>Serial Number: <span className="font-mono font-medium">{order.item.serialNumber || 'N/A'}</span></div>
                <div>Condition: <span>{order.item.cosmeticCondition || 'Normal wear'}</span></div>
                <div>
                  Accessories: <span className="text-slate-700 dark:text-slate-300">{order.item.accessoriesIncluded?.join(', ') || 'Device only'}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Diagnostic & Technical Overview */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/50 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 pb-1 border-b border-slate-100 dark:border-slate-700/60">
              Technical Assessment
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Reported Problem:
              </span>
              <p className="text-xs text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                {order.problemReported}
              </p>
            </div>

            {order.preliminaryDiagnosis && (
              <div>
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Preliminary Diagnosis:
                </span>
                <p className="text-xs text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                  {order.preliminaryDiagnosis}
                </p>
              </div>
            )}

            {order.partsRequired && (
              <div className="flex items-center gap-2 text-xs bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 p-2 rounded-lg border border-purple-200 dark:border-purple-900/50">
                <Package className="w-4 h-4 shrink-0" />
                <span>Required Replacement Part: <strong>{order.partsRequired}</strong></span>
              </div>
            )}
          </div>

          {/* Service Item Inspection & Repair Photos */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/50 space-y-3">
            <ImageAttachmentSection
              images={order.item.images || []}
              onChange={(newImages) => {
                if (onUpdateImages) {
                  onUpdateImages(order.id, newImages);
                }
              }}
              googleDriveSettings={googleDriveSettings}
              onOpenGoogleDriveSettings={onOpenGoogleDriveSettings}
            />
          </div>

          {/* Financial Breakdown */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Cost Ledger & Balance</span>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-400 block mb-1">Estimated Cost</span>
                <span className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums">
                  {formatCurrency(order.estimatedCost)}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-400 block mb-1">Advance Paid</span>
                <span className="font-mono text-base font-bold text-emerald-600 tabular-nums">
                  {formatCurrency(order.advancePaid)}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-400 block mb-1">Balance Due</span>
                <span className={`font-mono text-base font-bold tabular-nums ${order.balanceDue > 0 ? 'text-amber-600' : 'text-slate-500'}`}>
                  {formatCurrency(order.balanceDue)}
                </span>
              </div>
            </div>

            <div className="mt-3 text-xs text-slate-500 flex items-center justify-between">
              <span>Warranty: <strong>{order.warrantyPeriod || '30 Days Service Warranty'}</strong></span>
              {order.completedAt && (
                <span>Completed: {new Date(order.completedAt).toLocaleDateString()}</span>
              )}
            </div>
          </div>

          {/* Audit History & Activity Log */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span>Activity History & Bench Notes</span>
            </div>

            {/* Quick Note Add Form */}
            <form onSubmit={handleAddNote} className="flex gap-2 mb-4">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Log internal note or technician update..."
                className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
              <button
                type="submit"
                disabled={!newNote.trim()}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Note</span>
              </button>
            </form>

            {/* Timeline Entries */}
            <div className="space-y-2.5">
              {order.statusHistory && order.statusHistory.length > 0 ? (
                order.statusHistory.slice().reverse().map((entry, idx) => (
                  <div 
                    key={idx}
                    className="p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                  >
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {entry.updatedBy}
                      </span>
                      <span className="font-mono text-[11px]">
                        {new Date(entry.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200">
                      {entry.note}
                    </p>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-400 italic">
                  Order created on {new Date(order.createdAt).toLocaleDateString()}.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <button
            type="button"
            onClick={() => {
              if (confirm(`Are you sure you want to delete order ${order.orderNumber}?`)) {
                onDelete(order.id);
                onClose();
              }
            }}
            className="flex items-center gap-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Order</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSendBill(order)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Send Bill Copy</span>
            </button>
            <button
              type="button"
              onClick={() => onWhatsApp(order)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp Update</span>
            </button>
            <button
              type="button"
              onClick={() => onPrint(order)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Sheet</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
