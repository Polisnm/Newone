import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Upload, 
  Trash2, 
  Maximize2, 
  X, 
  Tag, 
  Plus, 
  Image as ImageIcon,
  FolderSync,
  ExternalLink
} from 'lucide-react';
import { ItemImage, GoogleDriveSettings } from '../types/workOrder';
import { compressAndReadImage } from '../utils/imageUtils';

interface ImageAttachmentSectionProps {
  images: ItemImage[];
  onChange: (images: ItemImage[]) => void;
  readOnly?: boolean;
  googleDriveSettings?: GoogleDriveSettings;
  onOpenGoogleDriveSettings?: () => void;
}

const STAGE_LABELS: Record<ItemImage['stage'], { label: string; bg: string; text: string }> = {
  intake: { label: 'Intake / Before', bg: 'bg-amber-100 dark:bg-amber-950/60', text: 'text-amber-800 dark:text-amber-300' },
  diagnosis: { label: 'Diagnostics', bg: 'bg-blue-100 dark:bg-blue-950/60', text: 'text-blue-800 dark:text-blue-300' },
  repair: { label: 'Bench Repair', bg: 'bg-purple-100 dark:bg-purple-950/60', text: 'text-purple-800 dark:text-purple-300' },
  completed: { label: 'Final / Completed', bg: 'bg-emerald-100 dark:bg-emerald-950/60', text: 'text-emerald-800 dark:text-emerald-300' }
};

export const ImageAttachmentSection: React.FC<ImageAttachmentSectionProps> = ({
  images = [],
  onChange,
  readOnly = false,
  googleDriveSettings,
  onOpenGoogleDriveSettings
}) => {
  const [selectedImageForLightbox, setSelectedImageForLightbox] = useState<ItemImage | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsUploading(true);

    try {
      const newImages: ItemImage[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith('image/')) continue;

        const compressedDataUrl = await compressAndReadImage(file);
        newImages.push({
          id: `img-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          url: compressedDataUrl,
          caption: file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
          stage: 'intake',
          createdAt: new Date().toISOString()
        });
      }

      if (newImages.length > 0) {
        onChange([...images, ...newImages]);
      }
    } catch (err) {
      console.error('Failed reading/compressing image:', err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (cameraInputRef.current) cameraInputRef.current.value = '';
    }
  };

  const handleRemoveImage = (id: string) => {
    onChange(images.filter(img => img.id !== id));
  };

  const handleUpdateCaption = (id: string, newCaption: string) => {
    onChange(images.map(img => img.id === id ? { ...img, caption: newCaption } : img));
  };

  const handleUpdateStage = (id: string, stage: ItemImage['stage']) => {
    onChange(images.map(img => img.id === id ? { ...img, stage } : img));
  };

  return (
    <div className="space-y-3">
      {/* Google Drive Link & Change Bar */}
      {googleDriveSettings && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 rounded-xl text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1 rounded-md bg-blue-600 text-white shrink-0">
              <FolderSync className="w-3.5 h-3.5" />
            </div>
            <div className="truncate">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mr-1.5">
                Google Drive Storage:
              </span>
              <span className="font-semibold text-slate-900 dark:text-white truncate">
                {googleDriveSettings.folderName}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {googleDriveSettings.folderUrl && (
              <a
                href={googleDriveSettings.folderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 flex items-center gap-1 font-medium"
              >
                <span>Open Folder</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}

            {onOpenGoogleDriveSettings && (
              <button
                type="button"
                onClick={onOpenGoogleDriveSettings}
                className="px-2.5 py-1 bg-white dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 rounded-md text-[11px] font-bold transition-colors shadow-2xs flex items-center gap-1"
              >
                <span>Change Google Drive</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Upload & Action Toolbar (when not read-only) */}
      {!readOnly && (
        <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/80">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block leading-tight">
                Equipment Photos & Inspection Images
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Attach damage photos, motherboard microscopy, serial labels or final testing
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Standard File Picker */}
            <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-2xs">
              <Upload className="w-3.5 h-3.5 text-blue-600" />
              <span>{isUploading ? 'Compressing...' : 'Upload Photos'}</span>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
                disabled={isUploading}
              />
            </label>

            {/* Mobile Camera Direct Capture */}
            <label className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-2xs">
              <Camera className="w-3.5 h-3.5" />
              <span>Take Photo</span>
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
                disabled={isUploading}
              />
            </label>
          </div>
        </div>
      )}

      {/* Images Grid */}
      {images.length === 0 ? (
        <div className="p-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-900/30 text-xs text-slate-400">
          <ImageIcon className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600 mb-2" />
          <p className="font-medium text-slate-600 dark:text-slate-400">No equipment photos attached yet</p>
          {!readOnly && (
            <p className="text-[11px] text-slate-400 mt-0.5">
              Click "Upload Photos" or "Take Photo" to document device condition and service progress.
            </p>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {images.map((img) => {
            const stageCfg = STAGE_LABELS[img.stage] || STAGE_LABELS.intake;

            return (
              <div
                key={img.id}
                className="group relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden shadow-2xs hover:shadow-xs transition-all flex flex-col"
              >
                {/* Image Container with Zoom Trigger */}
                <div 
                  className="relative h-40 bg-slate-950 flex items-center justify-center overflow-hidden cursor-pointer"
                  onClick={() => setSelectedImageForLightbox(img)}
                >
                  <img
                    src={img.url}
                    alt={img.caption || 'Service item'}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Stage Tag Overlay */}
                  <div className="absolute top-2 left-2 pointer-events-none">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded shadow-xs uppercase tracking-wider ${stageCfg.bg} ${stageCfg.text}`}>
                      {stageCfg.label}
                    </span>
                  </div>

                  {/* Zoom Overlay Icon */}
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="p-2 rounded-full bg-white/90 text-slate-900 shadow-md">
                      <Maximize2 className="w-4 h-4" />
                    </span>
                  </div>
                </div>

                {/* Card Details / Editable caption */}
                <div className="p-2.5 space-y-2 text-xs flex-1 flex flex-col justify-between">
                  {readOnly ? (
                    <div>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 line-clamp-2">
                        {img.caption || 'Equipment Photo'}
                      </p>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        {new Date(img.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  ) : (
                    <>
                      <input
                        type="text"
                        value={img.caption}
                        onChange={(e) => handleUpdateCaption(img.id, e.target.value)}
                        placeholder="Add descriptive photo note..."
                        className="w-full px-2 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                      />

                      <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-100 dark:border-slate-700/60">
                        {/* Stage Selector */}
                        <select
                          value={img.stage}
                          onChange={(e) => handleUpdateStage(img.id, e.target.value as any)}
                          className="text-[11px] font-medium px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                        >
                          <option value="intake">Intake / Before</option>
                          <option value="diagnosis">Diagnostics</option>
                          <option value="repair">Bench Repair</option>
                          <option value="completed">Completed / Final</option>
                        </select>

                        {/* Remove Image Button */}
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(img.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded transition-colors"
                          title="Delete photo"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Full-Screen Lightbox Modal */}
      {selectedImageForLightbox && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div 
            className="fixed inset-0" 
            onClick={() => setSelectedImageForLightbox(null)} 
          />
          <div className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center z-10">
            <button
              type="button"
              onClick={() => setSelectedImageForLightbox(null)}
              className="absolute -top-10 right-0 p-1.5 text-white/80 hover:text-white bg-slate-800/80 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={selectedImageForLightbox.url}
              alt={selectedImageForLightbox.caption}
              className="max-h-[75vh] w-auto max-w-full rounded-xl object-contain shadow-2xl border border-slate-800"
            />

            <div className="mt-3 text-center text-white">
              <p className="text-sm font-semibold">{selectedImageForLightbox.caption || 'Equipment Inspection Image'}</p>
              <div className="flex items-center justify-center gap-2 mt-1 text-xs text-slate-400">
                <span className="capitalize">{selectedImageForLightbox.stage} phase</span>
                <span>·</span>
                <span>{new Date(selectedImageForLightbox.createdAt).toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
