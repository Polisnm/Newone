import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wrench, 
  User, 
  Phone, 
  Laptop, 
  Calendar, 
  DollarSign, 
  ShieldCheck, 
  Check, 
  AlertCircle
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus, PriorityLevel, ItemType, ItemImage, GoogleDriveSettings } from '../types/workOrder';
import { StorageService, ACCESSORY_PRESETS, getTodayDateStr } from '../services/storage';
import { ImageAttachmentSection } from './ImageAttachmentSection';

interface WorkOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (order: WorkOrder) => void;
  orderToEdit?: WorkOrder | null;
  techniciansList: string[];
  defaultScheduledDate?: string;
  googleDriveSettings?: GoogleDriveSettings;
  onOpenGoogleDriveSettings?: () => void;
}

const ITEM_TYPES: ItemType[] = [
  'Laptop',
  'Desktop PC',
  'Motherboard / Logic Board',
  'Smartphone',
  'Tablet',
  'Printer / Scanner',
  'Audio / Console',
  'Network Equipment',
  'Other Equipment'
];

export const WorkOrderModal: React.FC<WorkOrderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  orderToEdit,
  techniciansList,
  defaultScheduledDate,
  googleDriveSettings,
  onOpenGoogleDriveSettings
}) => {
  const isEditing = Boolean(orderToEdit);

  // Form State
  const [orderNumber, setOrderNumber] = useState('');
  const [scheduledDate, setScheduledDate] = useState(defaultScheduledDate || getTodayDateStr());
  const [dueDate, setDueDate] = useState(getTodayDateStr());
  const [status, setStatus] = useState<WorkOrderStatus>('pending');
  const [priority, setPriority] = useState<PriorityLevel>('normal');

  // Customer
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAltPhone, setCustomerAltPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  // Item
  const [itemType, setItemType] = useState<ItemType>('Laptop');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [cosmeticCondition, setCosmeticCondition] = useState('');
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>([]);
  const [customAccessory, setCustomAccessory] = useState('');
  const [attachedImages, setAttachedImages] = useState<ItemImage[]>([]);

  // Repair & Notes
  const [problemReported, setProblemReported] = useState('');
  const [preliminaryDiagnosis, setPreliminaryDiagnosis] = useState('');
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [assignedTechnician, setAssignedTechnician] = useState(techniciansList[0] || 'Alex Rivera');
  const [partsRequired, setPartsRequired] = useState('');
  const [warrantyPeriod, setWarrantyPeriod] = useState('30 Days Service Warranty');

  // Costs
  const [estimatedCost, setEstimatedCost] = useState<number>(100);
  const [advancePaid, setAdvancePaid] = useState<number>(0);

  // Errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      if (orderToEdit) {
        setOrderNumber(orderToEdit.orderNumber);
        setScheduledDate(orderToEdit.scheduledDate);
        setDueDate(orderToEdit.dueDate);
        setStatus(orderToEdit.status);
        setPriority(orderToEdit.priority);

        setCustomerName(orderToEdit.customer.name);
        setCustomerPhone(orderToEdit.customer.phone);
        setCustomerAltPhone(orderToEdit.customer.altPhone || '');
        setCustomerEmail(orderToEdit.customer.email || '');
        setCustomerAddress(orderToEdit.customer.address);

        setItemType(orderToEdit.item.itemType);
        setBrand(orderToEdit.item.brand);
        setModel(orderToEdit.item.model);
        setSerialNumber(orderToEdit.item.serialNumber || '');
        setCosmeticCondition(orderToEdit.item.cosmeticCondition || '');
        setSelectedAccessories(orderToEdit.item.accessoriesIncluded || []);
        setAttachedImages(orderToEdit.item.images || []);

        setProblemReported(orderToEdit.problemReported);
        setPreliminaryDiagnosis(orderToEdit.preliminaryDiagnosis || '');
        setTechnicianNotes(orderToEdit.technicianNotes || '');
        setAssignedTechnician(orderToEdit.assignedTechnician);
        setPartsRequired(orderToEdit.partsRequired || '');
        setWarrantyPeriod(orderToEdit.warrantyPeriod || '30 Days Service Warranty');

        setEstimatedCost(orderToEdit.estimatedCost);
        setAdvancePaid(orderToEdit.advancePaid);
      } else {
        // New order
        setOrderNumber(StorageService.getNextOrderNumber());
        const today = defaultScheduledDate || getTodayDateStr();
        setScheduledDate(today);
        
        // Default due date to +2 days
        const d = new Date(today);
        d.setDate(d.getDate() + 2);
        setDueDate(d.toISOString().split('T')[0]);

        setStatus('pending');
        setPriority('normal');
        setCustomerName('');
        setCustomerPhone('');
        setCustomerAltPhone('');
        setCustomerEmail('');
        setCustomerAddress('');
        setItemType('Laptop');
        setBrand('');
        setModel('');
        setSerialNumber('');
        setCosmeticCondition('');
        setSelectedAccessories(['Original Charger / Power Adapter']);
        setAttachedImages([]);
        setProblemReported('');
        setPreliminaryDiagnosis('');
        setTechnicianNotes('');
        setAssignedTechnician(techniciansList[0] || 'Alex Rivera');
        setPartsRequired('');
        setWarrantyPeriod('30 Days Service Warranty');
        setEstimatedCost(120);
        setAdvancePaid(0);
      }
      setErrors({});
    }
  }, [isOpen, orderToEdit, defaultScheduledDate, techniciansList]);

  if (!isOpen) return null;

  const toggleAccessory = (acc: string) => {
    setSelectedAccessories(prev => 
      prev.includes(acc) ? prev.filter(a => a !== acc) : [...prev, acc]
    );
  };

  const handleAddCustomAccessory = () => {
    if (customAccessory.trim() && !selectedAccessories.includes(customAccessory.trim())) {
      setSelectedAccessories([...selectedAccessories, customAccessory.trim()]);
      setCustomAccessory('');
    }
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!customerName.trim()) errs.customerName = 'Customer name is required';
    if (!customerPhone.trim()) errs.customerPhone = 'Contact phone number is required';
    if (!customerAddress.trim()) errs.customerAddress = 'Address / location is required';
    if (!brand.trim()) errs.brand = 'Brand is required (e.g., Apple, Dell, Asus)';
    if (!model.trim()) errs.model = 'Model is required';
    if (!problemReported.trim()) errs.problemReported = 'Customer reported problem is required';
    if (!scheduledDate) errs.scheduledDate = 'Scheduled date is required';
    if (!dueDate) errs.dueDate = 'Due date is required';
    if (estimatedCost < 0) errs.estimatedCost = 'Estimate must be greater or equal to 0';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const balanceDue = Math.max(0, estimatedCost - advancePaid);

    const workOrderData: WorkOrder = {
      id: orderToEdit ? orderToEdit.id : `wo-${Date.now()}`,
      orderNumber,
      scheduledDate,
      dueDate,
      createdAt: orderToEdit ? orderToEdit.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status,
      priority,
      customer: {
        name: customerName.trim(),
        phone: customerPhone.trim(),
        altPhone: customerAltPhone.trim() || undefined,
        email: customerEmail.trim() || undefined,
        address: customerAddress.trim()
      },
      item: {
        itemType,
        brand: brand.trim(),
        model: model.trim(),
        serialNumber: serialNumber.trim(),
        cosmeticCondition: cosmeticCondition.trim() || undefined,
        accessoriesIncluded: selectedAccessories,
        images: attachedImages
      },
      problemReported: problemReported.trim(),
      preliminaryDiagnosis: preliminaryDiagnosis.trim(),
      technicianNotes: technicianNotes.trim(),
      assignedTechnician,
      estimatedCost: Number(estimatedCost),
      advancePaid: Number(advancePaid),
      balanceDue,
      partsRequired: partsRequired.trim() || undefined,
      warrantyPeriod: warrantyPeriod.trim(),
      statusHistory: orderToEdit ? orderToEdit.statusHistory : [
        {
          status,
          timestamp: new Date().toISOString(),
          note: 'Work order created in system.',
          updatedBy: 'Front Desk'
        }
      ]
    };

    onSave(workOrderData);
    onClose();
  };

  const calculatedBalance = Math.max(0, (estimatedCost || 0) - (advancePaid || 0));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div 
        className="fixed inset-0" 
        onClick={onClose}
      />
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-600 text-white">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
                {isEditing ? `Edit Work Order #${orderNumber}` : 'Create New Work Order'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isEditing ? 'Update service progress, notes, or customer intake parameters' : 'Record customer equipment intake, diagnostic notes, and financial deposit'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[78vh] overflow-y-auto">
          
          {/* Order Meta & Schedule */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                Order Ticket #
              </label>
              <input
                type="text"
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono font-bold bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-blue-600 dark:text-blue-400"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                Scheduled Date *
              </label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
                required
              />
              {errors.scheduledDate && <p className="text-[11px] text-rose-500 mt-0.5">{errors.scheduledDate}</p>}
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                Estimated Due Date *
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
                required
              />
              {errors.dueDate && <p className="text-[11px] text-rose-500 mt-0.5">{errors.dueDate}</p>}
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
              >
                <option value="low">Low Priority</option>
                <option value="normal">Normal</option>
                <option value="high">High Priority</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>

          {/* Section 1: Customer Details */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <User className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                1. Customer Details
              </h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Full Customer Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Johnathan Miller"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.customerName ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.customerName && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerName}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Primary Mobile Phone (WhatsApp) *
                </label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="e.g. +1 555-019-2834"
                  className={`w-full px-3 py-2 text-xs font-mono rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.customerPhone ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.customerPhone && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerPhone}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Alternative Contact / Landline (Optional)
                </label>
                <input
                  type="text"
                  value={customerAltPhone}
                  onChange={(e) => setCustomerAltPhone(e.target.value)}
                  placeholder="e.g. +1 555-019-2800"
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="e.g. client@company.com"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Physical Address / Location *
                </label>
                <input
                  type="text"
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="e.g. 542 Pine Street, Apt 3B, Downtown"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.customerAddress ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.customerAddress && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerAddress}</p>}
              </div>
            </div>
          </div>

          {/* Section 2: Item / Asset Details */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Laptop className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                2. Item & Asset Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Item Category *
                </label>
                <select
                  value={itemType}
                  onChange={(e) => setItemType(e.target.value as ItemType)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  {ITEM_TYPES.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Brand / Manufacturer *
                </label>
                <input
                  type="text"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="e.g. Apple, Dell, Lenovo"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.brand ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.brand && <p className="text-[11px] text-rose-500 mt-0.5">{errors.brand}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Model & Specs *
                </label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="e.g. MacBook Pro 14 M2, XPS 13"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.model ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.model && <p className="text-[11px] text-rose-500 mt-0.5">{errors.model}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Serial Number (S/N)
                </label>
                <input
                  type="text"
                  value={serialNumber}
                  onChange={(e) => setSerialNumber(e.target.value)}
                  placeholder="e.g. C02G99XZMD6R"
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Cosmetic Condition Inspection
                </label>
                <input
                  type="text"
                  value={cosmeticCondition}
                  onChange={(e) => setCosmeticCondition(e.target.value)}
                  placeholder="e.g. Minor scratches on base plate, screen glass intact"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            {/* Accessories Checkboxes */}
            <div className="mt-3">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1.5">
                Accessories Received at Intake:
              </label>
              <div className="flex flex-wrap gap-2">
                {ACCESSORY_PRESETS.map((acc) => {
                  const isChecked = selectedAccessories.includes(acc);
                  return (
                    <button
                      key={acc}
                      type="button"
                      onClick={() => toggleAccessory(acc)}
                      className={`text-xs px-2.5 py-1 rounded-md border flex items-center gap-1.5 transition-colors ${
                        isChecked 
                          ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 text-blue-700 dark:text-blue-300 font-medium' 
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <span className={`w-3.5 h-3.5 rounded flex items-center justify-center text-[10px] ${
                        isChecked ? 'bg-blue-600 text-white' : 'border border-slate-300 dark:border-slate-600'
                      }`}>
                        {isChecked && '✓'}
                      </span>
                      <span>{acc}</span>
                    </button>
                  );
                })}
              </div>

              {/* Custom Accessory Add */}
              <div className="flex gap-2 mt-2">
                <input
                  type="text"
                  value={customAccessory}
                  onChange={(e) => setCustomAccessory(e.target.value)}
                  placeholder="Add other accessory..."
                  className="px-2.5 py-1 text-xs rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 max-w-xs"
                />
                <button
                  type="button"
                  onClick={handleAddCustomAccessory}
                  className="px-2.5 py-1 text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-md font-medium"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Attached Service Items Photos */}
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
              <ImageAttachmentSection
                images={attachedImages}
                onChange={setAttachedImages}
                googleDriveSettings={googleDriveSettings}
                onOpenGoogleDriveSettings={onOpenGoogleDriveSettings}
              />
            </div>
          </div>

          {/* Section 3: Diagnostic & Technician Notes */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Wrench className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                3. Diagnostics, Technician & Status
              </h3>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  Customer Problem Description *
                </label>
                <textarea
                  rows={2}
                  value={problemReported}
                  onChange={(e) => setProblemReported(e.target.value)}
                  placeholder="Describe the exact symptoms reported by customer..."
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.problemReported ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.problemReported && <p className="text-[11px] text-rose-500 mt-0.5">{errors.problemReported}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Preliminary Diagnosis
                  </label>
                  <textarea
                    rows={2}
                    value={preliminaryDiagnosis}
                    onChange={(e) => setPreliminaryDiagnosis(e.target.value)}
                    placeholder="Initial technical assessment or bench findings..."
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Technician Work Notes
                  </label>
                  <textarea
                    rows={2}
                    value={technicianNotes}
                    onChange={(e) => setTechnicianNotes(e.target.value)}
                    placeholder="Internal bench notes, components checked, steps taken..."
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Assigned Technician
                  </label>
                  <select
                    value={assignedTechnician}
                    onChange={(e) => setAssignedTechnician(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  >
                    {techniciansList.map(tech => (
                      <option key={tech} value={tech}>{tech}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as WorkOrderStatus)}
                    className="w-full px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  >
                    <option value="pending">Pending Intake</option>
                    <option value="in_progress">In Progress</option>
                    <option value="waiting_for_parts">Waiting for Parts</option>
                    <option value="completed">Completed (Ready for Pickup)</option>
                    <option value="delivered">Delivered to Customer</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Replacement Parts Needed
                  </label>
                  <input
                    type="text"
                    value={partsRequired}
                    onChange={(e) => setPartsRequired(e.target.value)}
                    placeholder="e.g. OEM Battery #5XJ28"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 4: Costing & Payments */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2 mb-3">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                4. Financial Estimate & Deposit
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3.5 items-end">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Estimated Total ($)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={estimatedCost}
                  onChange={(e) => setEstimatedCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Advance Deposit Paid ($)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={advancePaid}
                  onChange={(e) => setAdvancePaid(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 tabular-nums"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                  Remaining Balance Due ($)
                </label>
                <div className={`px-3 py-2 text-sm font-mono font-bold rounded-lg border bg-slate-100 dark:bg-slate-800 tabular-nums ${
                  calculatedBalance > 0 ? 'text-amber-600 dark:text-amber-400 border-amber-300 dark:border-amber-900' : 'text-slate-500 border-slate-200 dark:border-slate-700'
                }`}>
                  ${calculatedBalance.toFixed(2)}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400 block mb-1">
                  Warranty Terms
                </label>
                <input
                  type="text"
                  value={warrantyPeriod}
                  onChange={(e) => setWarrantyPeriod(e.target.value)}
                  placeholder="e.g. 30 Days Warranty"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                />
              </div>
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{isEditing ? 'Save Changes' : 'Create Work Order'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
