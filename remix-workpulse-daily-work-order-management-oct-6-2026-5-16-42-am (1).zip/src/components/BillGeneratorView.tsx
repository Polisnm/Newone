import React, { useState, useEffect, useMemo } from 'react';
import { 
  Receipt, 
  Settings, 
  Plus, 
  Trash2, 
  Search, 
  Printer, 
  MessageSquare, 
  Mail, 
  Copy, 
  Check, 
  DollarSign, 
  Percent, 
  CreditCard, 
  User, 
  FileText, 
  Sparkles,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Download
} from 'lucide-react';
import { WorkOrder, BillModelConfig, BillLineItem } from '../types/workOrder';
import { formatCurrency, formatDateDisplay, getTodayDateStr } from '../services/storage';
import { cleanPhoneNumber, generateWhatsAppUrl } from '../utils/whatsapp';

interface BillGeneratorViewProps {
  orders: WorkOrder[];
  billConfig: BillModelConfig;
  onOpenBillConfig: () => void;
  onPrintInvoice: (order: WorkOrder) => void;
  onSendWhatsApp: (order: WorkOrder) => void;
}

export const BillGeneratorView: React.FC<BillGeneratorViewProps> = ({
  orders,
  billConfig,
  onOpenBillConfig,
  onPrintInvoice,
  onSendWhatsApp
}) => {
  // Selected order to bill
  const [selectedOrderId, setSelectedOrderId] = useState<string>(orders[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');

  // Bill Fields
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(getTodayDateStr());
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Credit/Debit Card' | 'Bank Transfer / Wire' | 'Online / UPI'>('Credit/Debit Card');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending' | 'partial'>('paid');
  const [discount, setDiscount] = useState<number>(0);
  const [customTaxRate, setCustomTaxRate] = useState<number>(billConfig.taxRatePercent);
  const [applyTax, setApplyTax] = useState<boolean>(billConfig.isTaxEnabled);
  const [notes, setNotes] = useState<string>(billConfig.footerNotes || '');

  // Line items
  const [lineItems, setLineItems] = useState<BillLineItem[]>([]);
  const [copied, setCopied] = useState(false);

  // Active selected order object
  const activeOrder = useMemo(() => {
    return orders.find(o => o.id === selectedOrderId) || null;
  }, [orders, selectedOrderId]);

  // When selected order changes, initialize line items
  useEffect(() => {
    if (activeOrder) {
      const digits = activeOrder.orderNumber.replace(/[^0-9]/g, '');
      setInvoiceNumber(`${billConfig.invoicePrefix || 'INV-'}${digits || '1001'}`);
      
      const laborEstimate = Math.max(0, activeOrder.estimatedCost * 0.6);
      const partsEstimate = Math.max(0, activeOrder.estimatedCost * 0.4);

      setLineItems([
        {
          id: 'item-1',
          description: `${activeOrder.item.brand} ${activeOrder.item.model} Service & Diagnostic Labor`,
          quantity: 1,
          unitPrice: Math.round(laborEstimate),
          total: Math.round(laborEstimate)
        },
        ...(partsEstimate > 0 ? [{
          id: 'item-2',
          description: activeOrder.partsRequired || 'Replacement Component & Bench Servicing',
          quantity: 1,
          unitPrice: Math.round(partsEstimate),
          total: Math.round(partsEstimate)
        }] : [])
      ]);

      setPaymentStatus(activeOrder.balanceDue <= 0 ? 'paid' : 'pending');
    }
  }, [activeOrder, billConfig.invoicePrefix]);

  // Financial calculations
  const subtotal = useMemo(() => {
    return lineItems.reduce((acc, item) => acc + (item.total || 0), 0);
  }, [lineItems]);

  const taxAmount = useMemo(() => {
    if (!applyTax) return 0;
    return (subtotal * customTaxRate) / 100;
  }, [subtotal, applyTax, customTaxRate]);

  const grandTotal = useMemo(() => {
    return Math.max(0, subtotal + taxAmount - Number(discount || 0));
  }, [subtotal, taxAmount, discount]);

  const advanceDeduction = activeOrder ? activeOrder.advancePaid : 0;
  const balanceDue = Math.max(0, grandTotal - advanceDeduction);

  // Line Item Handlers
  const handleItemChange = (id: string, field: 'description' | 'quantity' | 'unitPrice', val: any) => {
    setLineItems(prev => prev.map(item => {
      if (item.id !== id) return item;
      const updated = { ...item, [field]: val };
      if (field === 'quantity' || field === 'unitPrice') {
        const qty = field === 'quantity' ? Number(val) : item.quantity;
        const rate = field === 'unitPrice' ? Number(val) : item.unitPrice;
        updated.total = Math.max(0, qty * rate);
      }
      return updated;
    }));
  };

  const handleAddItem = () => {
    const newItem: BillLineItem = {
      id: `item-${Date.now()}`,
      description: 'Additional Service / Hardware Component',
      quantity: 1,
      unitPrice: 25,
      total: 25
    };
    setLineItems([...lineItems, newItem]);
  };

  const handleRemoveItem = (id: string) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter(item => item.id !== id));
    }
  };

  // Plaintext Bill Generator
  const generateBillText = (): string => {
    const custName = activeOrder?.customer.name || 'Walk-in Customer';
    const custPhone = activeOrder?.customer.phone || '';
    const itemDesc = activeOrder ? `${activeOrder.item.brand} ${activeOrder.item.model}` : 'Hardware Repair';

    return `========================================
TAX INVOICE & BILL COPY
${billConfig.shopName}
${billConfig.address}
Phone: ${billConfig.phone} · Email: ${billConfig.email}
${billConfig.taxRegistrationNumber ? `Tax ID: ${billConfig.taxRegistrationNumber}` : ''}
========================================
Invoice No:    ${invoiceNumber}
Date:          ${invoiceDate}
Work Order ID: ${activeOrder?.orderNumber || 'N/A'}
Payment State: ${paymentStatus === 'paid' ? '[PAID IN FULL]' : '[BALANCE PENDING]'}
Payment Mode:  ${paymentMethod}

BILLED TO:
Customer:      ${custName}
Phone:         ${custPhone}
Device:        ${itemDesc}

ITEMIZED BREAKDOWN:
${lineItems.map(item => `- ${item.description}: ${item.quantity}x @ ${billConfig.currencySymbol}${item.unitPrice.toFixed(2)} = ${billConfig.currencySymbol}${item.total.toFixed(2)}`).join('\n')}

Subtotal:      ${billConfig.currencySymbol}${subtotal.toFixed(2)}
${applyTax ? `${billConfig.taxLabel || 'Tax'}:          ${billConfig.currencySymbol}${taxAmount.toFixed(2)}` : ''}
Discount:      ${billConfig.currencySymbol}${Number(discount || 0).toFixed(2)}
Grand Total:   ${billConfig.currencySymbol}${grandTotal.toFixed(2)}
Advance Paid:  ${billConfig.currencySymbol}${advanceDeduction.toFixed(2)}
BALANCE DUE:   ${billConfig.currencySymbol}${balanceDue.toFixed(2)}

${billConfig.bankDetailsOrUPI ? `Payment Account: ${billConfig.bankDetailsOrUPI}` : ''}
Terms: ${billConfig.termsAndConditions}
========================================
${billConfig.footerNotes || 'Thank you for your business!'}`;
  };

  const handleCopyBill = () => {
    navigator.clipboard.writeText(generateBillText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsAppBill = () => {
    if (!activeOrder) return;
    const phone = cleanPhoneNumber(activeOrder.customer.phone);
    const message = generateBillText();
    const url = generateWhatsAppUrl(phone, message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleEmailBill = () => {
    if (!activeOrder?.customer.email) {
      alert('No customer email on file for this work order.');
      return;
    }
    const subject = encodeURIComponent(`Invoice ${invoiceNumber} - ${billConfig.shopName}`);
    const body = encodeURIComponent(generateBillText());
    window.location.href = `mailto:${activeOrder.customer.email}?subject=${subject}&body=${body}`;
  };

  // Filter orders for quick select
  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return orders;
    const q = searchQuery.toLowerCase();
    return orders.filter(o => 
      o.orderNumber.toLowerCase().includes(q) ||
      o.customer.name.toLowerCase().includes(q) ||
      o.customer.phone.toLowerCase().includes(q) ||
      o.item.brand.toLowerCase().includes(q)
    );
  }, [orders, searchQuery]);

  return (
    <div className="space-y-6">
      
      {/* Top Bar Header with Configure Bill Model button */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-600 text-white shadow-xs">
                <Receipt className="w-5 h-5" />
              </span>
              <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                Bill Generator & Invoicing Station
              </h1>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Create itemized repair bills, apply taxes & discounts, and send via WhatsApp, Email, or Print
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenBillConfig}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-900 rounded-xl transition-colors shadow-2xs"
            >
              <Settings className="w-4 h-4 text-blue-600" />
              <span>Configure Bill Model</span>
            </button>
          </div>
        </div>

        {/* Shop Branding Banner preview */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <div>
            Active Shop Model: <strong className="text-slate-800 dark:text-slate-200">{billConfig.shopName}</strong> · Tax: <strong>{billConfig.isTaxEnabled ? `${billConfig.taxLabel} (${billConfig.taxRatePercent}%)` : 'Disabled'}</strong> · Currency: <strong className="font-mono">{billConfig.currencySymbol} ({billConfig.currencyCode})</strong>
          </div>
          <button
            type="button"
            onClick={onOpenBillConfig}
            className="text-[11px] text-blue-600 hover:underline font-semibold"
          >
            Edit Shop Header, GSTIN & Terms
          </button>
        </div>
      </div>

      {/* Main 2-Column Workstation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Order Picker & Bill Builder (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Order Selector Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-blue-600" />
                <span>Select Work Order to Bill</span>
              </label>

              <div className="w-full sm:w-64">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search name, phone, order #..."
                  className="w-full px-2.5 py-1 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <select
              value={selectedOrderId}
              onChange={(e) => setSelectedOrderId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold"
            >
              {filteredOrders.map(order => (
                <option key={order.id} value={order.id}>
                  {order.orderNumber} — {order.customer.name} ({order.item.brand} {order.item.model}) — Due: {formatCurrency(order.balanceDue)}
                </option>
              ))}
            </select>

            {/* Quick Details of selected order */}
            {activeOrder && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Customer</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 truncate block">{activeOrder.customer.name}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Contact</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300 truncate block">{activeOrder.customer.phone}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Device</span>
                  <span className="text-slate-700 dark:text-slate-300 truncate block">{activeOrder.item.brand} {activeOrder.item.model}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Advance Recorded</span>
                  <span className="font-mono font-bold text-emerald-600 block">{formatCurrency(activeOrder.advancePaid)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Invoice Header Details */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Invoice Metadata & Payment Status
              </h2>
              <span className="text-[11px] font-mono text-slate-500">
                Prefix: {billConfig.invoicePrefix}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Invoice Number
                </label>
                <input
                  type="text"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Billing Date
                </label>
                <input
                  type="date"
                  value={invoiceDate}
                  onChange={(e) => setInvoiceDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Payment Mode
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold"
                >
                  <option value="Credit/Debit Card">Credit / Debit Card</option>
                  <option value="Cash">Cash</option>
                  <option value="Online / UPI">Online / UPI</option>
                  <option value="Bank Transfer / Wire">Bank Transfer / Wire</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Payment Status
                </label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as any)}
                  className={`w-full px-3 py-2 text-xs rounded-lg border font-bold ${
                    paymentStatus === 'paid'
                      ? 'border-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300'
                      : 'border-amber-300 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300'
                  }`}
                >
                  <option value="paid">Paid in Full</option>
                  <option value="partial">Partial Payment</option>
                  <option value="pending">Balance Pending</option>
                </select>
              </div>
            </div>
          </div>

          {/* Line Items Table Builder */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Itemized Services & Replacement Parts
                </h2>
                <span className="text-[11px] text-slate-500">
                  Add labor fees, components, and diagnostic items
                </span>
              </div>

              <button
                type="button"
                onClick={handleAddItem}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 rounded-lg text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Line Item</span>
              </button>
            </div>

            {/* Items Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 uppercase text-[10px]">
                    <th className="py-2 px-1">Description / Component</th>
                    <th className="py-2 px-2 w-20 text-center">Qty</th>
                    <th className="py-2 px-2 w-28 text-right">Rate ({billConfig.currencySymbol})</th>
                    <th className="py-2 px-2 w-28 text-right">Total</th>
                    <th className="py-2 px-1 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {lineItems.map((item) => (
                    <tr key={item.id} className="group">
                      <td className="py-2 px-1">
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                          placeholder="Service description..."
                          className="w-full px-2.5 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="number"
                          min="1"
                          max="99"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(item.id, 'quantity', e.target.value)}
                          className="w-full px-2 py-1.5 text-xs text-center font-mono rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(item.id, 'unitPrice', e.target.value)}
                          className="w-full px-2 py-1.5 text-xs text-right font-mono rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                        />
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {billConfig.currencySymbol}{item.total.toFixed(2)}
                      </td>
                      <td className="py-2 px-1 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          disabled={lineItems.length <= 1}
                          className="p-1 text-slate-400 hover:text-rose-600 disabled:opacity-30 rounded transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculations & Discounts */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between gap-4">
              <div className="space-y-2 max-w-sm">
                <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applyTax}
                    onChange={(e) => setApplyTax(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span>Apply {billConfig.taxLabel || 'Tax'} ({customTaxRate}%)</span>
                </label>

                {applyTax && (
                  <div className="flex items-center gap-2 pl-6">
                    <span className="text-[11px] text-slate-400">Override Tax Rate %:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={customTaxRate}
                      onChange={(e) => setCustomTaxRate(Number(e.target.value))}
                      className="w-20 px-2 py-0.5 text-xs font-mono rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800"
                    />
                  </div>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">Discount Amount ({billConfig.currencySymbol}):</span>
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={discount}
                    onChange={(e) => setDiscount(Number(e.target.value))}
                    className="w-24 px-2 py-1 text-xs font-mono rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800"
                  />
                </div>
              </div>

              {/* Totals Box */}
              <div className="w-full sm:w-64 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Subtotal:</span>
                  <span className="font-mono font-medium">{billConfig.currencySymbol}{subtotal.toFixed(2)}</span>
                </div>
                {applyTax && (
                  <div className="flex justify-between text-slate-500">
                    <span>{billConfig.taxLabel || 'Tax'} ({customTaxRate}%):</span>
                    <span className="font-mono font-medium">{billConfig.currencySymbol}{taxAmount.toFixed(2)}</span>
                  </div>
                )}
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Discount:</span>
                    <span className="font-mono">-{billConfig.currencySymbol}{Number(discount).toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-slate-900 dark:text-white pt-1.5 border-t border-slate-200 dark:border-slate-700 text-sm">
                  <span>Grand Total:</span>
                  <span className="font-mono">{billConfig.currencySymbol}{grandTotal.toFixed(2)}</span>
                </div>
                {advanceDeduction > 0 && (
                  <div className="flex justify-between text-slate-500 text-[11px] pt-1">
                    <span>Advance Paid:</span>
                    <span className="font-mono">-{billConfig.currencySymbol}{advanceDeduction.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-extrabold text-amber-600 pt-1 border-t border-slate-200 dark:border-slate-700 text-sm">
                  <span>Balance Due:</span>
                  <span className="font-mono">{billConfig.currencySymbol}{balanceDue.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Right Col: Live Bill Copy & Communication Dispatch */}
        <div className="space-y-5">
          
          {/* Dispatch Actions Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Send & Print Bill Copy</span>
            </h3>

            <div className="space-y-2">
              <button
                type="button"
                onClick={handleWhatsAppBill}
                className="w-full flex items-center justify-between px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span>Send Bill on WhatsApp</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => {
                  if (activeOrder) onPrintInvoice(activeOrder);
                }}
                className="w-full flex items-center justify-between px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                <div className="flex items-center gap-2">
                  <Printer className="w-4 h-4" />
                  <span>Print Tax Invoice & Receipt</span>
                </div>
                <span className="text-[10px] opacity-80 uppercase">{billConfig.layoutTheme}</span>
              </button>

              <button
                type="button"
                onClick={handleEmailBill}
                className="w-full flex items-center justify-between px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors border border-slate-200 dark:border-slate-700"
              >
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-600" />
                  <span>Email Invoice to Customer</span>
                </div>
              </button>

              <button
                type="button"
                onClick={handleCopyBill}
                className="w-full flex items-center justify-between px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors border border-slate-200 dark:border-slate-700"
              >
                <div className="flex items-center gap-2">
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
                  <span>{copied ? 'Copied to Clipboard!' : 'Copy Formatted Bill Text'}</span>
                </div>
              </button>
            </div>
          </div>

          {/* Formatted Text Preview */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Invoice Live Preview
              </span>
              <button
                type="button"
                onClick={onOpenBillConfig}
                className="text-[11px] text-blue-600 hover:underline flex items-center gap-1 font-semibold"
              >
                <Settings className="w-3 h-3" />
                <span>Template Settings</span>
              </button>
            </div>

            <pre className="p-3 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-300 font-mono text-[11px] rounded-xl overflow-x-auto max-h-96 whitespace-pre-wrap leading-relaxed border border-slate-100 dark:border-slate-800">
              {generateBillText()}
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
};
