import React from 'react';
import { 
  Phone, 
  MapPin, 
  Calendar, 
  User, 
  Wrench, 
  Printer, 
  MessageSquare, 
  Receipt,
  Camera,
  MoreVertical, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Package, 
  Edit3, 
  Trash2,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Send
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus, PriorityLevel } from '../types/workOrder';
import { formatCurrency, formatDateDisplay, getTodayDateStr } from '../services/storage';

interface WorkOrderCardProps {
  order: WorkOrder;
  onEdit: (order: WorkOrder) => void;
  onViewDetails: (order: WorkOrder) => void;
  onPrint: (order: WorkOrder) => void;
  onWhatsApp: (order: WorkOrder) => void;
  onSendBill: (order: WorkOrder) => void;
  onUpdateStatus: (id: string, status: WorkOrderStatus) => void;
  onDelete: (id: string) => void;
}

export const getStatusBadgeConfig = (status: WorkOrderStatus) => {
  switch (status) {
    case 'pending':
      return {
        label: 'Pending Intake',
        bg: 'bg-amber-50 dark:bg-amber-950/40',
        text: 'text-amber-700 dark:text-amber-400',
        border: 'border-amber-200 dark:border-amber-900/50',
        dot: 'bg-amber-500'
      };
    case 'in_progress':
      return {
        label: 'In Progress',
        bg: 'bg-blue-50 dark:bg-blue-950/40',
        text: 'text-blue-700 dark:text-blue-400',
        border: 'border-blue-200 dark:border-blue-900/50',
        dot: 'bg-blue-500'
      };
    case 'waiting_for_parts':
      return {
        label: 'Waiting Parts',
        bg: 'bg-purple-50 dark:bg-purple-950/40',
        text: 'text-purple-700 dark:text-purple-400',
        border: 'border-purple-200 dark:border-purple-900/50',
        dot: 'bg-purple-500'
      };
    case 'completed':
      return {
        label: 'Completed',
        bg: 'bg-emerald-50 dark:bg-emerald-950/40',
        text: 'text-emerald-700 dark:text-emerald-400',
        border: 'border-emerald-200 dark:border-emerald-900/50',
        dot: 'bg-emerald-500'
      };
    case 'delivered':
      return {
        label: 'Delivered',
        bg: 'bg-teal-50 dark:bg-teal-950/40',
        text: 'text-teal-700 dark:text-teal-400',
        border: 'border-teal-200 dark:border-teal-900/50',
        dot: 'bg-teal-500'
      };
    case 'cancelled':
      return {
        label: 'Cancelled',
        bg: 'bg-slate-100 dark:bg-slate-800',
        text: 'text-slate-600 dark:text-slate-400',
        border: 'border-slate-200 dark:border-slate-700',
        dot: 'bg-slate-400'
      };
  }
};

export const getPriorityBadge = (priority: PriorityLevel) => {
  switch (priority) {
    case 'urgent':
      return (
        <span className="text-[11px] font-semibold text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 px-2 py-0.5 rounded border border-rose-200 dark:border-rose-900/60">
          Urgent
        </span>
      );
    case 'high':
      return (
        <span className="text-[11px] font-semibold text-orange-700 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/50 px-2 py-0.5 rounded border border-orange-200 dark:border-orange-900/60">
          High
        </span>
      );
    case 'normal':
      return null;
    case 'low':
      return (
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
          Low
        </span>
      );
  }
};

export const WorkOrderCard: React.FC<WorkOrderCardProps> = ({
  order,
  onEdit,
  onViewDetails,
  onPrint,
  onWhatsApp,
  onSendBill,
  onUpdateStatus,
  onDelete
}) => {
  const statusCfg = getStatusBadgeConfig(order.status);
  const today = getTodayDateStr();
  const isOverdue = order.dueDate < today && order.status !== 'completed' && order.status !== 'delivered' && order.status !== 'cancelled';

  return (
    <div className={`bg-white dark:bg-slate-900 border rounded-xl shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden ${
      isOverdue 
        ? 'border-rose-300 dark:border-rose-900/60 ring-1 ring-rose-200/50 dark:ring-rose-900/30' 
        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
    }`}>
      
      {/* Top Card Header: WO Number, Status Badge, Due Date */}
      <div className="p-4 pb-3 border-b border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center justify-between gap-2 mb-2">
          
          {/* Order ID & Priority */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-bold tracking-tight text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/50 px-2 py-0.5 rounded-md border border-blue-200/60 dark:border-blue-900/40">
              {order.orderNumber}
            </span>
            {getPriorityBadge(order.priority)}
            {isOverdue && (
              <span className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-2 py-0.5 rounded flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Overdue
              </span>
            )}
          </div>

          {/* Status Badge Dropdown */}
          <div className="relative">
            <select
              value={order.status}
              onChange={(e) => onUpdateStatus(order.id, e.target.value as WorkOrderStatus)}
              className={`text-xs font-semibold px-2.5 py-1 rounded-full border cursor-pointer focus:outline-hidden focus:ring-1 focus:ring-blue-500 transition-colors ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}
            >
              <option value="pending">Pending Intake</option>
              <option value="in_progress">In Progress</option>
              <option value="waiting_for_parts">Waiting Parts</option>
              <option value="completed">Completed</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

        </div>

        {/* Device Information */}
        <div className="flex items-start justify-between gap-2 mt-2">
          <div>
            <h3 
              onClick={() => onViewDetails(order)}
              className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors leading-tight"
            >
              {order.item.brand} {order.item.model}
            </h3>
            <div className="flex flex-wrap items-center gap-x-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
              <span>{order.item.itemType}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-[11px]">S/N: {order.item.serialNumber || 'N/A'}</span>
              {order.item.images && order.item.images.length > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <button
                    type="button"
                    onClick={() => onViewDetails(order)}
                    className="inline-flex items-center gap-1 text-[11px] text-blue-600 dark:text-blue-400 font-semibold hover:underline"
                  >
                    <Camera className="w-3 h-3" />
                    <span>{order.item.images.length} photo{order.item.images.length > 1 ? 's' : ''}</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Card Body: Problem, Customer & Tech Details */}
      <div className="p-4 space-y-3 text-xs flex-1">
        
        {/* Reported Problem */}
        <div className="bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
            Problem Reported
          </span>
          <p className="text-slate-700 dark:text-slate-300 line-clamp-2 leading-relaxed">
            {order.problemReported}
          </p>
        </div>

        {/* Preliminary Diagnosis or Parts Note */}
        {order.preliminaryDiagnosis && (
          <div className="text-slate-600 dark:text-slate-400">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Diagnosis: </span>
            <span className="line-clamp-1">{order.preliminaryDiagnosis}</span>
          </div>
        )}

        {order.partsRequired && order.status === 'waiting_for_parts' && (
          <div className="flex items-center gap-1.5 text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/40 px-2 py-1 rounded">
            <Package className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate font-medium">Part: {order.partsRequired}</span>
          </div>
        )}

        {/* Customer & Location */}
        <div className="pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-slate-700 dark:text-slate-300">
          <div className="truncate pr-2">
            <span className="font-semibold text-slate-900 dark:text-slate-200 block truncate">
              {order.customer.name}
            </span>
            <span className="text-slate-400 dark:text-slate-500 text-[11px] truncate block">
              {order.customer.address}
            </span>
          </div>

          {/* Quick Call Phone */}
          <a
            href={`tel:${order.customer.phone}`}
            className="flex items-center gap-1 px-2 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/50 hover:text-blue-600 dark:hover:text-blue-400 text-slate-600 dark:text-slate-300 rounded-md transition-colors shrink-0"
            title={`Call ${order.customer.name}`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] font-medium hidden sm:inline">
              {order.customer.phone}
            </span>
          </a>
        </div>

        {/* Technician & Due Date */}
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] pt-1">
          <div className="flex items-center gap-1">
            <Wrench className="w-3 h-3 text-slate-400" />
            <span>Tech: <strong className="text-slate-700 dark:text-slate-200">{order.assignedTechnician}</strong></span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-slate-400" />
            <span>Due: <strong className={isOverdue ? 'text-rose-600 dark:text-rose-400' : 'text-slate-700 dark:text-slate-200'}>{order.dueDate}</strong></span>
          </div>
        </div>

        {/* Financial Breakdown */}
        <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-1 text-center bg-slate-50/70 dark:bg-slate-800/40 p-2 rounded-lg">
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 block uppercase">Estimate</span>
            <span className="font-mono text-xs font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
              {formatCurrency(order.estimatedCost)}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 block uppercase">Advance</span>
            <span className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
              {formatCurrency(order.advancePaid)}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 block uppercase">Balance</span>
            <span className={`font-mono text-xs font-bold tabular-nums ${
              order.balanceDue > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'
            }`}>
              {formatCurrency(order.balanceDue)}
            </span>
          </div>
        </div>

      </div>

      {/* Card Action Footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/70 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-1.5">
        
        {/* Quick WhatsApp Button */}
        <button
          type="button"
          onClick={() => onWhatsApp(order)}
          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          title="Send Status Update via WhatsApp"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>WhatsApp</span>
        </button>

        {/* Send Bill Copy Button */}
        <button
          type="button"
          onClick={() => onSendBill(order)}
          className="flex items-center justify-center gap-1 py-1.5 px-2.5 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/80 rounded-lg text-xs font-semibold transition-colors"
          title="Send Bill Copy to Customer (WhatsApp, Email, SMS)"
        >
          <Receipt className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span>Send Bill</span>
        </button>

        {/* Print Job Sheet Button */}
        <button
          type="button"
          onClick={() => onPrint(order)}
          className="p-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg transition-colors"
          title="Print Job Sheet / Receipt"
        >
          <Printer className="w-4 h-4" />
        </button>

        {/* Edit Button */}
        <button
          type="button"
          onClick={() => onEdit(order)}
          className="p-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg transition-colors"
          title="Edit Work Order"
        >
          <Edit3 className="w-4 h-4" />
        </button>

        {/* Inspect Details Button */}
        <button
          type="button"
          onClick={() => onViewDetails(order)}
          className="p-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg transition-colors"
          title="View Full Details & History"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

      </div>

    </div>
  );
};
