import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  FileText, 
  Receipt, 
  CheckCircle2, 
  Wrench, 
  Phone, 
  MapPin, 
  ShieldCheck,
  Calendar
} from 'lucide-react';
import { WorkOrder } from '../types/workOrder';
import { formatCurrency, formatDateDisplay } from '../services/storage';

interface PrintJobSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder | null;
  onOpenSendBill?: (order: WorkOrder) => void;
  initialLayout?: 'a4' | 'receipt' | 'invoice';
}

export const PrintJobSheetModal: React.FC<PrintJobSheetModalProps> = ({
  isOpen,
  onClose,
  order,
  onOpenSendBill,
  initialLayout = 'a4'
}) => {
  const [printLayout, setPrintLayout] = useState<'a4' | 'receipt' | 'invoice'>(initialLayout);

  React.useEffect(() => {
    if (isOpen && initialLayout) {
      setPrintLayout(initialLayout);
    }
  }, [isOpen, initialLayout]);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const invoiceNumber = `INV-${order.orderNumber.replace(/[^0-9]/g, '') || order.orderNumber}`;
  const isPaid = order.balanceDue <= 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0 no-print" onClick={onClose} />
      
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col max-h-[90vh]">
        
        {/* Header Controls (Hidden during browser print) */}
        <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-600 text-white">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {printLayout === 'invoice' ? 'Tax Invoice & Bill Copy' : 'Print Job Ticket & Receipt'} — {order.orderNumber}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Customer: {order.customer.name} · Device: {order.item.brand} {order.item.model}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Format Switcher */}
            <div className="flex bg-slate-200 dark:bg-slate-700 p-0.5 rounded-lg text-xs font-medium">
              <button
                type="button"
                onClick={() => setPrintLayout('a4')}
                className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-colors ${
                  printLayout === 'a4' 
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs' 
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Job Sheet</span>
              </button>
              <button
                type="button"
                onClick={() => setPrintLayout('invoice')}
                className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-colors ${
                  printLayout === 'invoice' 
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs' 
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Tax Invoice</span>
              </button>
              <button
                type="button"
                onClick={() => setPrintLayout('receipt')}
                className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-colors ${
                  printLayout === 'receipt' 
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs' 
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>80mm Slip</span>
              </button>
            </div>

            {/* Send Bill to Customer Button */}
            {onOpenSendBill && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenSendBill(order);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                title="Send digital bill copy via WhatsApp or Email"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Send Bill Copy</span>
              </button>
            )}

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Sheet Viewport */}
        <div className="p-6 overflow-y-auto bg-slate-100 dark:bg-slate-950 flex justify-center">
          
          {/* Layout 1: Tax Invoice & Bill Copy */}
          {printLayout === 'invoice' && (
            <div className="w-full max-w-[800px] bg-white text-slate-900 p-8 shadow-md border border-slate-200 print:border-none print:shadow-none print:p-0 rounded-lg print:rounded-none relative">
              
              {/* Payment Watermark Stamp */}
              <div className="absolute right-12 top-28 pointer-events-none select-none opacity-80">
                <div className={`border-4 font-mono font-black text-2xl uppercase px-4 py-1.5 rounded-lg rotate-[-12deg] tracking-widest ${
                  isPaid ? 'border-emerald-600 text-emerald-600' : 'border-amber-600 text-amber-600'
                }`}>
                  {isPaid ? 'PAID IN FULL' : 'BALANCE DUE'}
                </div>
              </div>

              {/* Top Header */}
              <div className="flex justify-between items-start border-b-2 border-slate-900 pb-5 mb-5">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 bg-slate-900 text-white rounded flex items-center justify-center font-bold text-sm">
                      WP
                    </div>
                    <span className="text-2xl font-black tracking-tight text-slate-900 uppercase">
                      WorkPulse Tech Care
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Workshop & Hardware Engineering Lab · Tax ID: WP-992-4819<br />
                    104 Industrial Parkway, Workshop Suite 4 · Tel: +1 (555) 019-9000<br />
                    Email: billing@workpulse-ops.com · Web: workpulse.internal
                  </p>
                </div>

                <div className="text-right">
                  <div className="text-xl font-black tracking-wider text-slate-900 uppercase">
                    TAX INVOICE
                  </div>
                  <div className="inline-block font-mono font-bold text-sm text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded mt-1 border border-blue-200">
                    {invoiceNumber}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-1">
                    Invoice Date: {new Date().toLocaleDateString()}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Order Ref: {order.orderNumber}
                  </div>
                </div>
              </div>

              {/* Billed To & Service Details */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-slate-50 p-4 rounded border border-slate-200 text-xs">
                  <span className="font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Billed To:
                  </span>
                  <div className="text-sm font-bold text-slate-900 mb-0.5">{order.customer.name}</div>
                  <div className="text-slate-700 font-mono">Phone: {order.customer.phone}</div>
                  {order.customer.email && <div className="text-slate-700">Email: {order.customer.email}</div>}
                  <div className="text-slate-600 mt-1">Address: {order.customer.address}</div>
                </div>

                <div className="bg-slate-50 p-4 rounded border border-slate-200 text-xs">
                  <span className="font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Equipment & Service Record:
                  </span>
                  <div><strong>Device:</strong> {order.item.brand} {order.item.model}</div>
                  <div><strong>Type:</strong> {order.item.itemType}</div>
                  <div className="font-mono"><strong>Serial No:</strong> {order.item.serialNumber || 'N/A'}</div>
                  <div><strong>Servicing Tech:</strong> {order.assignedTechnician}</div>
                  <div><strong>Warranty:</strong> {order.warrantyPeriod || '30 Days Service Warranty'}</div>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="mb-6">
                <table className="w-full text-xs border border-slate-200">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-semibold uppercase text-[11px]">
                      <th className="py-2 px-3 text-left w-12">#</th>
                      <th className="py-2 px-3 text-left">Service / Item Description</th>
                      <th className="py-2 px-3 text-center w-20">Qty</th>
                      <th className="py-2 px-3 text-right w-28">Rate</th>
                      <th className="py-2 px-3 text-right w-28">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="py-2.5 px-3 font-mono text-slate-500">1</td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900">Diagnostics & Precision Labor</div>
                        <div className="text-[11px] text-slate-600">{order.problemReported}</div>
                        {order.preliminaryDiagnosis && (
                          <div className="text-[11px] text-slate-500 italic mt-0.5">{order.preliminaryDiagnosis}</div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">1</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(order.estimatedCost * 0.6)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold">{formatCurrency(order.estimatedCost * 0.6)}</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-mono text-slate-500">2</td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900">Hardware Components & Consumables</div>
                        <div className="text-[11px] text-slate-600">
                          {order.partsRequired || 'Thermal compound, microsoldering solder/flux, and replacement modules'}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">1</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(order.estimatedCost * 0.4)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold">{formatCurrency(order.estimatedCost * 0.4)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Totals & Advance Table */}
              <div className="flex justify-end mb-6">
                <div className="w-80 text-xs space-y-1.5 border border-slate-200 p-3 rounded bg-slate-50">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal Charges:</span>
                    <span className="font-mono font-bold">{formatCurrency(order.estimatedCost)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Sales Tax (0%):</span>
                    <span className="font-mono">$0.00</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Advance Deposit Received:</span>
                    <span className="font-mono font-bold text-emerald-700">- {formatCurrency(order.advancePaid)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-300 pt-1.5 font-bold text-sm text-slate-900">
                    <span>BALANCE DUE:</span>
                    <span className="font-mono text-base text-blue-700">{formatCurrency(order.balanceDue)}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 pt-1">
                    Status: <span className="font-semibold">{isPaid ? 'PAID IN FULL' : 'PAYABLE UPON PICKUP'}</span>
                  </div>
                </div>
              </div>

              {/* Payment Details & Warranty */}
              <div className="text-[11px] text-slate-600 leading-relaxed border-t border-slate-200 pt-3 mb-6">
                <p><strong>Accepted Payment Methods:</strong> Cash Counter, Visa/MasterCard/Amex, Bank Wire Transfer, or Online Link.</p>
                <p><strong>Warranty Policy:</strong> {order.warrantyPeriod || '30 Days Service Warranty'}. Covers replaced components and labor. Physical/liquid damage voids warranty.</p>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-12 pt-4 border-t border-slate-300">
                <div>
                  <div className="border-b border-slate-400 h-8 mb-1"></div>
                  <div className="text-xs font-semibold text-slate-800">Customer Received & Verified</div>
                </div>
                <div>
                  <div className="border-b border-slate-400 h-8 mb-1"></div>
                  <div className="text-xs font-semibold text-slate-800">Authorized Workshop Signatory</div>
                </div>
              </div>

            </div>
          )}

          {/* Layout 2: A4 Standard Job Sheet */}
          {printLayout === 'a4' && (
            <div className="w-full max-w-[800px] bg-white text-slate-900 p-8 shadow-md border border-slate-200 print:border-none print:shadow-none print:p-0 rounded-lg print:rounded-none">
              
              {/* Top Workshop Header */}
              <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6 mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 bg-slate-900 text-white rounded flex items-center justify-center font-bold text-sm">
                      WP
                    </div>
                    <span className="text-2xl font-black tracking-tight text-slate-900 uppercase">
                      WorkPulse Tech Care
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Precision Electronics, Logic Board & Hardware Engineering<br />
                    104 Industrial Parkway, Workshop Suite 4 · Phone: +1 (555) 019-9000<br />
                    Email: support@workpulse-ops.com · Web: workpulse.internal
                  </p>
                </div>

                <div className="text-right">
                  <div className="inline-block bg-slate-900 text-white px-3 py-1 font-mono font-black text-lg tracking-wider rounded">
                    {order.orderNumber}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-1">
                    Created: {new Date(order.createdAt).toLocaleDateString()}
                  </div>
                  {/* Fake Barcode SVG visualization */}
                  <div className="mt-2 flex justify-end">
                    <svg className="w-36 h-8" viewBox="0 0 100 24" preserveAspectRatio="none">
                      <rect x="0" y="0" width="3" height="24" fill="#000" />
                      <rect x="5" y="0" width="2" height="24" fill="#000" />
                      <rect x="9" y="0" width="4" height="24" fill="#000" />
                      <rect x="15" y="0" width="1" height="24" fill="#000" />
                      <rect x="18" y="0" width="3" height="24" fill="#000" />
                      <rect x="23" y="0" width="5" height="24" fill="#000" />
                      <rect x="30" y="0" width="2" height="24" fill="#000" />
                      <rect x="34" y="0" width="4" height="24" fill="#000" />
                      <rect x="40" y="0" width="2" height="24" fill="#000" />
                      <rect x="44" y="0" width="1" height="24" fill="#000" />
                      <rect x="47" y="0" width="5" height="24" fill="#000" />
                      <rect x="54" y="0" width="3" height="24" fill="#000" />
                      <rect x="59" y="0" width="2" height="24" fill="#000" />
                      <rect x="63" y="0" width="4" height="24" fill="#000" />
                      <rect x="69" y="0" width="2" height="24" fill="#000" />
                      <rect x="73" y="0" width="3" height="24" fill="#000" />
                      <rect x="78" y="0" width="5" height="24" fill="#000" />
                      <rect x="85" y="0" width="2" height="24" fill="#000" />
                      <rect x="89" y="0" width="4" height="24" fill="#000" />
                      <rect x="95" y="0" width="3" height="24" fill="#000" />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Grid: Customer Info & Schedule */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-slate-50 p-4 rounded border border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Customer Information
                  </h3>
                  <div className="text-sm font-bold text-slate-900 mb-1">{order.customer.name}</div>
                  <div className="text-xs text-slate-700 font-mono mb-1">Phone: {order.customer.phone}</div>
                  {order.customer.altPhone && (
                    <div className="text-xs text-slate-700 font-mono mb-1">Alt: {order.customer.altPhone}</div>
                  )}
                  {order.customer.email && (
                    <div className="text-xs text-slate-700 mb-1">Email: {order.customer.email}</div>
                  )}
                  <div className="text-xs text-slate-600 mt-1">Address: {order.customer.address}</div>
                </div>

                <div className="bg-slate-50 p-4 rounded border border-slate-200">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Work Order Schedule & Technician
                  </h3>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 block">Scheduled Date:</span>
                      <span className="font-semibold">{formatDateDisplay(order.scheduledDate)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Estimated Due:</span>
                      <span className="font-semibold">{formatDateDisplay(order.dueDate)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Assigned Tech:</span>
                      <span className="font-semibold">{order.assignedTechnician}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Priority:</span>
                      <span className="font-semibold uppercase text-blue-700">{order.priority}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Device & Hardware Details */}
              <div className="mb-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Asset Details & Intake Inspection
                </h3>
                <table className="w-full text-xs border border-slate-200">
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="w-1/4 py-2 px-3 bg-slate-100 font-semibold text-slate-700">Device / Equipment:</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{order.item.brand} {order.item.model} ({order.item.itemType})</td>
                      <td className="w-1/4 py-2 px-3 bg-slate-100 font-semibold text-slate-700">Serial Number:</td>
                      <td className="py-2 px-3 font-mono">{order.item.serialNumber || 'N/A'}</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 bg-slate-100 font-semibold text-slate-700">Cosmetic Condition:</td>
                      <td colSpan={3} className="py-2 px-3 text-slate-700">{order.item.cosmeticCondition || 'Standard operational wear'}</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 bg-slate-100 font-semibold text-slate-700">Accessories Received:</td>
                      <td colSpan={3} className="py-2 px-3 text-slate-700">
                        {order.item.accessoriesIncluded && order.item.accessoriesIncluded.length > 0 
                          ? order.item.accessoriesIncluded.join(', ') 
                          : 'None (Device only)'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Problem Reported & Diagnosis */}
              <div className="mb-6 space-y-3">
                <div className="p-3 border border-slate-200 rounded">
                  <span className="text-xs font-bold uppercase text-slate-500 block mb-1">Customer Problem Description:</span>
                  <p className="text-xs text-slate-800 leading-relaxed">{order.problemReported}</p>
                </div>

                <div className="p-3 border border-slate-200 rounded bg-slate-50/50">
                  <span className="text-xs font-bold uppercase text-slate-500 block mb-1">Preliminary Diagnostics & Tech Bench Notes:</span>
                  <p className="text-xs text-slate-800 leading-relaxed">
                    {order.preliminaryDiagnosis || 'Undergoing hardware stress testing and diagnostics.'}
                  </p>
                  {order.technicianNotes && (
                    <p className="text-xs text-slate-600 mt-1 italic">
                      Notes: {order.technicianNotes}
                    </p>
                  )}
                </div>
              </div>

              {/* Attached Inspection & Service Photos */}
              {order.item.images && order.item.images.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Attached Inspection & Hardware Photos ({order.item.images.length})
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {order.item.images.map((img) => (
                      <div key={img.id} className="border border-slate-200 rounded p-1.5 bg-slate-50">
                        <img 
                          src={img.url} 
                          alt={img.caption} 
                          className="w-full h-24 object-cover rounded mb-1 bg-slate-900" 
                          referrerPolicy="no-referrer" 
                        />
                        <div className="text-[10px] font-semibold text-slate-800 truncate">{img.caption || 'Equipment photo'}</div>
                        <div className="text-[9px] text-slate-500 uppercase font-mono">{img.stage} phase</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Financial Breakdown Table */}
              <div className="mb-6">
                <table className="w-full text-xs border border-slate-200">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700">
                      <th className="py-2 px-3 text-left">Description</th>
                      <th className="py-2 px-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="py-2 px-3">Estimated Diagnostic & Repair Labor + Parts</td>
                      <td className="py-2 px-3 text-right font-mono font-bold">{formatCurrency(order.estimatedCost)}</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 text-emerald-700">Advance Deposit Received (Cash/Card)</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700">- {formatCurrency(order.advancePaid)}</td>
                    </tr>
                    <tr className="bg-slate-50 font-bold text-sm">
                      <td className="py-2 px-3">Total Balance Payable Upon Collection:</td>
                      <td className="py-2 px-3 text-right font-mono text-base">{formatCurrency(order.balanceDue)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Warranty & Terms */}
              <div className="text-[10px] text-slate-500 leading-relaxed border-t border-slate-200 pt-4 mb-6">
                <p className="font-semibold text-slate-700 mb-1">Terms of Service & Customer Acknowledgement:</p>
                <ol className="list-decimal pl-4 space-y-0.5">
                  <li>Data Safety: Customers are advised to backup all personal data prior to hardware service. Workshop is not liable for data loss during drive repair or OS reinstalls.</li>
                  <li>Unclaimed Equipment: Items not collected within 45 days of completion notification will incur storage fees or disposal in accordance with local commercial salvage laws.</li>
                  <li>Warranty: {order.warrantyPeriod || '30 days warranty on labor and replaced components'}. Warranty void if warranty sticker is broken or in cases of physical/liquid damage.</li>
                </ol>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-12 pt-6 border-t border-slate-300">
                <div>
                  <div className="border-b border-slate-400 h-10 mb-1"></div>
                  <div className="text-xs font-semibold text-slate-800">Customer Signature / Acknowledgment</div>
                  <div className="text-[10px] text-slate-400">Date: ________________________</div>
                </div>
                <div>
                  <div className="border-b border-slate-400 h-10 mb-1"></div>
                  <div className="text-xs font-semibold text-slate-800">Authorized Technician: {order.assignedTechnician}</div>
                  <div className="text-[10px] text-slate-400">WorkPulse Service Center</div>
                </div>
              </div>

            </div>
          )}

          {/* Layout 3: 80mm Counter Thermal Receipt */}
          {printLayout === 'receipt' && (
            <div className="w-[320px] bg-white text-slate-900 p-6 shadow-md border border-slate-200 font-mono text-xs leading-tight">
              <div className="text-center pb-3 border-b border-dashed border-slate-300 mb-3">
                <div className="font-black text-sm uppercase tracking-wider">WORKPULSE TECH CARE</div>
                <div className="text-[11px] text-slate-600 mt-1">104 Industrial Pkwy, Ste 4</div>
                <div className="text-[11px] text-slate-600">Tel: +1 (555) 019-9000</div>
                <div className="font-bold text-base mt-2">{order.orderNumber}</div>
                <div className="text-[10px] text-slate-500">{new Date(order.createdAt).toLocaleString()}</div>
              </div>

              <div className="pb-3 border-b border-dashed border-slate-300 mb-3 space-y-1">
                <div><strong>Customer:</strong> {order.customer.name}</div>
                <div><strong>Phone:</strong> {order.customer.phone}</div>
                <div><strong>Device:</strong> {order.item.brand} {order.item.model}</div>
                <div><strong>S/N:</strong> {order.item.serialNumber || 'N/A'}</div>
                <div><strong>Tech:</strong> {order.assignedTechnician}</div>
                <div><strong>Due Date:</strong> {order.dueDate}</div>
              </div>

              <div className="pb-3 border-b border-dashed border-slate-300 mb-3">
                <div className="font-bold mb-1">PROBLEM REPORTED:</div>
                <div className="text-[11px] text-slate-700">{order.problemReported}</div>
              </div>

              <div className="pb-3 border-b border-dashed border-slate-300 mb-3 space-y-1">
                <div className="flex justify-between">
                  <span>Estimate:</span>
                  <span>{formatCurrency(order.estimatedCost)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Advance Paid:</span>
                  <span>- {formatCurrency(order.advancePaid)}</span>
                </div>
                <div className="flex justify-between font-bold text-sm pt-1 border-t border-slate-200">
                  <span>BALANCE DUE:</span>
                  <span>{formatCurrency(order.balanceDue)}</span>
                </div>
              </div>

              <div className="text-[10px] text-center text-slate-500 space-y-1">
                <div>Present this slip for device collection.</div>
                <div>Warranty: {order.warrantyPeriod || '30 Days'}</div>
                <div className="pt-2 font-bold uppercase">Thank you for your business!</div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
