import React from 'react';
import { 
  ArrowRight, 
  MessageSquare, 
  Printer, 
  Receipt,
  Phone, 
  ChevronRight, 
  AlertCircle,
  Plus
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus } from '../types/workOrder';
import { formatCurrency, getTodayDateStr } from '../services/storage';
import { getPriorityBadge } from './WorkOrderCard';

interface KanbanBoardViewProps {
  orders: WorkOrder[];
  onEdit: (order: WorkOrder) => void;
  onViewDetails: (order: WorkOrder) => void;
  onPrint: (order: WorkOrder) => void;
  onWhatsApp: (order: WorkOrder) => void;
  onSendBill: (order: WorkOrder) => void;
  onUpdateStatus: (id: string, status: WorkOrderStatus) => void;
  onCreateNew: () => void;
}

interface ColumnDef {
  key: WorkOrderStatus;
  title: string;
  nextStatus?: WorkOrderStatus;
  nextLabel?: string;
  accentColor: string;
  badgeBg: string;
  badgeText: string;
}

const KANBAN_COLUMNS: ColumnDef[] = [
  {
    key: 'pending',
    title: 'Pending Intake',
    nextStatus: 'in_progress',
    nextLabel: 'Start Repair',
    accentColor: 'border-t-amber-500',
    badgeBg: 'bg-amber-100 dark:bg-amber-950/60',
    badgeText: 'text-amber-800 dark:text-amber-300'
  },
  {
    key: 'in_progress',
    title: 'In Progress',
    nextStatus: 'completed',
    nextLabel: 'Mark Done',
    accentColor: 'border-t-blue-500',
    badgeBg: 'bg-blue-100 dark:bg-blue-950/60',
    badgeText: 'text-blue-800 dark:text-blue-300'
  },
  {
    key: 'waiting_for_parts',
    title: 'Waiting for Parts',
    nextStatus: 'in_progress',
    nextLabel: 'Parts Received',
    accentColor: 'border-t-purple-500',
    badgeBg: 'bg-purple-100 dark:bg-purple-950/60',
    badgeText: 'text-purple-800 dark:text-purple-300'
  },
  {
    key: 'completed',
    title: 'Completed (Ready)',
    nextStatus: 'delivered',
    nextLabel: 'Handover / Deliver',
    accentColor: 'border-t-emerald-500',
    badgeBg: 'bg-emerald-100 dark:bg-emerald-950/60',
    badgeText: 'text-emerald-800 dark:text-emerald-300'
  },
  {
    key: 'delivered',
    title: 'Delivered / Closed',
    accentColor: 'border-t-teal-500',
    badgeBg: 'bg-teal-100 dark:bg-teal-950/60',
    badgeText: 'text-teal-800 dark:text-teal-300'
  }
];

export const KanbanBoardView: React.FC<KanbanBoardViewProps> = ({
  orders,
  onEdit,
  onViewDetails,
  onPrint,
  onWhatsApp,
  onSendBill,
  onUpdateStatus,
  onCreateNew
}) => {
  const today = getTodayDateStr();

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-4 min-w-[1100px] items-start">
        {KANBAN_COLUMNS.map((column) => {
          const colOrders = orders.filter(o => o.status === column.key);
          const colTotalBalance = colOrders.reduce((sum, o) => sum + o.balanceDue, 0);

          return (
            <div
              key={column.key}
              className={`flex-1 bg-slate-100/70 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col max-h-[820px] border-t-4 ${column.accentColor}`}
            >
              
              {/* Column Header */}
              <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                      {column.title}
                    </h3>
                    <span className={`text-[11px] font-mono tabular-nums px-2 py-0.5 rounded-full font-bold ${column.badgeBg} ${column.badgeText}`}>
                      {colOrders.length}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 dark:text-slate-500 font-mono tabular-nums mt-0.5">
                    Due: {formatCurrency(colTotalBalance)}
                  </div>
                </div>

                {column.key === 'pending' && (
                  <button
                    type="button"
                    onClick={onCreateNew}
                    className="p-1 text-blue-600 hover:text-blue-700 dark:text-blue-400 hover:bg-white dark:hover:bg-slate-800 rounded-md transition-colors"
                    title="Add new work order"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Cards Container */}
              <div className="p-2.5 space-y-2.5 overflow-y-auto flex-1">
                {colOrders.length === 0 ? (
                  <div className="py-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-400">
                    No orders in this stage
                  </div>
                ) : (
                  colOrders.map((order) => {
                    const isOverdue = order.dueDate < today && order.status !== 'completed' && order.status !== 'delivered' && order.status !== 'cancelled';

                    return (
                      <div
                        key={order.id}
                        className={`bg-white dark:bg-slate-800 border rounded-lg p-3 shadow-2xs hover:shadow-xs transition-all space-y-2.5 ${
                          isOverdue 
                            ? 'border-rose-300 dark:border-rose-900/60' 
                            : 'border-slate-200/90 dark:border-slate-700/80 hover:border-blue-400 dark:hover:border-blue-500'
                        }`}
                      >
                        {/* Order Header */}
                        <div className="flex items-center justify-between">
                          <button
                            type="button"
                            onClick={() => onViewDetails(order)}
                            className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                          >
                            {order.orderNumber}
                          </button>
                          <div className="flex items-center gap-1">
                            {getPriorityBadge(order.priority)}
                            {isOverdue && (
                              <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                <AlertCircle className="w-2.5 h-2.5" />
                                Overdue
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Device & Customer */}
                        <div>
                          <h4 
                            onClick={() => onViewDetails(order)}
                            className="text-xs font-bold text-slate-900 dark:text-slate-100 hover:text-blue-600 cursor-pointer line-clamp-1"
                          >
                            {order.item.brand} {order.item.model}
                          </h4>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {order.customer.name} · <span className="font-mono">{order.customer.phone}</span>
                          </div>
                        </div>

                        {/* Problem snippet */}
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2 bg-slate-50 dark:bg-slate-900/40 p-1.5 rounded">
                          {order.problemReported}
                        </p>

                        {/* Tech & Balance */}
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 dark:border-slate-700/60">
                          <span className="text-slate-500 dark:text-slate-400">
                            {order.assignedTechnician}
                          </span>
                          <span className={`font-mono font-bold tabular-nums ${order.balanceDue > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600'}`}>
                            Due: {formatCurrency(order.balanceDue)}
                          </span>
                        </div>

                        {/* Actions Toolbar */}
                        <div className="flex items-center justify-between gap-1 pt-1">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => onWhatsApp(order)}
                              title="WhatsApp Customer"
                              className="p-1 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onSendBill(order)}
                              title="Send Bill Copy"
                              className="p-1 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded transition-colors"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onPrint(order)}
                              title="Print Job Sheet / Bill"
                              className="p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded transition-colors"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={`tel:${order.customer.phone}`}
                              title="Call Customer"
                              className="p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded transition-colors"
                            >
                              <Phone className="w-3.5 h-3.5" />
                            </a>
                          </div>

                          {/* Quick Move to Next Stage */}
                          {column.nextStatus && (
                            <button
                              type="button"
                              onClick={() => onUpdateStatus(order.id, column.nextStatus!)}
                              className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 px-2 py-1 rounded transition-colors"
                            >
                              <span>{column.nextLabel}</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                      </div>
                    );
                  })
                )}
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
};
