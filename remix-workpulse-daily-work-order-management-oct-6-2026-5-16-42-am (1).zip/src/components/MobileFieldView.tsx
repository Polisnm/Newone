import React from 'react';
import { 
  Phone, 
  MessageSquare, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  Wrench, 
  Printer, 
  Receipt,
  AlertCircle,
  Package,
  ArrowRight,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus } from '../types/workOrder';
import { formatCurrency, getTodayDateStr } from '../services/storage';
import { getStatusBadgeConfig, getPriorityBadge } from './WorkOrderCard';

interface MobileFieldViewProps {
  orders: WorkOrder[];
  onEdit: (order: WorkOrder) => void;
  onViewDetails: (order: WorkOrder) => void;
  onPrint: (order: WorkOrder) => void;
  onWhatsApp: (order: WorkOrder) => void;
  onSendBill: (order: WorkOrder) => void;
  onUpdateStatus: (id: string, status: WorkOrderStatus) => void;
  onCreateNew: () => void;
}

export const MobileFieldView: React.FC<MobileFieldViewProps> = ({
  orders,
  onEdit,
  onViewDetails,
  onPrint,
  onWhatsApp,
  onSendBill,
  onUpdateStatus,
  onCreateNew
}) => {
  const today = getTodayDateStr();

  if (orders.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center">
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
          No work orders in current view
        </p>
        <button
          type="button"
          onClick={onCreateNew}
          className="mt-3 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-xs font-semibold"
        >
          Create New Order
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-lg mx-auto">
      {orders.map((order) => {
        const statusCfg = getStatusBadgeConfig(order.status);
        const isOverdue = order.dueDate < today && order.status !== 'completed' && order.status !== 'delivered' && order.status !== 'cancelled';

        return (
          <div
            key={order.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden"
          >
            {/* Header: Order ID & Status */}
            <div className="p-4 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-md">
                  {order.orderNumber}
                </span>
                {getPriorityBadge(order.priority)}
                {isOverdue && (
                  <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400 flex items-center gap-0.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Overdue
                  </span>
                )}
              </div>

              {/* Status Select */}
              <select
                value={order.status}
                onChange={(e) => onUpdateStatus(order.id, e.target.value as WorkOrderStatus)}
                className={`text-xs font-semibold px-2.5 py-1.5 rounded-full border ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}
              >
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="waiting_for_parts">Waiting Parts</option>
                <option value="completed">Completed</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            {/* Device & Customer Details */}
            <div className="p-4 space-y-3">
              <div>
                <h3 
                  onClick={() => onViewDetails(order)}
                  className="text-base font-bold text-slate-900 dark:text-slate-100 leading-tight"
                >
                  {order.item.brand} {order.item.model}
                </h3>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {order.item.itemType} · <span className="font-mono">S/N: {order.item.serialNumber || 'N/A'}</span>
                </div>
              </div>

              {/* Customer Box */}
              <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="font-semibold text-slate-900 dark:text-slate-200 text-sm">
                  {order.customer.name}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{order.customer.address}</span>
                </div>
              </div>

              {/* Reported Problem */}
              <div className="text-xs text-slate-700 dark:text-slate-300">
                <span className="font-semibold block text-slate-500 dark:text-slate-400 mb-0.5">
                  Problem:
                </span>
                <p className="line-clamp-2 leading-relaxed bg-slate-50/60 dark:bg-slate-800/30 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                  {order.problemReported}
                </p>
              </div>

              {/* Balance & Assigned */}
              <div className="flex items-center justify-between text-xs pt-1">
                <div className="text-slate-500 dark:text-slate-400">
                  Tech: <strong className="text-slate-800 dark:text-slate-200">{order.assignedTechnician}</strong>
                </div>
                <div className="font-mono font-bold text-sm">
                  <span className="text-slate-400 text-xs font-normal mr-1">Due:</span>
                  <span className={order.balanceDue > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600'}>
                    {formatCurrency(order.balanceDue)}
                  </span>
                </div>
              </div>

            </div>

            {/* Quick Action Buttons (Optimized for 44px thumb touch target) */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/70 border-t border-slate-100 dark:border-slate-800 grid grid-cols-4 gap-1.5">
              
              {/* WhatsApp Button */}
              <button
                type="button"
                onClick={() => onWhatsApp(order)}
                className="h-11 flex flex-col items-center justify-center bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl text-[11px] font-bold transition-colors shadow-xs"
                title="WhatsApp update"
              >
                <MessageSquare className="w-4 h-4 mb-0.5" />
                <span>WhatsApp</span>
              </button>

              {/* Send Bill Button */}
              <button
                type="button"
                onClick={() => onSendBill(order)}
                className="h-11 flex flex-col items-center justify-center bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-[11px] font-bold transition-colors shadow-xs"
                title="Send Bill Copy"
              >
                <Receipt className="w-4 h-4 mb-0.5" />
                <span>Send Bill</span>
              </button>

              {/* Direct Phone Call */}
              <a
                href={`tel:${order.customer.phone}`}
                className="h-11 flex flex-col items-center justify-center bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-xl text-[11px] font-bold transition-colors"
                title="Call customer"
              >
                <Phone className="w-4 h-4 text-blue-600 dark:text-blue-400 mb-0.5" />
                <span>Call</span>
              </a>

              {/* View Details */}
              <button
                type="button"
                onClick={() => onViewDetails(order)}
                className="h-11 flex flex-col items-center justify-center bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-xl text-[11px] font-bold transition-colors"
                title="View full details"
              >
                <ChevronRight className="w-4 h-4 text-slate-600 dark:text-slate-300 mb-0.5" />
                <span>Details</span>
              </button>

            </div>

          </div>
        );
      })}
    </div>
  );
};
