import React, { useState, useEffect } from 'react';
import { 
  X, 
  ExternalLink, 
  RefreshCw, 
  Check, 
  FolderSync, 
  FolderPlus,
  HardDrive, 
  ShieldCheck, 
  Download, 
  Upload, 
  Database,
  Camera,
  FolderOpen,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Link2,
  Sparkles
} from 'lucide-react';
import { GoogleDriveSettings, SavedGoogleDrive, WorkOrder } from '../types/workOrder';

interface GoogleDriveSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GoogleDriveSettings;
  onSaveSettings: (settings: GoogleDriveSettings) => void;
  orders: WorkOrder[];
  onImportDriveBackup?: (orders: WorkOrder[]) => void;
}

export const GoogleDriveSettingsModal: React.FC<GoogleDriveSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  orders,
  onImportDriveBackup
}) => {
  const [folderUrl, setFolderUrl] = useState(settings.folderUrl);
  const [folderName, setFolderName] = useState(settings.folderName);
  const [folderId, setFolderId] = useState(settings.folderId || '');
  const [autoSyncOnSave, setAutoSyncOnSave] = useState(settings.autoSyncOnSave);
  const [savedDrives, setSavedDrives] = useState<SavedGoogleDrive[]>(settings.savedDrives || []);

  const [activeTab, setActiveTab] = useState<'change' | 'saved' | 'sync'>('change');
  const [isSyncing, setIsSyncing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  // New preset/saved drive creation state
  const [isAddingNewDrive, setIsAddingNewDrive] = useState(false);
  const [newDriveName, setNewDriveName] = useState('');
  const [newDriveUrl, setNewDriveUrl] = useState('');
  const [newDriveDesc, setNewDriveDesc] = useState('');

  // Sync state whenever modal opens or settings change
  useEffect(() => {
    if (isOpen) {
      setFolderUrl(settings.folderUrl);
      setFolderName(settings.folderName);
      setFolderId(settings.folderId || '');
      setAutoSyncOnSave(settings.autoSyncOnSave);
      setSavedDrives(settings.savedDrives || []);
      setStatusMessage(null);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  // Helper to extract Google Drive Folder ID from a URL
  const extractFolderId = (url: string): string => {
    if (!url) return '';
    try {
      const match = url.match(/\/folders\/([a-zA-Z0-9_-]+)/);
      if (match && match[1]) return match[1];
      const idMatch = url.match(/id=([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) return idMatch[1];
    } catch {
      // fallback
    }
    return '';
  };

  const handleUrlChange = (newUrl: string) => {
    setFolderUrl(newUrl);
    const extracted = extractFolderId(newUrl);
    if (extracted) {
      setFolderId(extracted);
    }
  };

  const handleSwitchToSavedDrive = (drive: SavedGoogleDrive) => {
    setFolderUrl(drive.url);
    setFolderName(drive.name);
    setFolderId(drive.folderId || extractFolderId(drive.url));

    const updatedSettings: GoogleDriveSettings = {
      ...settings,
      folderUrl: drive.url.trim(),
      folderName: drive.name.trim(),
      folderId: drive.folderId || extractFolderId(drive.url),
      autoSyncOnSave,
      savedDrives,
      syncStatus: 'linked'
    };

    onSaveSettings(updatedSettings);
    setStatusMessage({
      type: 'success',
      text: `Successfully switched active Google Drive to "${drive.name}"!`
    });
  };

  const handleAddNewDrive = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDriveName.trim() || !newDriveUrl.trim()) return;

    const newDrive: SavedGoogleDrive = {
      id: `drive-${Date.now()}`,
      name: newDriveName.trim(),
      url: newDriveUrl.trim(),
      folderId: extractFolderId(newDriveUrl.trim()),
      description: newDriveDesc.trim() || 'Custom Google Drive location'
    };

    const updatedList = [...savedDrives, newDrive];
    setSavedDrives(updatedList);

    // Also switch to it
    setFolderUrl(newDrive.url);
    setFolderName(newDrive.name);
    setFolderId(newDrive.folderId || '');

    const updatedSettings: GoogleDriveSettings = {
      ...settings,
      folderUrl: newDrive.url,
      folderName: newDrive.name,
      folderId: newDrive.folderId,
      autoSyncOnSave,
      savedDrives: updatedList,
      syncStatus: 'linked'
    };

    onSaveSettings(updatedSettings);
    setIsAddingNewDrive(false);
    setNewDriveName('');
    setNewDriveUrl('');
    setNewDriveDesc('');
    setStatusMessage({
      type: 'success',
      text: `Added and activated new Google Drive: "${newDrive.name}".`
    });
  };

  const handleDeleteSavedDrive = (driveId: string) => {
    const updated = savedDrives.filter(d => d.id !== driveId);
    setSavedDrives(updated);
    const updatedSettings: GoogleDriveSettings = {
      ...settings,
      savedDrives: updated
    };
    onSaveSettings(updatedSettings);
    setStatusMessage({
      type: 'info',
      text: 'Saved Google Drive removed from your locations list.'
    });
  };

  const handleOpenDrive = (urlToOpen?: string) => {
    const target = urlToOpen || folderUrl;
    if (target) {
      window.open(target, '_blank', 'noopener,noreferrer');
    }
  };

  const handleSaveActiveDrive = (e: React.FormEvent) => {
    e.preventDefault();
    const finalFolderId = folderId.trim() || extractFolderId(folderUrl.trim());

    // Update in savedDrives if it matches by url, or keep list
    const updatedSettings: GoogleDriveSettings = {
      ...settings,
      folderUrl: folderUrl.trim(),
      folderName: folderName.trim(),
      folderId: finalFolderId,
      autoSyncOnSave,
      savedDrives,
      syncStatus: 'linked'
    };

    onSaveSettings(updatedSettings);
    setStatusMessage({
      type: 'success',
      text: `Google Drive destination updated to "${folderName.trim()}".`
    });
  };

  const handleSyncDatabase = () => {
    setIsSyncing(true);
    setStatusMessage(null);

    setTimeout(() => {
      // Create a bundled JSON package of the database with all service items images & orders
      const dataBundle = {
        app: 'WorkPulse Daily Work Order Management',
        version: '1.2.0',
        exportedAt: new Date().toISOString(),
        targetGoogleDriveFolder: folderName,
        targetGoogleDriveUrl: folderUrl,
        targetFolderId: folderId || extractFolderId(folderUrl),
        totalOrdersCount: orders.length,
        orders: orders
      };

      const blob = new Blob([JSON.stringify(dataBundle, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `workpulse-drive-database-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);

      const updatedSettings: GoogleDriveSettings = {
        ...settings,
        folderUrl: folderUrl.trim(),
        folderName: folderName.trim(),
        folderId: folderId || extractFolderId(folderUrl),
        autoSyncOnSave,
        lastSyncedAt: new Date().toISOString(),
        syncStatus: 'linked'
      };

      onSaveSettings(updatedSettings);
      setIsSyncing(false);
      setStatusMessage({
        type: 'success',
        text: `Database backup package created for "${folderName}". Downloaded as .json file ready to drop into your Google Drive!`
      });
    }, 600);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        const importedOrders = Array.isArray(parsed) ? parsed : (parsed.orders || []);
        
        if (Array.isArray(importedOrders) && importedOrders.length > 0) {
          if (onImportDriveBackup) {
            onImportDriveBackup(importedOrders);
          }
          setStatusMessage({
            type: 'success',
            text: `Successfully imported ${importedOrders.length} orders from Google Drive backup file.`
          });
        } else {
          setStatusMessage({
            type: 'error',
            text: 'Backup file does not contain valid work orders list.'
          });
        }
      } catch (err: any) {
        setStatusMessage({
          type: 'error',
          text: `Failed to parse backup: ${err.message || 'Invalid format'}`
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const isCurrentDrive = (url: string) => {
    return folderUrl.trim().toLowerCase() === url.trim().toLowerCase();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-xs">
              <FolderSync className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-tight">
                  Google Drive for Data & Photos
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  Configured
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Change target Google Drive folder, switch shared drives, or manage data backups
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-slate-50/50 dark:bg-slate-800/30">
          <button
            type="button"
            onClick={() => setActiveTab('change')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'change'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Change Google Drive</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'saved'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>Switch Saved Drives ({savedDrives.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sync')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'sync'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Backup & Sync Package</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Active Drive Info Banner */}
          <div className="p-3.5 bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="min-w-0">
              <span className="font-bold text-blue-900 dark:text-blue-300 block mb-0.5 flex items-center gap-1.5">
                <FolderOpen className="w-4 h-4 text-blue-600 shrink-0" />
                Active Google Drive Destination:
              </span>
              <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                {folderName}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate font-mono">
                {folderUrl}
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleOpenDrive(folderUrl)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-lg text-xs font-semibold shrink-0 shadow-xs transition-colors self-start sm:self-auto"
            >
              <span>Open in Google Drive</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Feedback Status Banner */}
          {statusMessage && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                : statusMessage.type === 'error'
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
                : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300'
            }`}>
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              ) : statusMessage.type === 'error' ? (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              ) : (
                <Sparkles className="w-4 h-4 shrink-0 text-blue-600" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* TAB 1: CHANGE GOOGLE DRIVE FORM */}
          {activeTab === 'change' && (
            <form onSubmit={handleSaveActiveDrive} className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Google Drive Folder Link / Shared Drive URL *
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      value={folderUrl}
                      onChange={(e) => handleUrlChange(e.target.value)}
                      placeholder="https://drive.google.com/drive/folders/..."
                      className="w-full pl-3 pr-24 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => handleOpenDrive(folderUrl)}
                      className="absolute right-1.5 top-1.5 px-2 py-1 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-[11px] font-medium rounded transition-colors flex items-center gap-1"
                    >
                      <span>Test Link</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Paste any Google Drive folder URL (company Google Workspace, Shared Drive, or personal Google Drive).
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Folder / Destination Display Name *
                    </label>
                    <input
                      type="text"
                      value={folderName}
                      onChange={(e) => setFolderName(e.target.value)}
                      placeholder="e.g. WorkPulse Tech Workshop Drive"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Folder ID (Auto-extracted)
                    </label>
                    <input
                      type="text"
                      value={folderId}
                      onChange={(e) => setFolderId(e.target.value)}
                      placeholder="e.g. 1BxiMVs0XRA5nFMdKvBHK..."
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Quick switch to popular workshop Drive presets */}
              <div className="pt-2">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
                  Or Click to Select from Available Drive Destinations:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {savedDrives.slice(0, 3).map((drive) => {
                    const isSelected = isCurrentDrive(drive.url);
                    return (
                      <button
                        key={drive.id}
                        type="button"
                        onClick={() => handleSwitchToSavedDrive(drive)}
                        className={`text-left p-2.5 rounded-xl border text-xs transition-all ${
                          isSelected
                            ? 'border-blue-500 bg-blue-50/70 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 ring-2 ring-blue-500/20 shadow-xs'
                            : 'border-slate-200 dark:border-slate-700 hover:border-blue-300 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold line-clamp-1">{drive.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                        </div>
                        <div className="text-[10px] text-slate-400 line-clamp-1">{drive.description}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Automatic sync toggle */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80 rounded-xl">
                <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoSyncOnSave}
                    onChange={(e) => setAutoSyncOnSave(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                  />
                  <div>
                    <span className="font-semibold block">Automatic data bundle sync</span>
                    <span className="text-[11px] text-slate-500">
                      Keep work order records and inspection images synchronized with this Google Drive destination
                    </span>
                  </div>
                </label>
              </div>

              {/* Form submit button */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('saved')}
                  className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>Manage / Add Saved Drive Presets</span>
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm transition-colors"
                >
                  Save & Apply Google Drive
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: SWITCH OR MANAGE SAVED DRIVES */}
          {activeTab === 'saved' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Your Configured Google Drive Locations
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Switch active storage between workshop branches, mobile field drives, or long-term archives in one click.
                  </p>
                </div>

                {!isAddingNewDrive && (
                  <button
                    type="button"
                    onClick={() => setIsAddingNewDrive(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors shadow-2xs"
                  >
                    <FolderPlus className="w-3.5 h-3.5" />
                    <span>Add New Drive</span>
                  </button>
                )}
              </div>

              {/* Add New Drive Form */}
              {isAddingNewDrive && (
                <form onSubmit={handleAddNewDrive} className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-blue-200 dark:border-blue-900 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <FolderPlus className="w-4 h-4 text-blue-600" />
                      Add New Google Drive Destination
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAddingNewDrive(false)}
                      className="text-slate-400 hover:text-slate-600 p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                        Drive Display Name *
                      </label>
                      <input
                        type="text"
                        value={newDriveName}
                        onChange={(e) => setNewDriveName(e.target.value)}
                        placeholder="e.g. North Branch Workshop Drive"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                        Short Description / Team
                      </label>
                      <input
                        type="text"
                        value={newDriveDesc}
                        onChange={(e) => setNewDriveDesc(e.target.value)}
                        placeholder="e.g. Bench intake photos & customer jobs"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                      Google Drive Folder URL *
                    </label>
                    <input
                      type="url"
                      value={newDriveUrl}
                      onChange={(e) => setNewDriveUrl(e.target.value)}
                      placeholder="https://drive.google.com/drive/folders/..."
                      className="w-full px-2.5 py-1.5 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsAddingNewDrive(false)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                    >
                      Save & Activate Drive
                    </button>
                  </div>
                </form>
              )}

              {/* Saved Drives List */}
              <div className="space-y-2.5">
                {savedDrives.map((drive) => {
                  const isCurrent = isCurrentDrive(drive.url);
                  return (
                    <div
                      key={drive.id}
                      className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isCurrent
                          ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-400 dark:border-blue-800 ring-2 ring-blue-500/20'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                            {drive.name}
                          </span>
                          {isCurrent ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-600 text-white flex items-center gap-1">
                              <Check className="w-2.5 h-2.5" />
                              Active Drive
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleSwitchToSavedDrive(drive)}
                              className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 hover:underline"
                            >
                              Switch to this Drive
                            </button>
                          )}
                        </div>
                        {drive.description && (
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            {drive.description}
                          </p>
                        )}
                        <span className="text-[10px] text-slate-400 font-mono block mt-0.5 truncate">
                          {drive.url}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-auto">
                        <button
                          type="button"
                          onClick={() => handleOpenDrive(drive.url)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 bg-slate-100 dark:bg-slate-700/60 rounded-lg transition-colors"
                          title="Open folder in Google Drive"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>

                        {!isCurrent && (
                          <button
                            type="button"
                            onClick={() => handleSwitchToSavedDrive(drive)}
                            className="px-3 py-1.5 text-xs font-semibold bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 rounded-lg transition-colors shadow-2xs"
                          >
                            Activate
                          </button>
                        )}

                        {savedDrives.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteSavedDrive(drive.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                            title="Remove from saved list"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: BACKUP & SYNC PACKAGE */}
          {activeTab === 'sync' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      Download Complete Google Drive Sync Bundle
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      Generates a standardized JSON backup package of all {orders.length} work orders, equipment photos, and technician notes formatted for {folderName}.
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleSyncDatabase}
                    disabled={isSyncing}
                    className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors shadow-xs shrink-0 self-start sm:self-auto"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? 'Packaging...' : 'Generate Drive Backup'}</span>
                  </button>
                </div>
              </div>

              {/* Import from Google Drive */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-2">
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Restore / Import from Google Drive Backup
                </span>
                <p className="text-[11px] text-slate-500">
                  Select a backup file previously saved to your Google Drive to restore work orders and images into this workshop session.
                </p>

                <label className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-2xs mt-1">
                  <Upload className="w-3.5 h-3.5 text-blue-600" />
                  <span>Choose Google Drive Backup File (.json)</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileImport}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Info Guide */}
              <div className="p-3 bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 rounded-xl text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                <div className="font-semibold text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  How Google Drive Data Storage Works
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Your data and service equipment images are preserved locally and formatted to synchronize with your chosen Google Drive folder. You can switch Google Drive destinations at any time without needing Google Workspace API authorization flows.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 text-xs">
          <button
            type="button"
            onClick={() => handleOpenDrive(folderUrl)}
            className="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
          >
            <span>Visit Target Folder</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
