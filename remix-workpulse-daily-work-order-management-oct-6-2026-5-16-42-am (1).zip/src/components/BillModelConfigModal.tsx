import React, { useState } from 'react';
import { 
  X, 
  Receipt, 
  Settings, 
  Check, 
  RotateCcw, 
  Building2, 
  Percent, 
  FileText, 
  Layout, 
  QrCode, 
  ShieldCheck, 
  Save,
  Eye,
  CreditCard,
  Printer
} from 'lucide-react';
import { BillModelConfig } from '../types/workOrder';
import { DEFAULT_BILL_MODEL_CONFIG } from '../services/storage';

interface BillModelConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BillModelConfig;
  onSaveConfig: (newConfig: BillModelConfig) => void;
}

export const BillModelConfigModal: React.FC<BillModelConfigModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig
}) => {
  const [formData, setFormData] = useState<BillModelConfig>(config);
  const [activeTab, setActiveTab] = useState<'branding' | 'tax' | 'policies' | 'layout'>('branding');
  const [showLivePreview, setShowLivePreview] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleChange = <K extends keyof BillModelConfig>(key: K, value: BillModelConfig[K]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 600);
  };

  const handleResetToDefault = () => {
    if (confirm('Reset bill model to default workshop configuration?')) {
      setFormData(DEFAULT_BILL_MODEL_CONFIG);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-tight">
                  Configure Bill Model & Invoice Template
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300">
                  Custom Template
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Customize shop branding, tax rules, invoice numbering, layout model, and payment terms
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowLivePreview(!showLivePreview)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-700 dark:text-slate-200 transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-blue-600" />
              <span>{showLivePreview ? 'Edit Fields' : 'Live Preview'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-slate-50/50 dark:bg-slate-800/30 overflow-x-auto">
          <button
            type="button"
            onClick={() => { setActiveTab('branding'); setShowLivePreview(false); }}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'branding' && !showLivePreview
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>1. Workshop Identity</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('tax'); setShowLivePreview(false); }}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'tax' && !showLivePreview
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Percent className="w-3.5 h-3.5" />
            <span>2. Tax & Currencies</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('policies'); setShowLivePreview(false); }}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'policies' && !showLivePreview
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>3. Terms & Bank / UPI</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('layout'); setShowLivePreview(false); }}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'layout' && !showLivePreview
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Layout className="w-3.5 h-3.5" />
            <span>4. Layout & Template</span>
          </button>

          <button
            type="button"
            onClick={() => setShowLivePreview(true)}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap sm:hidden ${
              showLivePreview
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Preview</span>
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {showLivePreview ? (
            /* Live Bill Preview Mockup */
            <div className="bg-slate-100 dark:bg-slate-950 p-4 sm:p-6 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 p-6 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 font-sans text-xs space-y-4">
                
                {/* Header */}
                <div className="flex justify-between items-start border-b pb-4 border-slate-200 dark:border-slate-700">
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white uppercase tracking-tight">
                      {formData.shopName || 'Workshop Name'}
                    </h3>
                    <p className="text-[11px] text-slate-500">{formData.tagline}</p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 max-w-xs">{formData.address}</p>
                    <p className="text-[11px] text-slate-500">Phone: {formData.phone} · Email: {formData.email}</p>
                    {formData.taxRegistrationNumber && (
                      <p className="text-[11px] font-mono text-slate-600 dark:text-slate-300 mt-0.5">
                        Tax ID / GSTIN: <strong>{formData.taxRegistrationNumber}</strong>
                      </p>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="inline-block px-2.5 py-1 bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 font-bold rounded text-[11px] uppercase tracking-wider">
                      Tax Invoice
                    </span>
                    <div className="mt-2 font-mono text-slate-900 dark:text-white font-bold">
                      {formData.invoicePrefix}1088
                    </div>
                    <div className="text-[11px] text-slate-400">Date: {new Date().toLocaleDateString()}</div>
                  </div>
                </div>

                {/* Sample items */}
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 uppercase text-[10px]">
                      <th className="py-1">Description / Service</th>
                      <th className="py-1 text-center">Qty</th>
                      <th className="py-1 text-right">Rate</th>
                      <th className="py-1 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    <tr>
                      <td className="py-1.5 font-medium">Motherboard Liquid Damage Repair & Ultrasonic Bath</td>
                      <td className="py-1.5 text-center">1</td>
                      <td className="py-1.5 text-right font-mono">{formData.currencySymbol}220.00</td>
                      <td className="py-1.5 text-right font-mono font-semibold">{formData.currencySymbol}220.00</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 font-medium">Backlight Circuit Replacement IC (MOSFET Q8400)</td>
                      <td className="py-1.5 text-center">1</td>
                      <td className="py-1.5 text-right font-mono">{formData.currencySymbol}45.00</td>
                      <td className="py-1.5 text-right font-mono font-semibold">{formData.currencySymbol}45.00</td>
                    </tr>
                  </tbody>
                </table>

                {/* Totals */}
                <div className="flex justify-end pt-2 border-t border-slate-200 dark:border-slate-700">
                  <div className="w-52 space-y-1 text-xs">
                    <div className="flex justify-between text-slate-500">
                      <span>Subtotal:</span>
                      <span className="font-mono">{formData.currencySymbol}265.00</span>
                    </div>
                    {formData.isTaxEnabled && (
                      <div className="flex justify-between text-slate-500">
                        <span>{formData.taxLabel}:</span>
                        <span className="font-mono">{formData.currencySymbol}{(265 * formData.taxRatePercent / 100).toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-slate-900 dark:text-white pt-1 border-t text-sm">
                      <span>Grand Total:</span>
                      <span className="font-mono">{formData.currencySymbol}{(265 + (formData.isTaxEnabled ? 265 * formData.taxRatePercent / 100 : 0)).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Terms & Payment info */}
                <div className="text-[10px] text-slate-500 border-t pt-3 space-y-1">
                  {formData.bankDetailsOrUPI && (
                    <p className="font-medium text-slate-700 dark:text-slate-300">
                      Payment / Bank Details: {formData.bankDetailsOrUPI}
                    </p>
                  )}
                  <p>{formData.termsAndConditions}</p>
                  <p className="text-slate-400 italic">{formData.footerNotes}</p>
                </div>

                {/* Signatures */}
                {formData.showSignatureBlock && (
                  <div className="flex justify-between pt-6 border-t text-[10px] text-slate-400">
                    <div className="border-t border-slate-300 w-36 pt-1 text-center">Customer Sign-off</div>
                    <div className="border-t border-slate-300 w-36 pt-1 text-center">Authorized Workshop Sign</div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <>
              {/* TAB 1: WORKSHOP IDENTITY */}
              {activeTab === 'branding' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Workshop / Business Name *
                      </label>
                      <input
                        type="text"
                        value={formData.shopName}
                        onChange={(e) => handleChange('shopName', e.target.value)}
                        placeholder="e.g. WorkPulse Tech Workshop"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Tagline / Subheading
                      </label>
                      <input
                        type="text"
                        value={formData.tagline}
                        onChange={(e) => handleChange('tagline', e.target.value)}
                        placeholder="e.g. Hardware Diagnostics & Board Repair"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Tax / GSTIN / VAT ID
                      </label>
                      <input
                        type="text"
                        value={formData.taxRegistrationNumber}
                        onChange={(e) => handleChange('taxRegistrationNumber', e.target.value)}
                        placeholder="e.g. GSTIN27AABCT3421Z"
                        className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Billing Phone Number *
                      </label>
                      <input
                        type="text"
                        value={formData.phone}
                        onChange={(e) => handleChange('phone', e.target.value)}
                        placeholder="+1 (555) 019-9000"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Billing Email Address
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleChange('email', e.target.value)}
                        placeholder="billing@workshop.com"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Shop Full Address & Location *
                    </label>
                    <textarea
                      rows={2}
                      value={formData.address}
                      onChange={(e) => handleChange('address', e.target.value)}
                      placeholder="Street address, building suite, city, state, zip code"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Website URL
                    </label>
                    <input
                      type="url"
                      value={formData.website || ''}
                      onChange={(e) => handleChange('website', e.target.value)}
                      placeholder="https://workpulse-ops.com"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              )}

              {/* TAB 2: TAX & CURRENCIES */}
              {activeTab === 'tax' && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
                    <label className="flex items-center gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.isTaxEnabled}
                        onChange={(e) => handleChange('isTaxEnabled', e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-900 dark:text-white block">
                          Enable Tax / GST / VAT Calculation
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Automatically compute and display tax breakdown on printed bills, WhatsApp summaries, and invoices
                        </span>
                      </div>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Tax Rate Percentage (%)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        step="0.5"
                        value={formData.taxRatePercent}
                        onChange={(e) => handleChange('taxRatePercent', Number(e.target.value))}
                        disabled={!formData.isTaxEnabled}
                        className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 disabled:opacity-50"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Tax Label on Invoice
                      </label>
                      <input
                        type="text"
                        value={formData.taxLabel}
                        onChange={(e) => handleChange('taxLabel', e.target.value)}
                        placeholder="e.g. Sales Tax, GST (18%), VAT"
                        disabled={!formData.isTaxEnabled}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 disabled:opacity-50"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Invoice Number Prefix
                      </label>
                      <input
                        type="text"
                        value={formData.invoicePrefix}
                        onChange={(e) => handleChange('invoicePrefix', e.target.value)}
                        placeholder="e.g. INV-, BILL-, WO-"
                        className="w-full px-3 py-2 text-xs font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Currency Symbol
                      </label>
                      <div className="flex gap-2">
                        {['$', '₹', '€', '£', 'AED', '¥'].map(symbol => (
                          <button
                            key={symbol}
                            type="button"
                            onClick={() => handleChange('currencySymbol', symbol)}
                            className={`px-3 py-1.5 text-xs font-mono font-bold rounded-lg border transition-colors ${
                              formData.currencySymbol === symbol
                                ? 'bg-blue-600 text-white border-blue-600'
                                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {symbol}
                          </button>
                        ))}
                        <input
                          type="text"
                          value={formData.currencySymbol}
                          onChange={(e) => handleChange('currencySymbol', e.target.value)}
                          className="w-16 px-2 py-1.5 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-center"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Currency ISO Code
                      </label>
                      <input
                        type="text"
                        value={formData.currencyCode}
                        onChange={(e) => handleChange('currencyCode', e.target.value.toUpperCase())}
                        placeholder="USD, INR, EUR, GBP"
                        className="w-full px-3 py-2 text-xs font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: TERMS & BANK / UPI */}
              {activeTab === 'policies' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Payment Account / Bank Wire / UPI ID
                    </label>
                    <input
                      type="text"
                      value={formData.bankDetailsOrUPI || ''}
                      onChange={(e) => handleChange('bankDetailsOrUPI', e.target.value)}
                      placeholder="e.g. UPI: payments@techshop | Bank: Chase Acct #9842-1102"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      Displayed on the customer invoice for direct digital payment or electronic wire.
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Billing Terms & Conditions
                    </label>
                    <textarea
                      rows={3}
                      value={formData.termsAndConditions}
                      onChange={(e) => handleChange('termsAndConditions', e.target.value)}
                      placeholder="Terms printed on invoice..."
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Warranty Policy & Disclaimer
                    </label>
                    <textarea
                      rows={2}
                      value={formData.warrantyDisclaimer}
                      onChange={(e) => handleChange('warrantyDisclaimer', e.target.value)}
                      placeholder="Warranty disclaimer rules..."
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Footer Message / Gratitude Note
                    </label>
                    <input
                      type="text"
                      value={formData.footerNotes || ''}
                      onChange={(e) => handleChange('footerNotes', e.target.value)}
                      placeholder="Thank you for trusting our repair team!"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              )}

              {/* TAB 4: LAYOUT & MODEL SELECTION */}
              {activeTab === 'layout' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
                      Default Bill Layout Model
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[
                        {
                          key: 'modern',
                          title: 'Modern Clean',
                          desc: 'Modern typography, neat table lines, balanced header with badges'
                        },
                        {
                          key: 'classic',
                          title: 'Classic Detailed',
                          desc: 'Full tabular accounting layout with formal borders and terms block'
                        },
                        {
                          key: 'thermal',
                          title: '80mm Thermal Slip',
                          desc: 'Compact receipt slip for POS thermal printers and quick counter pickup'
                        }
                      ].map(model => (
                        <button
                          key={model.key}
                          type="button"
                          onClick={() => handleChange('layoutTheme', model.key as any)}
                          className={`p-3.5 rounded-xl border text-left transition-all ${
                            formData.layoutTheme === model.key
                              ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 ring-2 ring-blue-500/20'
                              : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-xs">{model.title}</span>
                            {formData.layoutTheme === model.key && <Check className="w-4 h-4 text-blue-600" />}
                          </div>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">{model.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
                    <label className="flex items-center gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.showSignatureBlock}
                        onChange={(e) => handleChange('showSignatureBlock', e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-900 dark:text-white block">
                          Print Signature Block
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Adds Customer Acceptance & Authorized Technician sign-off lines
                        </span>
                      </div>
                    </label>

                    <label className="flex items-center gap-2.5 cursor-pointer pt-2 border-t border-slate-200 dark:border-slate-700/60">
                      <input
                        type="checkbox"
                        checked={formData.showBarcode}
                        onChange={(e) => handleChange('showBarcode', e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-900 dark:text-white block">
                          Display Barcode & QR Stamp
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Visual barcode encoding Order ID for quick handheld scanner retrieval at front desk
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Footer Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={handleResetToDefault}
              className="text-xs text-amber-600 hover:text-amber-700 dark:text-amber-400 flex items-center gap-1 font-medium"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Defaults</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
              >
                {saveSuccess ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
                <span>{saveSuccess ? 'Saved!' : 'Save Bill Model'}</span>
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
