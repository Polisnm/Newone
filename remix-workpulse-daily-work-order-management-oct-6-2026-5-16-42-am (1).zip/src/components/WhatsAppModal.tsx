import React, { useState, useEffect } from 'react';
import { 
  X, 
  MessageSquare, 
  Send, 
  Copy, 
  Check, 
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { WorkOrder } from '../types/workOrder';
import { 
  WHATSAPP_TEMPLATES, 
  WhatsAppTemplateKey, 
  openWhatsAppChat, 
  cleanPhoneNumber,
  generateWhatsAppUrl
} from '../utils/whatsapp';

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder | null;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({
  isOpen,
  onClose,
  order
}) => {
  const [selectedTemplateKey, setSelectedTemplateKey] = useState<WhatsAppTemplateKey>('intake_confirmation');
  const [customMessage, setCustomMessage] = useState('');
  const [copied, setCopied] = useState(false);

  // Automatically select suitable default template according to status
  useEffect(() => {
    if (order) {
      let defaultKey: WhatsAppTemplateKey = 'intake_confirmation';
      if (order.status === 'in_progress') defaultKey = 'diagnosis_update';
      else if (order.status === 'waiting_for_parts') defaultKey = 'waiting_for_parts';
      else if (order.status === 'completed') defaultKey = 'ready_for_pickup';
      else if (order.status === 'delivered') defaultKey = 'delivered_thank_you';

      setSelectedTemplateKey(defaultKey);
      const template = WHATSAPP_TEMPLATES.find(t => t.key === defaultKey);
      if (template) {
        setCustomMessage(template.generateText(order));
      }
    }
  }, [order, isOpen]);

  if (!isOpen || !order) return null;

  const handleTemplateSelect = (key: WhatsAppTemplateKey) => {
    setSelectedTemplateKey(key);
    const template = WHATSAPP_TEMPLATES.find(t => t.key === key);
    if (template) {
      setCustomMessage(template.generateText(order));
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(customMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSend = () => {
    openWhatsAppChat(order.customer.phone, customMessage);
    onClose();
  };

  const directUrl = generateWhatsAppUrl(order.customer.phone, customMessage);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-emerald-50/70 dark:bg-emerald-950/30">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-600 text-white">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                Send WhatsApp Update — {order.customer.name}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                Phone: {order.customer.phone} · Ticket: {order.orderNumber}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[78vh] overflow-y-auto">
          
          {/* Template Selection Tabs */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
              Select Message Template:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {WHATSAPP_TEMPLATES.map((tpl) => {
                const isSelected = selectedTemplateKey === tpl.key;
                return (
                  <button
                    key={tpl.key}
                    type="button"
                    onClick={() => handleTemplateSelect(tpl.key)}
                    className={`text-left p-2.5 rounded-lg border text-xs transition-colors ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{tpl.label}</span>
                      {isSelected && <span className="text-emerald-600 font-bold">✓</span>}
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-normal mt-0.5 line-clamp-1">
                      {tpl.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Editable Message Box */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Message Preview (Editable):
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy to Clipboard'}</span>
              </button>
            </div>

            <textarea
              rows={8}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full p-3.5 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 leading-relaxed"
            />
          </div>

          {/* Notice */}
          <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 p-2.5 rounded-lg flex items-center gap-2">
            <span>
              Clicking <strong>Send via WhatsApp</strong> opens a verified <code>wa.me</code> deep-link directly in WhatsApp Web or the mobile app with the pre-filled text.
            </span>
          </div>

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSend}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-xs transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>Send via WhatsApp</span>
          </button>
        </div>

      </div>
    </div>
  );
};
