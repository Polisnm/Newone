import React, { useState, useMemo } from 'react';
import { 
  X, 
  Receipt, 
  MessageSquare, 
  Mail, 
  Printer, 
  Copy, 
  Check, 
  Send, 
  CreditCard, 
  DollarSign, 
  Phone, 
  FileText,
  Smartphone,
  ExternalLink,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { WorkOrder } from '../types/workOrder';
import { formatCurrency, getTodayDateStr } from '../services/storage';
import { 
  BillOptions, 
  DEFAULT_BILL_OPTIONS, 
  getInvoiceNumber, 
  generateItemizedBillText, 
  generateEmailBillLink,
  generateSmsBillLink
} from '../utils/invoice';
import { openWhatsAppChat, generateWhatsAppUrl } from '../utils/whatsapp';

interface SendBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: WorkOrder | null;
  onMarkPaidInFull?: (orderId: string) => void;
  onOpenPrintInvoice?: (order: WorkOrder) => void;
}

type ChannelTab = 'whatsapp' | 'email' | 'sms' | 'preview';

export const SendBillModal: React.FC<SendBillModalProps> = ({
  isOpen,
  onClose,
  order,
  onMarkPaidInFull,
  onOpenPrintInvoice
}) => {
  const [activeChannel, setActiveChannel] = useState<ChannelTab>('whatsapp');
  const [copied, setCopied] = useState(false);
  
  // Bill Customization Options
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(getTodayDateStr());
  const [paymentMethod, setPaymentMethod] = useState<BillOptions['paymentMethod']>('Credit/Debit Card');
  const [taxPercent, setTaxPercent] = useState<number>(0);
  const [discount, setDiscount] = useState<number>(0);
  const [customerEmail, setCustomerEmail] = useState('');

  React.useEffect(() => {
    if (order) {
      setInvoiceNumber(getInvoiceNumber(order));
      setInvoiceDate(getTodayDateStr());
      setCustomerEmail(order.customer.email || '');
      setPaymentMethod(order.balanceDue <= 0 ? 'Credit/Debit Card' : 'Cash');
    }
  }, [order, isOpen]);

  const billOptions: BillOptions = useMemo(() => {
    return {
      ...DEFAULT_BILL_OPTIONS,
      invoiceNumber: invoiceNumber || (order ? getInvoiceNumber(order) : 'INV-1001'),
      invoiceDate,
      paymentMethod,
      taxPercent,
      discount
    };
  }, [invoiceNumber, invoiceDate, paymentMethod, taxPercent, discount, order]);

  const billText = useMemo(() => {
    if (!order) return '';
    return generateItemizedBillText(order, billOptions);
  }, [order, billOptions]);

  // Formatted WhatsApp Bill Text
  const whatsAppBillText = useMemo(() => {
    if (!order) return '';
    const isPaid = order.balanceDue <= 0;
    return `🧾 *OFFICIAL BILL & RECEIPT COPY*\n` +
      `*${DEFAULT_BILL_OPTIONS.shopName}*\n` +
      `📍 ${DEFAULT_BILL_OPTIONS.shopAddress}\n` +
      `📞 Support: ${DEFAULT_BILL_OPTIONS.shopPhone}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `*Invoice No:* ${billOptions.invoiceNumber}\n` +
      `*Order Ticket:* ${order.orderNumber}\n` +
      `*Date:* ${billOptions.invoiceDate}\n` +
      `*Customer:* ${order.customer.name}\n` +
      `*Device:* ${order.item.brand} ${order.item.model} (${order.item.itemType})\n` +
      `*Serial No:* ${order.item.serialNumber || 'N/A'}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `*SERVICE SUMMARY:*\n` +
      `• Issue Solved: ${order.problemReported}\n` +
      (order.partsRequired ? `• Replaced Parts: ${order.partsRequired}\n` : '') +
      `• Lead Tech: ${order.assignedTechnician}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `*CHARGES & PAYMENTS:*\n` +
      `Service Subtotal: ${formatCurrency(order.estimatedCost)}\n` +
      (taxPercent > 0 ? `Tax (${taxPercent}%): +${formatCurrency((order.estimatedCost * taxPercent) / 100)}\n` : '') +
      (discount > 0 ? `Discount: -${formatCurrency(discount)}\n` : '') +
      `Advance Paid: -${formatCurrency(order.advancePaid)}\n` +
      `*BALANCE DUE:* ${formatCurrency(order.balanceDue)}\n` +
      `*Status:* ${isPaid ? '✅ PAID IN FULL' : '⏳ BALANCE PAYABLE'}\n` +
      `*Payment Mode:* ${billOptions.paymentMethod}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🛡️ *Warranty Covered:* ${order.warrantyPeriod || '30 Days Service Warranty'}\n\n` +
      `Thank you for your business! Please keep this digital bill copy for your warranty records.`;
  }, [order, billOptions, taxPercent, discount]);

  if (!isOpen || !order) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    openWhatsAppChat(order.customer.phone, whatsAppBillText);
    onClose();
  };

  const handleSendEmail = () => {
    const updatedOrder = {
      ...order,
      customer: {
        ...order.customer,
        email: customerEmail.trim()
      }
    };
    const mailto = generateEmailBillLink(updatedOrder, billText, billOptions);
    window.location.href = mailto;
  };

  const handleSendSms = () => {
    const smsLink = generateSmsBillLink(order, billOptions);
    window.location.href = smsLink;
  };

  const isPaidInFull = order.balanceDue <= 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-tight">
                  Send Bill Copy to Customer
                </h2>
                <span className="font-mono text-xs px-2 py-0.5 rounded font-bold bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300">
                  {billOptions.invoiceNumber}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Customer: <strong>{order.customer.name}</strong> · Device: {order.item.brand} {order.item.model}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Channel Selection Tabs */}
        <div className="px-6 pt-4 pb-2 border-b border-slate-200 dark:border-slate-800 flex flex-wrap gap-2 bg-slate-50/50 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => setActiveChannel('whatsapp')}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeChannel === 'whatsapp'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>WhatsApp Bill</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChannel('email')}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeChannel === 'email'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Email Invoice</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChannel('sms')}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeChannel === 'sms'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>SMS Receipt</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChannel('preview')}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeChannel === 'preview'
                ? 'bg-slate-800 text-white dark:bg-slate-700 shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Full Invoice Text</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 max-h-[70vh]">
          
          {/* Quick Bill Configuration Banner */}
          <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Invoice Number:
              </label>
              <input
                type="text"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full px-2.5 py-1 text-xs font-mono font-bold rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Invoice Date:
              </label>
              <input
                type="date"
                value={invoiceDate}
                onChange={(e) => setInvoiceDate(e.target.value)}
                className="w-full px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Payment Method:
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              >
                <option value="Credit/Debit Card">Credit/Debit Card</option>
                <option value="Cash">Cash Counter</option>
                <option value="Bank Transfer / Wire">Bank Transfer</option>
                <option value="Online / UPI">Online / UPI</option>
                <option value="Pending">Payment Pending</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Payment Status:
              </label>
              <div className="flex items-center gap-1.5 pt-0.5">
                <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                  isPaidInFull 
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' 
                    : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                }`}>
                  {isPaidInFull ? 'Paid in Full' : `Due: ${formatCurrency(order.balanceDue)}`}
                </span>
              </div>
            </div>
          </div>

          {/* CHANNEL SPECIFIC PANELS */}

          {/* 1. WHATSAPP CHANNEL */}
          {activeChannel === 'whatsapp' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    WhatsApp Digital Bill Preview
                  </span>
                  <span className="text-xs text-slate-500 font-mono">
                    (Target: {order.customer.phone})
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy(whatsAppBillText)}
                  className="text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 flex items-center gap-1 font-medium"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Bill Text'}</span>
                </button>
              </div>

              {/* Chat Bubble Style Container */}
              <div className="p-4 bg-emerald-50/60 dark:bg-slate-800/80 border border-emerald-200/80 dark:border-slate-700 rounded-xl text-xs font-mono leading-relaxed whitespace-pre-wrap text-slate-800 dark:text-slate-200 shadow-inner">
                {whatsAppBillText}
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-[11px] text-slate-500">
                  Sends directly to customer's WhatsApp chat with formatted invoice slip and warranty terms.
                </div>
                <button
                  type="button"
                  onClick={handleSendWhatsApp}
                  className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-xs transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Bill on WhatsApp</span>
                </button>
              </div>
            </div>
          )}

          {/* 2. EMAIL CHANNEL */}
          {activeChannel === 'email' && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Recipient Email Address:
                </label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="e.g. customer@example.com"
                    className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Email Bill Preview:
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(billText)}
                    className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy Text'}</span>
                  </button>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono whitespace-pre-wrap text-slate-800 dark:text-slate-200 max-h-60 overflow-y-auto">
                  {billText}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-[11px] text-slate-500">
                  Launches your default mail client with pre-filled subject line and full invoice text.
                </div>
                <button
                  type="button"
                  onClick={handleSendEmail}
                  className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  <span>Open in Email Client</span>
                </button>
              </div>
            </div>
          )}

          {/* 3. SMS CHANNEL */}
          {activeChannel === 'sms' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Smartphone className="w-4 h-4 text-purple-600" />
                <span>Quick SMS Text to <strong>{order.customer.phone}</strong>:</span>
              </div>

              <div className="p-4 bg-purple-50/50 dark:bg-slate-800 border border-purple-200 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-800 dark:text-slate-200">
                Hello {order.customer.name}, your bill copy for {order.item.brand} {order.item.model} ({billOptions.invoiceNumber}) is ready. Total: ${order.estimatedCost.toFixed(2)}, Advance Paid: ${order.advancePaid.toFixed(2)}, Balance: ${order.balanceDue.toFixed(2)}. WorkPulse Tech Care
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-[11px] text-slate-500">
                  Ideal for cellular smartphones with direct SMS native app launch.
                </div>
                <button
                  type="button"
                  onClick={handleSendSms}
                  className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-xs transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>Send via SMS</span>
                </button>
              </div>
            </div>
          )}

          {/* 4. FULL INVOICE PREVIEW & PRINT */}
          {activeChannel === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Itemized Bill Copy Plaintext:
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(billText)}
                    className="text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 flex items-center gap-1 font-medium"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy Text</span>
                  </button>
                  {onOpenPrintInvoice && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenPrintInvoice(order);
                      }}
                      className="text-xs text-blue-600 dark:text-blue-400 font-semibold flex items-center gap-1 hover:underline"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Open Printable Slip</span>
                    </button>
                  )}
                </div>
              </div>

              <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono leading-relaxed overflow-x-auto border border-slate-800">
                {billText}
              </pre>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div>
            {onOpenPrintInvoice && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenPrintInvoice(order);
                }}
                className="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Physical Bill</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
