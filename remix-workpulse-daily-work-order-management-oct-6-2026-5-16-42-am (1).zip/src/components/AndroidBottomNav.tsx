import React from 'react';
import { 
  Calendar, 
  LayoutList, 
  Plus, 
  Receipt, 
  Users 
} from 'lucide-react';
import { NavTab } from '../types/workOrder';

interface AndroidBottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  totalOrdersCount: number;
}

export const AndroidBottomNav: React.FC<AndroidBottomNavProps> = ({
  activeTab,
  onTabChange,
  totalOrdersCount
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 transition-colors shadow-lg px-2 pb-safe">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto">
        
        {/* 1. Daily Schedule */}
        <button
          type="button"
          onClick={() => onTabChange('daily')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'daily'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${
            activeTab === 'daily' ? 'bg-blue-100 dark:bg-blue-950/60 scale-105' : ''
          }`}>
            <Calendar className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Schedule</span>
        </button>

        {/* 2. All Orders */}
        <button
          type="button"
          onClick={() => onTabChange('all')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors relative ${
            activeTab === 'all'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${
            activeTab === 'all' ? 'bg-blue-100 dark:bg-blue-950/60 scale-105' : ''
          }`}>
            <LayoutList className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Orders</span>
          {totalOrdersCount > 0 && (
            <span className="absolute top-1 right-3 text-[9px] font-mono px-1 py-0.2 bg-blue-600 text-white rounded-full">
              {totalOrdersCount}
            </span>
          )}
        </button>

        {/* 3. Center Prominent Action: Item Intake */}
        <button
          type="button"
          onClick={() => onTabChange('item_entry')}
          className="flex flex-col items-center justify-center -mt-5"
          title="Item Intake"
        >
          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg transition-transform active:scale-95 ${
            activeTab === 'item_entry' 
              ? 'bg-blue-600 ring-4 ring-blue-500/20 shadow-blue-500/30' 
              : 'bg-blue-600 hover:bg-blue-700'
          }`}>
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </div>
          <span className={`text-[10px] mt-1 font-semibold ${
            activeTab === 'item_entry' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500'
          }`}>
            Intake
          </span>
        </button>

        {/* 4. Billing Station */}
        <button
          type="button"
          onClick={() => onTabChange('billing')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'billing'
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${
            activeTab === 'billing' ? 'bg-emerald-100 dark:bg-emerald-950/60 scale-105' : ''
          }`}>
            <Receipt className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Billing</span>
        </button>

        {/* 5. Employees Roster */}
        <button
          type="button"
          onClick={() => onTabChange('employees')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'employees'
              ? 'text-purple-600 dark:text-purple-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${
            activeTab === 'employees' ? 'bg-purple-100 dark:bg-purple-950/60 scale-105' : ''
          }`}>
            <Users className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Staff</span>
        </button>

      </div>
    </nav>
  );
};
