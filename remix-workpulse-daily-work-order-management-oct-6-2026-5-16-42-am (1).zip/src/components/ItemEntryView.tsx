import React, { useState } from 'react';
import { 
  Laptop, 
  Smartphone, 
  Tablet, 
  Monitor, 
  Cpu, 
  Printer, 
  Headphones, 
  Network, 
  Wrench, 
  User, 
  Phone, 
  MapPin, 
  Calendar, 
  DollarSign, 
  CheckCircle2, 
  Camera, 
  Save, 
  Printer as PrintIcon, 
  MessageSquare, 
  Sparkles, 
  Tag, 
  Plus, 
  Clock, 
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus, PriorityLevel, ItemType, ItemImage, GoogleDriveSettings } from '../types/workOrder';
import { StorageService, ACCESSORY_PRESETS, getTodayDateStr, formatCurrency } from '../services/storage';
import { ImageAttachmentSection } from './ImageAttachmentSection';

interface ItemEntryViewProps {
  onSaveOrder: (order: WorkOrder) => void;
  onPrintOrder: (order: WorkOrder) => void;
  onWhatsAppOrder: (order: WorkOrder) => void;
  techniciansList: string[];
  recentOrders: WorkOrder[];
  googleDriveSettings?: GoogleDriveSettings;
  onOpenGoogleDriveSettings?: () => void;
}

const ITEM_TYPES: Array<{ type: ItemType; icon: React.ComponentType<{ className?: string }> }> = [
  { type: 'Laptop', icon: Laptop },
  { type: 'Desktop PC', icon: Monitor },
  { type: 'Motherboard / Logic Board', icon: Cpu },
  { type: 'Smartphone', icon: Smartphone },
  { type: 'Tablet', icon: Tablet },
  { type: 'Printer / Scanner', icon: Printer },
  { type: 'Audio / Console', icon: Headphones },
  { type: 'Network Equipment', icon: Network },
  { type: 'Other Equipment', icon: Wrench },
];

const POPULAR_BRANDS = ['Apple', 'Dell', 'HP', 'Lenovo', 'ASUS', 'Acer', 'Samsung', 'MSI', 'Sony'];

const COMMON_SYMPTOMS = [
  'No Power / Completely Dead',
  'Liquid Spill / Coffee Corrosion',
  'Screen Broken / Lines / Flickering',
  'Overheating / Fans Spinning 100%',
  'No Display / Black Screen on Boot',
  'Battery Not Charging / Drains Fast',
  'Corrupt OS / Blue Screen / Boot Loop',
  'Short Circuit / Burn Smell on Board'
];

const COSMETIC_PRESETS = [
  'Immaculate / Mint condition',
  'Minor hairline scratches on top lid',
  'Dent on corner chassis',
  'Screen anti-reflective coating wear',
  'Loose hinge / cracked casing',
  'Missing bottom casing screws'
];

export const ItemEntryView: React.FC<ItemEntryViewProps> = ({
  onSaveOrder,
  onPrintOrder,
  onWhatsAppOrder,
  techniciansList,
  recentOrders,
  googleDriveSettings,
  onOpenGoogleDriveSettings
}) => {
  // Form State
  const [scheduledDate, setScheduledDate] = useState(getTodayDateStr());
  const [dueDate, setDueDate] = useState(getTodayDateStr());
  const [status, setStatus] = useState<WorkOrderStatus>('pending');
  const [priority, setPriority] = useState<PriorityLevel>('normal');

  // Customer State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAltPhone, setCustomerAltPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  // Item State
  const [itemType, setItemType] = useState<ItemType>('Laptop');
  const [brand, setBrand] = useState('Apple');
  const [model, setModel] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [cosmeticCondition, setCosmeticCondition] = useState('');
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>(['Original Charger / Power Adapter']);
  const [attachedImages, setAttachedImages] = useState<ItemImage[]>([]);

  // Diagnostics & Cost
  const [problemReported, setProblemReported] = useState('');
  const [preliminaryDiagnosis, setPreliminaryDiagnosis] = useState('');
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [assignedTechnician, setAssignedTechnician] = useState(techniciansList[0] || 'Alex Rivera');
  const [estimatedCost, setEstimatedCost] = useState<number>(150);
  const [advancePaid, setAdvancePaid] = useState<number>(50);
  const [warrantyPeriod, setWarrantyPeriod] = useState('60 Days Warranty on Labor & Parts');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  const toggleAccessory = (acc: string) => {
    if (selectedAccessories.includes(acc)) {
      setSelectedAccessories(selectedAccessories.filter(a => a !== acc));
    } else {
      setSelectedAccessories([...selectedAccessories, acc]);
    }
  };

  const handleApplySymptom = (symptom: string) => {
    if (!problemReported.trim()) {
      setProblemReported(symptom);
    } else if (!problemReported.includes(symptom)) {
      setProblemReported(`${problemReported}. ${symptom}`);
    }
  };

  const handleGenerateSerial = () => {
    const randomHex = Math.random().toString(36).substring(2, 10).toUpperCase();
    setSerialNumber(`SN-${brand.slice(0, 3).toUpperCase()}-${randomHex}`);
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!customerName.trim()) errs.customerName = 'Customer name is required';
    if (!customerPhone.trim()) errs.customerPhone = 'Phone number is required';
    if (!customerAddress.trim()) errs.customerAddress = 'Address / location is required';
    if (!brand.trim()) errs.brand = 'Brand is required';
    if (!model.trim()) errs.model = 'Model is required';
    if (!problemReported.trim()) errs.problemReported = 'Problem description is required';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const buildWorkOrder = (): WorkOrder => {
    const nextNum = `WO-${1000 + recentOrders.length + 1}`;
    const balanceDue = Math.max(0, Number(estimatedCost || 0) - Number(advancePaid || 0));

    return {
      id: `wo-${Date.now()}`,
      orderNumber: nextNum,
      scheduledDate,
      dueDate,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status,
      priority,
      customer: {
        name: customerName.trim(),
        phone: customerPhone.trim(),
        altPhone: customerAltPhone.trim() || undefined,
        email: customerEmail.trim() || undefined,
        address: customerAddress.trim()
      },
      item: {
        itemType,
        brand: brand.trim(),
        model: model.trim(),
        serialNumber: serialNumber.trim() || `SN-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        cosmeticCondition: cosmeticCondition.trim() || undefined,
        accessoriesIncluded: selectedAccessories,
        images: attachedImages
      },
      problemReported: problemReported.trim(),
      preliminaryDiagnosis: preliminaryDiagnosis.trim(),
      technicianNotes: technicianNotes.trim(),
      assignedTechnician,
      estimatedCost: Number(estimatedCost || 0),
      advancePaid: Number(advancePaid || 0),
      balanceDue,
      warrantyPeriod: warrantyPeriod.trim(),
      statusHistory: [
        {
          status,
          timestamp: new Date().toISOString(),
          note: 'Item logged at Bench Intake Station.',
          updatedBy: 'Front Desk'
        }
      ]
    };
  };

  const resetForm = () => {
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAltPhone('');
    setCustomerEmail('');
    setCustomerAddress('');
    setModel('');
    setSerialNumber('');
    setCosmeticCondition('');
    setProblemReported('');
    setPreliminaryDiagnosis('');
    setTechnicianNotes('');
    setAttachedImages([]);
    setEstimatedCost(150);
    setAdvancePaid(50);
    setErrors({});
  };

  const handleSubmit = (action: 'save' | 'print' | 'whatsapp') => {
    if (!validate()) return;

    const newOrder = buildWorkOrder();
    onSaveOrder(newOrder);

    if (action === 'print') {
      onPrintOrder(newOrder);
    } else if (action === 'whatsapp') {
      onWhatsAppOrder(newOrder);
    }

    setSuccessBanner(`Work Order ${newOrder.orderNumber} successfully logged for ${newOrder.customer.name}!`);
    resetForm();
    setTimeout(() => setSuccessBanner(null), 4000);
  };

  const calculatedBalance = Math.max(0, (estimatedCost || 0) - (advancePaid || 0));

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-600 text-white shadow-xs">
                <Wrench className="w-5 h-5" />
              </span>
              <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                Item Intake & Device Entry Station
              </h1>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Log customer equipment, record condition & accessories, attach photos, and issue immediate receipts
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-semibold rounded-lg border border-blue-200 dark:border-blue-900">
              Next Order No: WO-{1000 + recentOrders.length + 1}
            </span>
          </div>
        </div>

        {/* Success Alert */}
        {successBanner && (
          <div className="mt-4 p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successBanner}</span>
          </div>
        )}
      </div>

      {/* Main Grid: Entry Form (Left) & Recent Intakes (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Form: 2 Cols */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Section 1: Customer Details */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <User className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                1. Customer Contact Details
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Customer Full Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. John Doe, Sarah Connor"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.customerName ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.customerName && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerName}</p>}
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Primary Phone / WhatsApp *
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+1 (555) 234-5678"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.customerPhone ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.customerPhone && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerPhone}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Alternative Phone (Optional)
                </label>
                <input
                  type="tel"
                  value={customerAltPhone}
                  onChange={(e) => setCustomerAltPhone(e.target.value)}
                  placeholder="+1 (555) 987-6543"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="john.doe@email.com"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Customer Location / Physical Address *
              </label>
              <input
                type="text"
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                placeholder="Street address, city, area"
                className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                  errors.customerAddress ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                }`}
              />
              {errors.customerAddress && <p className="text-[11px] text-rose-500 mt-0.5">{errors.customerAddress}</p>}
            </div>
          </div>

          {/* Section 2: Equipment & Asset Details */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <Laptop className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                2. Device & Hardware Specification
              </h2>
            </div>

            {/* Device Type Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
                Item Category *
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {ITEM_TYPES.map(({ type, icon: Icon }) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setItemType(type)}
                    className={`flex flex-col items-center gap-1.5 p-2.5 rounded-xl border text-center transition-all ${
                      itemType === type
                        ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 ring-2 ring-blue-500/20 font-bold'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-[11px] leading-tight line-clamp-1">{type}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Brand & Model */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Brand / Manufacturer *
                </label>
                <input
                  type="text"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="e.g. Apple, Dell, Lenovo"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.brand ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {/* Brand quick chips */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {POPULAR_BRANDS.map(b => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => setBrand(b)}
                      className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${
                        brand === b
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Model & Specs *
                </label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="e.g. MacBook Pro 14 (M3 Pro) / ThinkPad X1"
                  className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                    errors.model ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {errors.model && <p className="text-[11px] text-rose-500 mt-0.5">{errors.model}</p>}
              </div>
            </div>

            {/* Serial Number & Scanner */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Serial Number / Service Tag
                </label>
                <button
                  type="button"
                  onClick={handleGenerateSerial}
                  className="text-[11px] text-blue-600 hover:text-blue-700 font-semibold"
                >
                  Generate Temp Serial
                </button>
              </div>
              <input
                type="text"
                value={serialNumber}
                onChange={(e) => setSerialNumber(e.target.value)}
                placeholder="e.g. C02G99XZMD6R or scan barcode"
                className="w-full px-3 py-2 text-xs font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>

            {/* Accessories Checklist */}
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                Included Accessories & Items Received
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {ACCESSORY_PRESETS.map((acc) => {
                  const isChecked = selectedAccessories.includes(acc);
                  return (
                    <button
                      key={acc}
                      type="button"
                      onClick={() => toggleAccessory(acc)}
                      className={`text-left p-2 rounded-lg border text-xs transition-colors flex items-center gap-1.5 ${
                        isChecked
                          ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 font-medium'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        readOnly
                        className="rounded border-slate-300 text-blue-600 pointer-events-none"
                      />
                      <span className="line-clamp-1">{acc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Cosmetic Condition */}
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Cosmetic Condition / Existing Defects
              </label>
              <input
                type="text"
                value={cosmeticCondition}
                onChange={(e) => setCosmeticCondition(e.target.value)}
                placeholder="e.g. Scratches on bottom, dent on left hinge, screen intact"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
              <div className="flex flex-wrap gap-1 mt-1.5">
                {COSMETIC_PRESETS.map(preset => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setCosmeticCondition(preset)}
                    className="text-[10px] px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 hover:border-slate-300"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Service Images Section */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <ImageAttachmentSection
                images={attachedImages}
                onChange={setAttachedImages}
                googleDriveSettings={googleDriveSettings}
                onOpenGoogleDriveSettings={onOpenGoogleDriveSettings}
              />
            </div>
          </div>

          {/* Section 3: Diagnosis, Symptoms & Financials */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                3. Symptoms, Assignment & Financials
              </h2>
            </div>

            {/* Problem Description */}
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Reported Problem / Customer Complaint *
              </label>
              <textarea
                rows={2}
                value={problemReported}
                onChange={(e) => setProblemReported(e.target.value)}
                placeholder="Describe exact customer reported failure..."
                className={`w-full px-3 py-2 text-xs rounded-lg border bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 ${
                  errors.problemReported ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                }`}
              />
              {errors.problemReported && <p className="text-[11px] text-rose-500 mt-0.5">{errors.problemReported}</p>}

              {/* Symptom quick chips */}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {COMMON_SYMPTOMS.map(symptom => (
                  <button
                    key={symptom}
                    type="button"
                    onClick={() => handleApplySymptom(symptom)}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 hover:text-blue-600 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors"
                  >
                    + {symptom}
                  </button>
                ))}
              </div>
            </div>

            {/* Preliminary Diagnosis & Tech Notes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Preliminary Diagnosis
                </label>
                <textarea
                  rows={2}
                  value={preliminaryDiagnosis}
                  onChange={(e) => setPreliminaryDiagnosis(e.target.value)}
                  placeholder="Bench tech initial finding..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Internal Workshop Notes
                </label>
                <textarea
                  rows={2}
                  value={technicianNotes}
                  onChange={(e) => setTechnicianNotes(e.target.value)}
                  placeholder="Passcodes, customer urgent requests..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            {/* Technician & Priority */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Assign Technician
                </label>
                <select
                  value={assignedTechnician}
                  onChange={(e) => setAssignedTechnician(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  {techniciansList.map(tech => (
                    <option key={tech} value={tech}>{tech}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Target Due Date
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Priority
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  <option value="low">Low Priority</option>
                  <option value="normal">Normal Priority</option>
                  <option value="high">High Priority</option>
                  <option value="urgent">Urgent / Emergency</option>
                </select>
              </div>
            </div>

            {/* Financial Ledger */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Estimated Cost ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={estimatedCost}
                    onChange={(e) => setEstimatedCost(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Advance Paid ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={advancePaid}
                    onChange={(e) => setAdvancePaid(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-emerald-600"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Balance Due ($)
                  </label>
                  <div className="w-full px-3 py-2 text-xs font-mono font-extrabold rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-amber-600">
                    {formatCurrency(calculatedBalance)}
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                Clear Form
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSubmit('print')}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors shadow-2xs"
                >
                  <PrintIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Log & Print Receipt</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSubmit('whatsapp')}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 rounded-lg transition-colors shadow-2xs"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Log & WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSubmit('save')}
                  className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm transition-colors"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Log Work Order</span>
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Right Side: Recent Workshop Intakes Today */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-2xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Recent Intakes Today
                </h3>
              </div>
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600">
                {recentOrders.length}
              </span>
            </div>

            {recentOrders.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-400">
                No orders logged yet today. Use the form to record incoming devices.
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[700px] overflow-y-auto pr-1">
                {recentOrders.slice(0, 10).map((order) => (
                  <div
                    key={order.id}
                    className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-blue-200 transition-all text-xs"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                        {order.orderNumber}
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 uppercase">
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <div className="font-bold text-slate-800 dark:text-slate-200 truncate">
                      {order.customer.name}
                    </div>

                    <div className="text-[11px] text-slate-500 truncate">
                      {order.item.brand} {order.item.model}
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px]">
                      <span className="text-slate-400">Est: {formatCurrency(order.estimatedCost)}</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onPrintOrder(order)}
                          className="p-1 text-slate-500 hover:text-blue-600"
                          title="Print Receipt"
                        >
                          <PrintIcon className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onWhatsAppOrder(order)}
                          className="p-1 text-slate-500 hover:text-emerald-600"
                          title="Send WhatsApp"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
