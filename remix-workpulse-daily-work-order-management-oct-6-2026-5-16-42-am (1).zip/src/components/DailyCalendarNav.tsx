import React from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Clock, 
  Wrench, 
  PackageSearch, 
  CheckCircle2, 
  Truck,
  AlertTriangle
} from 'lucide-react';
import { DailyStatusCounts, WorkOrderStatus } from '../types/workOrder';
import { formatDateDisplay, getTodayDateStr } from '../services/storage';

interface DailyCalendarNavProps {
  selectedDate: string;
  onDateChange: (newDate: string) => void;
  dailyCounts: DailyStatusCounts;
  activeStatusFilter: WorkOrderStatus | 'all';
  onStatusFilterChange: (status: WorkOrderStatus | 'all') => void;
}

export const DailyCalendarNav: React.FC<DailyCalendarNavProps> = ({
  selectedDate,
  onDateChange,
  dailyCounts,
  activeStatusFilter,
  onStatusFilterChange
}) => {
  const today = getTodayDateStr();
  const isToday = selectedDate === today;

  const handlePrevDay = () => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const prev = new Date(year, month - 1, day - 1);
    onDateChange(prev.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const next = new Date(year, month - 1, day + 1);
    onDateChange(next.toISOString().split('T')[0]);
  };

  const handleSetToday = () => {
    onDateChange(today);
  };

  const statusCategories = [
    {
      key: 'all' as const,
      label: 'Total Scheduled',
      count: dailyCounts.total,
      color: 'text-slate-900 dark:text-white',
      accentDot: 'bg-slate-400 dark:bg-slate-500'
    },
    {
      key: 'pending' as WorkOrderStatus,
      label: 'Pending',
      count: dailyCounts.pending,
      color: 'text-amber-700 dark:text-amber-400',
      accentDot: 'bg-amber-500'
    },
    {
      key: 'in_progress' as WorkOrderStatus,
      label: 'In Progress',
      count: dailyCounts.in_progress,
      color: 'text-blue-700 dark:text-blue-400',
      accentDot: 'bg-blue-500'
    },
    {
      key: 'waiting_for_parts' as WorkOrderStatus,
      label: 'Waiting Parts',
      count: dailyCounts.waiting_for_parts,
      color: 'text-purple-700 dark:text-purple-400',
      accentDot: 'bg-purple-500'
    },
    {
      key: 'completed' as WorkOrderStatus,
      label: 'Completed',
      count: dailyCounts.completed,
      color: 'text-emerald-700 dark:text-emerald-400',
      accentDot: 'bg-emerald-500'
    },
    {
      key: 'delivered' as WorkOrderStatus,
      label: 'Delivered',
      count: dailyCounts.delivered,
      color: 'text-teal-700 dark:text-teal-400',
      accentDot: 'bg-teal-500'
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm mb-6 transition-colors">
      
      {/* Date Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        
        {/* Day Navigator */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 border border-slate-200/60 dark:border-slate-700/60">
            <button
              type="button"
              onClick={handlePrevDay}
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-md text-slate-600 dark:text-slate-300 transition-colors"
              title="Previous Day"
              aria-label="Previous day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleSetToday}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                isToday 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              Today
            </button>
            <button
              type="button"
              onClick={handleNextDay}
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-md text-slate-600 dark:text-slate-300 transition-colors"
              title="Next Day"
              aria-label="Next day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Current Date Display */}
          <div className="flex items-center gap-2 pl-2">
            <CalendarIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
              {formatDateDisplay(selectedDate)}
            </h2>
            {isToday && (
              <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md">
                Current Day
              </span>
            )}
          </div>
        </div>

        {/* Date Picker Input */}
        <div className="flex items-center gap-2">
          <label htmlFor="calendar-date-picker" className="text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
            Jump to date:
          </label>
          <input
            id="calendar-date-picker"
            type="date"
            value={selectedDate}
            onChange={(e) => e.target.value && onDateChange(e.target.value)}
            className="px-2.5 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Daily Breakdown Status Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-4">
        {statusCategories.map((item) => {
          const isSelected = activeStatusFilter === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onStatusFilterChange(isSelected && item.key !== 'all' ? 'all' : item.key)}
              className={`p-3 rounded-lg border text-left transition-all relative overflow-hidden group ${
                isSelected
                  ? 'border-blue-500 dark:border-blue-500 bg-blue-50/50 dark:bg-blue-950/20 shadow-xs'
                  : 'border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-slate-600 dark:text-slate-400 truncate">
                  {item.label}
                </span>
                <span className={`w-2 h-2 rounded-full ${item.accentDot}`} />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-xl font-bold font-mono tabular-nums ${item.color}`}>
                  {item.count}
                </span>
                <span className="text-[11px] text-slate-400 dark:text-slate-500">
                  orders
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Overdue Warning Notice if any */}
      {dailyCounts.overdue > 0 && (
        <div className="mt-3 flex items-center justify-between px-3 py-2 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg text-xs text-rose-800 dark:text-rose-300">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
            <span>
              <strong>{dailyCounts.overdue} work order{dailyCounts.overdue > 1 ? 's' : ''}</strong> currently past due date require technician intervention.
            </span>
          </div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-rose-600 dark:text-rose-400">
            Action Needed
          </span>
        </div>
      )}

    </div>
  );
};
