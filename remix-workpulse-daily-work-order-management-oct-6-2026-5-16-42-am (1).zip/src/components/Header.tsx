import React, { useState } from 'react';
import { 
  Plus, 
  Sun, 
  Moon, 
  Calendar, 
  LayoutList, 
  Columns3, 
  Smartphone, 
  Database, 
  Download, 
  Upload, 
  RotateCcw,
  Wrench,
  CheckCircle2,
  FolderSync,
  Receipt,
  Users,
  Settings
} from 'lucide-react';
import { ViewMode, NavTab } from '../types/workOrder';

interface HeaderProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onOpenNewOrderModal: () => void;
  onOpenSupabaseModal: () => void;
  onOpenGoogleDriveModal: () => void;
  onOpenBillConfigModal?: () => void;
  googleDriveFolderName?: string;
  onExportData: () => void;
  onImportData: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetData: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  activeNavTab: NavTab;
  onNavTabChange: (tab: NavTab) => void;
  totalOrdersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  viewMode,
  onViewModeChange,
  onOpenNewOrderModal,
  onOpenSupabaseModal,
  onOpenGoogleDriveModal,
  onOpenBillConfigModal,
  googleDriveFolderName,
  onExportData,
  onImportData,
  onResetData,
  darkMode,
  onToggleDarkMode,
  activeNavTab,
  onNavTabChange,
  totalOrdersCount
}) => {
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Zone 1: Brand Title (Single text element wordmark with icon) */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 dark:bg-blue-500 flex items-center justify-center text-white shadow-sm shadow-blue-500/20 shrink-0">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white block leading-none">
                WorkPulse
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:inline">
                Workshop & Field Ops
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links & View Controls */}
          <nav className="flex items-center gap-1 sm:gap-2">
            {/* Separate Tabs for daily, all, item_entry, billing, employees */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-lg overflow-x-auto max-w-[55vw] sm:max-w-none">
              
              {/* 1. Daily Schedule */}
              <button
                type="button"
                onClick={() => onNavTabChange('daily')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeNavTab === 'daily'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Daily</span>
                <span>Schedule</span>
              </button>

              {/* 2. All Orders */}
              <button
                type="button"
                onClick={() => onNavTabChange('all')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeNavTab === 'all'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>All Orders</span>
                <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.2 bg-slate-200 dark:bg-slate-600 rounded text-slate-700 dark:text-slate-200">
                  {totalOrdersCount}
                </span>
              </button>

              {/* 3. Item Entering Tab */}
              <button
                type="button"
                onClick={() => onNavTabChange('item_entry')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeNavTab === 'item_entry'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-white'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Item Intake</span>
              </button>

              {/* 4. Bill Generating Tab */}
              <button
                type="button"
                onClick={() => onNavTabChange('billing')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeNavTab === 'billing'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-white'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Bill Generator</span>
              </button>

              {/* 5. Employees & Staff Tab */}
              <button
                type="button"
                onClick={() => onNavTabChange('employees')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeNavTab === 'employees'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-purple-600 dark:hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Staff &</span>
                <span>Employees</span>
              </button>
            </div>

            {/* View Mode Toggle: Table / Kanban / Field (when in daily or all orders view) */}
            {(activeNavTab === 'daily' || activeNavTab === 'all') && (
              <div className="hidden xl:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                <button
                  type="button"
                  onClick={() => onViewModeChange('table')}
                  title="Workshop Desk Table View"
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === 'table'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <LayoutList className="w-3.5 h-3.5" />
                  <span>Desk</span>
                </button>

                <button
                  type="button"
                  onClick={() => onViewModeChange('kanban')}
                  title="Pipeline Kanban Board"
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === 'kanban'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Columns3 className="w-3.5 h-3.5" />
                  <span>Pipeline</span>
                </button>

                <button
                  type="button"
                  onClick={() => onViewModeChange('mobile_field')}
                  title="Smartphone Field Technician View"
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === 'mobile_field'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Field</span>
                </button>
              </div>
            )}
          </nav>

          {/* Zone 3: Actions (New Work Order, Schema, Dark Mode) */}
          <div className="flex items-center gap-2">
            
            {/* Configure Bill Model Button */}
            {onOpenBillConfigModal && (
              <button
                type="button"
                onClick={onOpenBillConfigModal}
                title="Configure Bill Model & Invoice Template"
                className="hidden lg:flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 hover:text-emerald-700 dark:hover:text-emerald-300 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap shadow-2xs"
              >
                <Settings className="w-3.5 h-3.5 text-emerald-600" />
                <span>Bill Model</span>
              </button>
            )}

            {/* Google Drive Storage Button */}
            <button
              type="button"
              onClick={onOpenGoogleDriveModal}
              title={googleDriveFolderName ? `Current Drive: ${googleDriveFolderName} (Click to change Google Drive for data)` : 'Configure or change Google Drive for data'}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/60 hover:text-blue-600 dark:hover:text-blue-400 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap shadow-2xs"
            >
              <FolderSync className="w-3.5 h-3.5 text-blue-500" />
              <span className="hidden sm:inline">Google Drive</span>
            </button>

            {/* Supabase Schema Modal Button */}
            <button
              type="button"
              onClick={onOpenSupabaseModal}
              title="View Supabase PostgreSQL Schema"
              className="hidden 2xl:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              <Database className="w-3.5 h-3.5 text-emerald-500" />
              <span>Supabase Schema</span>
            </button>

            {/* Dark / Light Mode Toggle */}
            <button
              type="button"
              onClick={onToggleDarkMode}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* More / Settings Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowSettingsMenu(!showSettingsMenu)}
                className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                title="Data Backup & Tools"
              >
                <Download className="w-4 h-4" />
              </button>

              {showSettingsMenu && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowSettingsMenu(false)}
                  />
                  <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 text-xs">
                    
                    {onOpenBillConfigModal && (
                      <button
                        type="button"
                        onClick={() => {
                          onOpenBillConfigModal();
                          setShowSettingsMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 font-medium"
                      >
                        <Settings className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Configure Bill Model & Template</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        onNavTabChange('item_entry');
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 font-medium"
                    >
                      <Plus className="w-3.5 h-3.5 text-blue-600" />
                      <span>Item Intake Station</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onNavTabChange('billing');
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 font-medium"
                    >
                      <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Bill Generator Station</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onNavTabChange('employees');
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 font-medium"
                    >
                      <Users className="w-3.5 h-3.5 text-purple-600" />
                      <span>Staff & Technician Management</span>
                    </button>

                    <div className="border-t border-slate-100 dark:border-slate-700 my-1" />

                    <button
                      type="button"
                      onClick={() => {
                        onExportData();
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2"
                    >
                      <Download className="w-3.5 h-3.5 text-blue-500" />
                      <span>Export Orders (JSON)</span>
                    </button>

                    <label className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 cursor-pointer">
                      <Upload className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Import Orders (JSON)</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={(e) => {
                          onImportData(e);
                          setShowSettingsMenu(false);
                        }}
                        className="hidden"
                      />
                    </label>

                    <div className="border-t border-slate-100 dark:border-slate-700 my-1" />

                    <button
                      type="button"
                      onClick={() => {
                        onOpenGoogleDriveModal();
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2 font-medium"
                    >
                      <FolderSync className="w-3.5 h-3.5 text-blue-500" />
                      <span>Change Google Drive for Data</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onResetData();
                        setShowSettingsMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-amber-50 dark:hover:bg-amber-950/30 text-amber-600 dark:text-amber-400 flex items-center gap-2"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset to Sample Data</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onOpenSupabaseModal();
                        setShowSettingsMenu(false);
                      }}
                      className="lg:hidden w-full text-left px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-2"
                    >
                      <Database className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Supabase PostgreSQL Schema</span>
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Primary Action Button: + New Work Order */}
            <button
              type="button"
              onClick={onOpenNewOrderModal}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm transition-colors whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">New Work Order</span>
              <span className="sm:hidden">New</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
