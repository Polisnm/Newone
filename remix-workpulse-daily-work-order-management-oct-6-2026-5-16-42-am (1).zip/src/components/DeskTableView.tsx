import React from 'react';
import { 
  Phone, 
  MessageSquare, 
  Printer, 
  Receipt,
  Camera,
  Edit3, 
  ChevronRight, 
  AlertCircle,
  Plus,
  ArrowUpDown
} from 'lucide-react';
import { WorkOrder, WorkOrderStatus } from '../types/workOrder';
import { formatCurrency, getTodayDateStr } from '../services/storage';
import { getStatusBadgeConfig, getPriorityBadge } from './WorkOrderCard';

interface DeskTableViewProps {
  orders: WorkOrder[];
  onEdit: (order: WorkOrder) => void;
  onViewDetails: (order: WorkOrder) => void;
  onPrint: (order: WorkOrder) => void;
  onWhatsApp: (order: WorkOrder) => void;
  onSendBill: (order: WorkOrder) => void;
  onUpdateStatus: (id: string, status: WorkOrderStatus) => void;
  onCreateNew: () => void;
}

export const DeskTableView: React.FC<DeskTableViewProps> = ({
  orders,
  onEdit,
  onViewDetails,
  onPrint,
  onWhatsApp,
  onSendBill,
  onUpdateStatus,
  onCreateNew
}) => {
  const today = getTodayDateStr();

  if (orders.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center shadow-xs">
        <div className="w-12 h-12 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center mb-3">
          <Edit3 className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-1">
          No work orders match current filters
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4">
          Try clearing search filters, selecting a different calendar date, or schedule a new service work order.
        </p>
        <button
          type="button"
          onClick={onCreateNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Create Work Order</span>
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden transition-colors">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              <th className="py-3 px-3.5 whitespace-nowrap">Order ID</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Scheduled / Due</th>
              <th className="py-3 px-3.5">Customer</th>
              <th className="py-3 px-3.5">Device & Serial</th>
              <th className="py-3 px-3.5 min-w-[200px]">Problem Reported</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Status</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Technician</th>
              <th className="py-3 px-3.5 text-right whitespace-nowrap">Balance / Est.</th>
              <th className="py-3 px-3.5 text-center whitespace-nowrap">Quick Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80 text-xs">
            {orders.map((order) => {
              const statusCfg = getStatusBadgeConfig(order.status);
              const isOverdue = order.dueDate < today && order.status !== 'completed' && order.status !== 'delivered' && order.status !== 'cancelled';

              return (
                <tr 
                  key={order.id}
                  className="hover:bg-slate-50/90 dark:hover:bg-slate-800/40 transition-colors group"
                >
                  
                  {/* Order ID & Priority */}
                  <td className="py-3 px-3.5 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onViewDetails(order)}
                        className="font-mono font-bold text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        {order.orderNumber}
                      </button>
                      {getPriorityBadge(order.priority)}
                    </div>
                  </td>

                  {/* Scheduled & Due Date */}
                  <td className="py-3 px-3.5 whitespace-nowrap font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    <div className="text-slate-900 dark:text-slate-100 font-medium">
                      {order.scheduledDate}
                    </div>
                    <div className={`text-[11px] flex items-center gap-1 ${isOverdue ? 'text-rose-600 dark:text-rose-400 font-semibold' : 'text-slate-400 dark:text-slate-500'}`}>
                      {isOverdue && <AlertCircle className="w-3 h-3 shrink-0" />}
                      <span>Due: {order.dueDate}</span>
                    </div>
                  </td>

                  {/* Customer Info */}
                  <td className="py-3 px-3.5">
                    <div className="font-semibold text-slate-900 dark:text-slate-100 truncate max-w-[140px]">
                      {order.customer.name}
                    </div>
                    <a
                      href={`tel:${order.customer.phone}`}
                      className="text-[11px] font-mono text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 inline-flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{order.customer.phone}</span>
                    </a>
                  </td>

                  {/* Device & Serial */}
                  <td className="py-3 px-3.5">
                    <div className="font-medium text-slate-900 dark:text-slate-200 truncate max-w-[160px]" title={`${order.item.brand} ${order.item.model}`}>
                      {order.item.brand} {order.item.model}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400 dark:text-slate-500 font-mono truncate max-w-[160px]">
                      <span className="truncate">S/N: {order.item.serialNumber || 'N/A'}</span>
                      {order.item.images && order.item.images.length > 0 && (
                        <button
                          type="button"
                          onClick={() => onViewDetails(order)}
                          className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 shrink-0"
                          title="View attached service photos"
                        >
                          <Camera className="w-2.5 h-2.5" />
                          <span>{order.item.images.length}</span>
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Problem Reported */}
                  <td className="py-3 px-3.5 text-slate-600 dark:text-slate-300">
                    <p className="line-clamp-2 leading-relaxed" title={order.problemReported}>
                      {order.problemReported}
                    </p>
                    {order.partsRequired && order.status === 'waiting_for_parts' && (
                      <span className="text-[11px] text-purple-600 dark:text-purple-400 block mt-0.5 truncate">
                        Part: {order.partsRequired}
                      </span>
                    )}
                  </td>

                  {/* Status Dropdown */}
                  <td className="py-3 px-3.5 whitespace-nowrap">
                    <select
                      value={order.status}
                      onChange={(e) => onUpdateStatus(order.id, e.target.value as WorkOrderStatus)}
                      className={`text-xs font-semibold px-2 py-1 rounded-full border cursor-pointer focus:outline-hidden focus:ring-1 focus:ring-blue-500 ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="in_progress">In Progress</option>
                      <option value="waiting_for_parts">Waiting Parts</option>
                      <option value="completed">Completed</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>

                  {/* Technician */}
                  <td className="py-3 px-3.5 whitespace-nowrap text-slate-700 dark:text-slate-300 font-medium">
                    {order.assignedTechnician}
                  </td>

                  {/* Financials: Balance & Estimate */}
                  <td className="py-3 px-3.5 text-right whitespace-nowrap font-mono tabular-nums">
                    <div className={`font-bold ${order.balanceDue > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                      {formatCurrency(order.balanceDue)}
                    </div>
                    <div className="text-[11px] text-slate-400 dark:text-slate-500">
                      Total: {formatCurrency(order.estimatedCost)}
                    </div>
                  </td>

                  {/* Quick Actions */}
                  <td className="py-3 px-3.5 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center gap-1">
                      
                      {/* WhatsApp Trigger */}
                      <button
                        type="button"
                        onClick={() => onWhatsApp(order)}
                        title="Send WhatsApp Update"
                        className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-md transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>

                      {/* Send Bill Copy Trigger */}
                      <button
                        type="button"
                        onClick={() => onSendBill(order)}
                        title="Send Bill Copy to Customer"
                        className="p-1.5 text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-md transition-colors"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                      </button>

                      {/* Print Ticket */}
                      <button
                        type="button"
                        onClick={() => onPrint(order)}
                        title="Print Job Sheet / Receipt"
                        className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>

                      {/* Edit */}
                      <button
                        type="button"
                        onClick={() => onEdit(order)}
                        title="Edit Work Order"
                        className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {/* Details Drawer */}
                      <button
                        type="button"
                        onClick={() => onViewDetails(order)}
                        title="Inspect Full Details"
                        className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-md transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>

                    </div>
                  </td>

                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
