import React from 'react';
import { 
  X, 
  Smartphone, 
  Download, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  WifiOff, 
  Camera, 
  Zap 
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose
}) => {
  const { isInstallable, isInstalled, isAndroid, isIOS, install } = usePWAInstall();

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-slate-900/60 backdrop-blur-xs">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 z-10 flex flex-col">
        
        {/* Header with Android Badge */}
        <div className="p-6 text-center border-b border-slate-100 dark:border-slate-800 bg-linear-to-b from-blue-50/80 to-transparent dark:from-blue-950/30">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* App Icon */}
          <div className="w-20 h-20 mx-auto rounded-2xl bg-slate-900 shadow-xl border-2 border-blue-500/30 p-2 flex items-center justify-center mb-3">
            <img 
              src="/pwa-192x192.png" 
              alt="WorkPulse App Icon" 
              className="w-full h-full object-contain rounded-xl"
            />
          </div>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold mb-1">
            <Smartphone className="w-3 h-3" />
            <span>Android PWA / WebAPK Ready</span>
          </div>

          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Install WorkPulse on Android
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Enjoy full-screen standalone performance, camera intake, and instant offline database access
          </p>
        </div>

        {/* Benefits list */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700 dark:text-slate-300">
            <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              <Zap className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Full-screen standalone display without browser address bar</span>
            </div>

            <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              <Camera className="w-4 h-4 text-blue-500 shrink-0" />
              <span>Direct smartphone camera hardware capture for equipment inspection</span>
            </div>

            <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              <WifiOff className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Offline service worker caching for field technician dispatches</span>
            </div>
          </div>

          {/* Android Installation Instructions */}
          {isInstalled ? (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>WorkPulse is already installed and running in standalone app mode!</span>
            </div>
          ) : isInstallable ? (
            <button
              type="button"
              onClick={handleInstallClick}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/20 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Install to Android Home Screen</span>
            </button>
          ) : (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                How to Add to Home Screen in Chrome on Android:
              </span>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-600 dark:text-slate-400 pl-1 leading-relaxed">
                <li>Tap the <strong>three dots (⋮)</strong> menu in the top right of Chrome.</li>
                <li>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                <li>Tap <strong>Install</strong> to add the WorkPulse icon to your Android app drawer.</li>
              </ol>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
