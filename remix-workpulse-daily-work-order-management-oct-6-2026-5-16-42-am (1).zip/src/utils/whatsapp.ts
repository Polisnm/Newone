import { WorkOrder } from '../types/workOrder';

export type WhatsAppTemplateKey = 
  | 'intake_confirmation'
  | 'diagnosis_update'
  | 'waiting_for_parts'
  | 'ready_for_pickup'
  | 'delivered_thank_you'
  | 'bill_invoice_copy';

export interface WhatsAppTemplate {
  key: WhatsAppTemplateKey;
  label: string;
  description: string;
  generateText: (order: WorkOrder, shopName?: string, shopPhone?: string) => string;
}

export const WHATSAPP_TEMPLATES: WhatsAppTemplate[] = [
  {
    key: 'bill_invoice_copy',
    label: 'Official Bill / Invoice Copy',
    description: 'Itemized invoice copy with payment status, breakdown, and warranty',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      const isPaid = order.balanceDue <= 0;
      const invoiceNumber = `INV-${order.orderNumber.replace(/[^0-9]/g, '') || order.orderNumber}`;
      return `🧾 *INVOICE / BILL COPY — ${shopName}*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*Invoice No:* ${invoiceNumber}\n` +
        `*Work Order Ref:* ${order.orderNumber}\n` +
        `*Date:* ${new Date().toLocaleDateString()}\n` +
        `*Customer:* ${order.customer.name}\n` +
        `*Device:* ${order.item.brand} ${order.item.model} (${order.item.itemType})\n` +
        `*Serial No:* ${order.item.serialNumber || 'N/A'}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*SERVICE BREAKDOWN:*\n` +
        `• Problem Solved: ${order.problemReported}\n` +
        (order.partsRequired ? `• Replaced Parts: ${order.partsRequired}\n` : '') +
        `• Technician: ${order.assignedTechnician}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*BILLING SUMMARY:*\n` +
        `Total Estimated / Billed: $${order.estimatedCost.toFixed(2)}\n` +
        `Advance Deposit Received: $${order.advancePaid.toFixed(2)}\n` +
        `*BALANCE PAYABLE:* $${order.balanceDue.toFixed(2)}\n` +
        `*Payment Status:* ${isPaid ? '✅ PAID IN FULL' : '⏳ BALANCE PENDING'}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🛡️ *Warranty Covered:* ${order.warrantyPeriod || '30 Days Service Warranty'}\n` +
        `📍 *Workshop Address:* 104 Industrial Parkway, Workshop Suite 4\n` +
        `📞 *Support Helpline:* +1 (555) 019-9000\n\n` +
        `Thank you for your business! Please retain this bill copy for your warranty records.`;
    }
  },
  {
    key: 'intake_confirmation',
    label: 'Intake Receipt & Ticket',
    description: 'Sent upon registering the work order with ticket number and initial details',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      return `Hello ${order.customer.name}, 👋\n\n` +
        `Thank you for entrusting your device with *${shopName}*!\n\n` +
        `📋 *Work Order ID:* ${order.orderNumber}\n` +
        `💻 *Device:* ${order.item.brand} ${order.item.model} (${order.item.itemType})\n` +
        `⚠️ *Reported Issue:* ${order.problemReported}\n` +
        `📅 *Estimated Due Date:* ${order.dueDate}\n` +
        `💰 *Estimated Cost:* $${order.estimatedCost.toFixed(2)}\n` +
        `💵 *Advance Received:* $${order.advancePaid.toFixed(2)}\n` +
        `⚖️ *Balance Due:* $${order.balanceDue.toFixed(2)}\n\n` +
        `👨‍🔧 *Assigned Technician:* ${order.assignedTechnician}\n\n` +
        `Our team will perform preliminary diagnostics and update you shortly. Reply to this chat if you have any questions!`;
    }
  },
  {
    key: 'diagnosis_update',
    label: 'Diagnosis & Approval',
    description: 'Share diagnostic findings and work progress with the customer',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      return `Hello ${order.customer.name}, 🔧 Update on *${order.orderNumber}*:\n\n` +
        `Our technician *${order.assignedTechnician}* has completed diagnostics on your *${order.item.brand} ${order.item.model}*.\n\n` +
        `🔍 *Diagnosis Findings:*\n${order.preliminaryDiagnosis || 'Diagnostics completed, ready to proceed with repair.'}\n\n` +
        `💰 *Current Estimate:* $${order.estimatedCost.toFixed(2)} (Advance Paid: $${order.advancePaid.toFixed(2)})\n` +
        `⚖️ *Balance Upon Completion:* $${order.balanceDue.toFixed(2)}\n\n` +
        `Please reply *APPROVE* or call us if you'd like to proceed with this repair. Thank you! — *${shopName}*`;
    }
  },
  {
    key: 'waiting_for_parts',
    label: 'Waiting for Parts Notice',
    description: 'Notify customer that replacement components are on order',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      return `Hello ${order.customer.name}, status update for *${order.orderNumber}*:\n\n` +
        `We are currently awaiting specific replacement parts for your *${order.item.brand} ${order.item.model}*.\n` +
        `📦 *Part(s) Needed:* ${order.partsRequired || 'Specialized replacement module'}\n\n` +
        `We expect the component to arrive soon, after which your repair will be prioritized. We appreciate your patience!\n` +
        `— *${shopName}*`;
    }
  },
  {
    key: 'ready_for_pickup',
    label: 'Ready for Pickup / Delivery',
    description: 'Alert the customer that repair is finished and ready for collection',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      return `🎉 Great news ${order.customer.name}!\n\n` +
        `Your *${order.item.brand} ${order.item.model}* (${order.orderNumber}) is *COMPLETED* and has passed all quality checks!\n\n` +
        `📍 *Pickup Location:* 104 Industrial Parkway, Workshop Suite 4\n` +
        `🕒 *Hours:* Mon - Sat, 9:00 AM - 7:00 PM\n` +
        `⚖️ *Balance Payable:* $${order.balanceDue.toFixed(2)}\n` +
        `🛡️ *Warranty:* ${order.warrantyPeriod || '30 Days Service Warranty'}\n\n` +
        `Please present this message or your Job Ticket ID upon arrival. See you soon!\n— *${shopName}*`;
    }
  },
  {
    key: 'delivered_thank_you',
    label: 'Handover & Warranty Record',
    description: 'Thank the customer after successful handover with warranty details',
    generateText: (order, shopName = 'WorkPulse Tech Care') => {
      return `Hello ${order.customer.name}, thank you for choosing *${shopName}*!\n\n` +
        `Your device *${order.item.brand} ${order.item.model}* (${order.orderNumber}) has been delivered.\n` +
        `🛡️ *Warranty Period:* ${order.warrantyPeriod || '30 Days'}\n\n` +
        `If you need anything else or experience any unexpected behavior, simply reply to this message. We hope to see you again! ⭐`;
    }
  }
];

export function cleanPhoneNumber(phone: string): string {
  // Remove non-numeric characters except leading +
  return phone.replace(/[^0-9]/g, '');
}

export function generateWhatsAppUrl(phone: string, message: string): string {
  const cleaned = cleanPhoneNumber(phone);
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${cleaned}?text=${encoded}`;
}

export function openWhatsAppChat(phone: string, message: string): void {
  const url = generateWhatsAppUrl(phone, message);
  window.open(url, '_blank', 'noopener,noreferrer');
}
