import { WorkOrder } from '../types/workOrder';
import { formatCurrency, formatDateDisplay } from '../services/storage';
import { cleanPhoneNumber, generateWhatsAppUrl } from './whatsapp';

export interface BillOptions {
  invoiceNumber: string;
  invoiceDate: string;
  paymentMethod: 'Cash' | 'Credit/Debit Card' | 'Bank Transfer / Wire' | 'Online / UPI' | 'Pending';
  taxPercent: number; // e.g., 0% or 8%
  discount: number;
  notes?: string;
  shopName: string;
  shopAddress: string;
  shopPhone: string;
  shopEmail: string;
}

export const DEFAULT_BILL_OPTIONS: Omit<BillOptions, 'invoiceNumber' | 'invoiceDate'> = {
  paymentMethod: 'Credit/Debit Card',
  taxPercent: 0,
  discount: 0,
  notes: 'Thank you for choosing WorkPulse Tech Care! Warranty valid with this invoice.',
  shopName: 'WorkPulse Tech Care',
  shopAddress: '104 Industrial Parkway, Workshop Suite 4',
  shopPhone: '+1 (555) 019-9000',
  shopEmail: 'billing@workpulse-ops.com'
};

export function getInvoiceNumber(order: WorkOrder): string {
  const digits = order.orderNumber.replace(/[^0-9]/g, '');
  return `INV-${digits || '1001'}`;
}

export function generateItemizedBillText(order: WorkOrder, options: BillOptions): string {
  const subtotal = order.estimatedCost;
  const taxAmount = (subtotal * options.taxPercent) / 100;
  const grandTotal = Math.max(0, subtotal + taxAmount - options.discount);
  const balanceDue = Math.max(0, grandTotal - order.advancePaid);
  const isPaid = balanceDue <= 0;

  return `========================================
TAX INVOICE / BILL COPY
${options.shopName}
${options.shopAddress}
Phone: ${options.shopPhone} | Email: ${options.shopEmail}
========================================
Invoice No:    ${options.invoiceNumber}
Date:          ${options.invoiceDate}
Work Order ID: ${order.orderNumber}
Payment State: ${isPaid ? '[PAID IN FULL]' : '[BALANCE PENDING]'}
Payment Mode:  ${options.paymentMethod}

BILLED TO:
Customer:      ${order.customer.name}
Phone:         ${order.customer.phone}
Address:       ${order.customer.address}

EQUIPMENT DETAILS:
Item / Device: ${order.item.brand} ${order.item.model} (${order.item.itemType})
Serial Number: ${order.item.serialNumber || 'N/A'}
Diagnosis:     ${order.preliminaryDiagnosis || order.problemReported}
Technician:    ${order.assignedTechnician}

ITEMIZED CHARGES:
1. Labor & Bench Service:           $${(subtotal * 0.6).toFixed(2)}
2. Hardware / Replaced Parts:       $${(subtotal * 0.4).toFixed(2)}
${order.partsRequired ? `   (Parts: ${order.partsRequired})\n` : ''}----------------------------------------
Subtotal:                           ${formatCurrency(subtotal)}
${options.taxPercent > 0 ? `Tax (${options.taxPercent}%):                        +${formatCurrency(taxAmount)}\n` : ''}${options.discount > 0 ? `Discount:                           -${formatCurrency(options.discount)}\n` : ''}Total Billed Amount:                ${formatCurrency(grandTotal)}
Advance Deposit Paid:              -${formatCurrency(order.advancePaid)}
========================================
BALANCE DUE UPON COLLECTION:        ${formatCurrency(balanceDue)}
========================================
Warranty Period: ${order.warrantyPeriod || '30 Days Service Warranty'}

Notes: ${options.notes || 'Please retain this bill copy for warranty claims.'}
========================================`;
}

export function generateEmailBillLink(order: WorkOrder, billText: string, options: BillOptions): string {
  const subject = encodeURIComponent(`Bill Copy & Receipt for ${order.item.brand} ${order.item.model} (${options.invoiceNumber})`);
  const body = encodeURIComponent(billText);
  const recipient = order.customer.email || '';
  return `mailto:${recipient}?subject=${subject}&body=${body}`;
}

export function generateSmsBillLink(order: WorkOrder, options: BillOptions): string {
  const phone = cleanPhoneNumber(order.customer.phone);
  const balanceDue = Math.max(0, order.estimatedCost - order.advancePaid);
  const text = encodeURIComponent(
    `Hello ${order.customer.name}, your bill copy for ${order.item.brand} ${order.item.model} (${options.invoiceNumber}) is ready. Total: $${order.estimatedCost.toFixed(2)}, Advance Paid: $${order.advancePaid.toFixed(2)}, Balance Due: $${balanceDue.toFixed(2)}. ${options.shopName}`
  );
  return `sms:${phone}?body=${text}`;
}
