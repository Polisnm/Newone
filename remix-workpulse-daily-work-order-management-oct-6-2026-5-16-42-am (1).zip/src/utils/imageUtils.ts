import { ItemImage } from '../types/workOrder';

/**
 * Compresses an image file client-side via canvas before converting to base64.
 * Keeps storage light and responsive.
 */
export async function compressAndReadImage(
  file: File, 
  maxWidth: number = 960, 
  maxHeight: number = 720, 
  quality: number = 0.78
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / maxWidth > height / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedBase64);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Creates high-fidelity SVG data URLs representing realistic workshop equipment photos
 */
export function createWorkshopSampleImageSvg(
  label: string, 
  subtext: string, 
  bgColor: string = '#1e293b', 
  accentColor: string = '#3b82f6'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
    <rect width="600" height="400" fill="${bgColor}"/>
    <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
      <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>
    </pattern>
    <rect width="600" height="400" fill="url(#grid)"/>
    <circle cx="300" cy="180" r="70" fill="none" stroke="${accentColor}" stroke-width="3" stroke-dasharray="6,6"/>
    <circle cx="300" cy="180" r="50" fill="${accentColor}" fill-opacity="0.15"/>
    <path d="M 280 180 L 320 180 M 300 160 L 300 200" stroke="${accentColor}" stroke-width="2.5" stroke-linecap="round"/>
    <text x="300" y="290" font-family="system-ui, -apple-system, sans-serif" font-size="18" font-weight="bold" fill="#ffffff" text-anchor="middle">${label}</text>
    <text x="300" y="320" font-family="system-ui, -apple-system, sans-serif" font-size="13" fill="#94a3b8" text-anchor="middle">${subtext}</text>
    <rect x="20" y="20" width="100" height="24" rx="4" fill="#0f172a" fill-opacity="0.8"/>
    <text x="70" y="36" font-family="monospace" font-size="11" fill="#38bdf8" text-anchor="middle">WORKSHOP</text>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export const SAMPLE_EQUIPMENT_IMAGES: Record<string, ItemImage[]> = {
  'wo-001': [
    {
      id: 'img-001-a',
      url: createWorkshopSampleImageSvg('Logic Board Corrosion Under Microscope', 'C8410 Backlight Rail Capacitor', '#0f172a', '#38bdf8'),
      caption: 'Microscope photo of liquid corrosion on C8410 capacitor rail',
      stage: 'intake',
      createdAt: new Date(Date.now() - 3600000 * 7).toISOString()
    },
    {
      id: 'img-001-b',
      url: createWorkshopSampleImageSvg('Post-Ultrasonic Clean & Micro-soldering', 'Replaced Q8400 MOSFET', '#022c22', '#10b981'),
      caption: 'Bench test after ultrasonic cleaning and backlight rail replacement',
      stage: 'repair',
      createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
    }
  ],
  'wo-002': [
    {
      id: 'img-002-a',
      url: createWorkshopSampleImageSvg('Swollen Dell Battery Pack', '86Wh Battery Cell Separation', '#451a03', '#f59e0b'),
      caption: 'Physical battery pack swollen causing trackpad displacement',
      stage: 'intake',
      createdAt: new Date(Date.now() - 3600000 * 16).toISOString()
    }
  ],
  'wo-004': [
    {
      id: 'img-004-a',
      url: createWorkshopSampleImageSvg('iPhone 14 Pro Cracked OLED Intake', 'Top-Right Impact Fractures', '#1e1b4b', '#818cf8'),
      caption: 'Intake photo showing glass fractures across display assembly',
      stage: 'intake',
      createdAt: new Date(Date.now() - 3600000 * 22).toISOString()
    },
    {
      id: 'img-004-b',
      url: createWorkshopSampleImageSvg('Screen Calibrated with TrueTone EEPROM', 'Display Diagnostic Passed 100%', '#064e3b', '#34d399'),
      caption: 'New Super Retina XDR installed and TrueTone verified',
      stage: 'completed',
      createdAt: new Date(Date.now() - 3600000 * 3).toISOString()
    }
  ]
};
