export const SUPABASE_SQL_SCHEMA = `-- =========================================================================
-- WORKPULSE DAILY WORK ORDER MANAGEMENT SCHEMA (SUPABASE / POSTGRESQL)
-- =========================================================================

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. ENUMS FOR STATUS & PRIORITY
CREATE TYPE work_order_status AS ENUM (
  'pending',
  'in_progress',
  'waiting_for_parts',
  'completed',
  'delivered',
  'cancelled'
);

CREATE TYPE priority_level AS ENUM (
  'low',
  'normal',
  'high',
  'urgent'
);

-- 2. TECHNICIANS TABLE
CREATE TABLE IF NOT EXISTS technicians (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT,
  specialty TEXT,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. WORK ORDERS TABLE
CREATE TABLE IF NOT EXISTS work_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number TEXT UNIQUE NOT NULL, -- e.g. WO-1001
  scheduled_date DATE NOT NULL,
  due_date DATE NOT NULL,
  status work_order_status NOT NULL DEFAULT 'pending',
  priority priority_level NOT NULL DEFAULT 'normal',
  
  -- Customer Information
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_alt_phone TEXT,
  customer_email TEXT,
  customer_address TEXT NOT NULL,
  
  -- Item / Asset Details
  item_type TEXT NOT NULL,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  serial_number TEXT NOT NULL,
  passcode_or_pattern TEXT,
  accessories_included JSONB DEFAULT '[]'::jsonb,
  cosmetic_condition TEXT,
  
  -- Diagnostics & Technician Assignment
  problem_reported TEXT NOT NULL,
  preliminary_diagnosis TEXT DEFAULT '',
  technician_notes TEXT DEFAULT '',
  assigned_technician TEXT NOT NULL,
  technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL,
  parts_required TEXT,
  warranty_period TEXT DEFAULT '30 Days Service Warranty',
  
  -- Financials
  estimated_cost NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  advance_paid NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  balance_due NUMERIC(10, 2) GENERATED ALWAYS AS (estimated_cost - advance_paid) STORED,
  
  -- Timestamps
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. WORK ORDER ACTIVITY AUDIT LOG
CREATE TABLE IF NOT EXISTS work_order_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID REFERENCES work_orders(id) ON DELETE CASCADE,
  status work_order_status NOT NULL,
  note TEXT,
  author TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_work_orders_scheduled_date ON work_orders(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_assigned_technician ON work_orders(assigned_technician);
CREATE INDEX IF NOT EXISTS idx_work_orders_order_number ON work_orders(order_number);
CREATE INDEX IF NOT EXISTS idx_work_orders_customer_phone ON work_orders(customer_phone);

-- 6. AUTOMATIC UPDATED_AT TRIGGER
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_work_orders_updated_at ON work_orders;
CREATE TRIGGER trigger_work_orders_updated_at
  BEFORE UPDATE ON work_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- 7. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE work_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE technicians ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_order_logs ENABLE ROW LEVEL SECURITY;

-- Allow authenticated workshop staff full access:
CREATE POLICY "Authenticated workshop staff full access"
  ON work_orders
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- 8. SAMPLE TECHNICIANS INSERTION
INSERT INTO technicians (name, email, phone, specialty) VALUES
  ('Alex Rivera', 'alex@workshop.internal', '+1-555-0192', 'Laptops & Logic Board Microsoldering'),
  ('David Chen', 'david@workshop.internal', '+1-555-0144', 'Motherboards, GPUs & Custom Desktops'),
  ('Sarah Jenkins', 'sarah@workshop.internal', '+1-555-0188', 'Smartphones, Tablets & Screen Refurbishing'),
  ('Marcus Vance', 'marcus@workshop.internal', '+1-555-0173', 'Laser Printers & Network Systems')
ON CONFLICT (email) DO NOTHING;
`;
