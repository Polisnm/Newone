/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { WorkOrder, WorkOrderStatus, PriorityLevel, ViewMode, GoogleDriveSettings, ItemImage } from './types/workOrder';
import { 
  StorageService, 
  getTodayDateStr, 
  formatCurrency, 
  formatDateDisplay 
} from './services/storage';
import { Header } from './components/Header';
import { DailyCalendarNav } from './components/DailyCalendarNav';
import { SearchAndFilterBar } from './components/SearchAndFilterBar';
import { DeskTableView } from './components/DeskTableView';
import { KanbanBoardView } from './components/KanbanBoardView';
import { MobileFieldView } from './components/MobileFieldView';
import { WorkOrderModal } from './components/WorkOrderModal';
import { WorkOrderDetailModal } from './components/WorkOrderDetailModal';
import { PrintJobSheetModal } from './components/PrintJobSheetModal';
import { WhatsAppModal } from './components/WhatsAppModal';
import { SendBillModal } from './components/SendBillModal';
import { SupabaseSchemaModal } from './components/SupabaseSchemaModal';
import { GoogleDriveSettingsModal } from './components/GoogleDriveSettingsModal';
import { 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  Wrench, 
  AlertCircle,
  FileSpreadsheet
} from 'lucide-react';

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('workpulse_theme') === 'dark' ||
      (!('workpulse_theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  // Apply dark mode class to <html>
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('workpulse_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('workpulse_theme', 'light');
    }
  }, [darkMode]);

  // Main data state
  const [orders, setOrders] = useState<WorkOrder[]>(() => StorageService.getWorkOrders());
  const [technicians, setTechnicians] = useState<string[]>(() => StorageService.getTechnicians());

  // Google Drive state
  const [googleDriveSettings, setGoogleDriveSettings] = useState<GoogleDriveSettings>(() => StorageService.getGoogleDriveSettings());
  const [isGoogleDriveModalOpen, setIsGoogleDriveModalOpen] = useState(false);

  // Navigation & Date state
  const [activeNavTab, setActiveNavTab] = useState<'daily' | 'all'>('daily');
  const [selectedDate, setSelectedDate] = useState<string>(() => getTodayDateStr());
  const [viewMode, setViewMode] = useState<ViewMode>('table');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<WorkOrderStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<PriorityLevel | 'all'>('all');
  const [technicianFilter, setTechnicianFilter] = useState<string>('all');

  // Modals state
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderToEdit, setOrderToEdit] = useState<WorkOrder | null>(null);
  const [inspectingOrder, setInspectingOrder] = useState<WorkOrder | null>(null);
  const [printingOrder, setPrintingOrder] = useState<WorkOrder | null>(null);
  const [whatsAppOrder, setWhatsAppOrder] = useState<WorkOrder | null>(null);
  const [sendBillOrder, setSendBillOrder] = useState<WorkOrder | null>(null);
  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);

  // Status notification toast banner
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Compute daily status breakdown for the selected calendar date
  const dailyCounts = useMemo(() => {
    const dayOrders = orders.filter(o => o.scheduledDate === selectedDate);
    const today = getTodayDateStr();

    const counts = {
      total: dayOrders.length,
      pending: 0,
      in_progress: 0,
      waiting_for_parts: 0,
      completed: 0,
      delivered: 0,
      cancelled: 0,
      overdue: 0
    };

    dayOrders.forEach(o => {
      if (counts[o.status] !== undefined) {
        counts[o.status]++;
      }
      if (o.dueDate < today && o.status !== 'completed' && o.status !== 'delivered' && o.status !== 'cancelled') {
        counts.overdue++;
      }
    });

    return counts;
  }, [orders, selectedDate]);

  // Overall Financial Metrics across all orders
  const overallMetrics = useMemo(() => {
    let totalEst = 0;
    let totalAdvance = 0;
    let totalBalance = 0;
    let activeRepairs = 0;

    orders.forEach(o => {
      totalEst += o.estimatedCost || 0;
      totalAdvance += o.advancePaid || 0;
      totalBalance += o.balanceDue || 0;
      if (o.status === 'in_progress' || o.status === 'pending' || o.status === 'waiting_for_parts') {
        activeRepairs++;
      }
    });

    return { totalEst, totalAdvance, totalBalance, activeRepairs };
  }, [orders]);

  // Filtered orders list
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      // 1. Date filter (if in daily mode)
      if (activeNavTab === 'daily' && order.scheduledDate !== selectedDate) {
        return false;
      }

      // 2. Status filter
      if (statusFilter !== 'all' && order.status !== statusFilter) {
        return false;
      }

      // 3. Priority filter
      if (priorityFilter !== 'all' && order.priority !== priorityFilter) {
        return false;
      }

      // 4. Technician filter
      if (technicianFilter !== 'all' && order.assignedTechnician !== technicianFilter) {
        return false;
      }

      // 5. Search query (matches Customer, Phone, Device, Model, Serial, Order Number)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const customerMatch = order.customer.name.toLowerCase().includes(q) ||
          order.customer.phone.toLowerCase().includes(q) ||
          (order.customer.altPhone && order.customer.altPhone.toLowerCase().includes(q)) ||
          order.customer.address.toLowerCase().includes(q);
        const itemMatch = order.item.brand.toLowerCase().includes(q) ||
          order.item.model.toLowerCase().includes(q) ||
          order.item.itemType.toLowerCase().includes(q) ||
          (order.item.serialNumber && order.item.serialNumber.toLowerCase().includes(q));
        const orderMatch = order.orderNumber.toLowerCase().includes(q) ||
          order.problemReported.toLowerCase().includes(q) ||
          (order.assignedTechnician && order.assignedTechnician.toLowerCase().includes(q));

        if (!customerMatch && !itemMatch && !orderMatch) {
          return false;
        }
      }

      return true;
    });
  }, [orders, activeNavTab, selectedDate, statusFilter, priorityFilter, technicianFilter, searchQuery]);

  // Actions
  const handleSaveOrder = (savedOrder: WorkOrder) => {
    const updated = StorageService.saveWorkOrder(savedOrder);
    setOrders(StorageService.getWorkOrders());
    showToast(`Work order ${updated.orderNumber} saved successfully.`);
  };

  const handleUpdateStatus = (id: string, newStatus: WorkOrderStatus, note?: string) => {
    const updated = StorageService.updateOrderStatus(id, newStatus, note, 'Technician Desk');
    if (updated) {
      setOrders(StorageService.getWorkOrders());
      showToast(`Status for ${updated.orderNumber} changed to "${newStatus.replace(/_/g, ' ')}".`);
      // Update inspectingOrder if open
      if (inspectingOrder && inspectingOrder.id === id) {
        setInspectingOrder(updated);
      }
    }
  };

  const handleDeleteOrder = (id: string) => {
    const deleted = StorageService.deleteWorkOrder(id);
    if (deleted) {
      setOrders(StorageService.getWorkOrders());
      showToast('Work order removed.');
    }
  };

  const handleOpenNewOrder = () => {
    setOrderToEdit(null);
    setIsOrderModalOpen(true);
  };

  const handleOpenEditOrder = (order: WorkOrder) => {
    setOrderToEdit(order);
    setIsOrderModalOpen(true);
  };

  const handleResetData = () => {
    if (confirm('Reset all work orders to initial sample data?')) {
      const seeded = StorageService.resetToSampleData();
      setOrders(seeded);
      showToast('Restored sample work orders for today.');
    }
  };

  const handleExportJSON = () => {
    const jsonStr = StorageService.exportToJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workpulse-orders-${getTodayDateStr()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Orders exported to JSON.');
  };

  const handleExportCSV = () => {
    const csvStr = StorageService.exportToCSV();
    const blob = new Blob([csvStr], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workpulse-ledger-${getTodayDateStr()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Orders exported to CSV.');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = StorageService.importFromJSON(content);
      if (res.success) {
        setOrders(StorageService.getWorkOrders());
        showToast(`Successfully imported ${res.count} work orders!`);
      } else {
        alert(`Import error: ${res.error}`);
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset input
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      
      {/* Top Bar Header */}
      <Header
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onOpenNewOrderModal={handleOpenNewOrder}
        onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)}
        onOpenGoogleDriveModal={() => setIsGoogleDriveModalOpen(true)}
        googleDriveFolderName={googleDriveSettings.folderName}
        onExportData={handleExportJSON}
        onImportData={handleImportJSON}
        onResetData={handleResetData}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        activeNavTab={activeNavTab}
        onNavTabChange={setActiveNavTab}
        totalOrdersCount={orders.length}
      />

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white dark:bg-white dark:text-slate-900 px-4 py-2.5 rounded-xl shadow-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 dark:border-slate-200 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* If in Daily Schedule mode: Show Daily Calendar Nav */}
        {activeNavTab === 'daily' ? (
          <DailyCalendarNav
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
            dailyCounts={dailyCounts}
            activeStatusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
          />
        ) : (
          /* All Orders Metrics Overview Banner */
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm mb-6 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800 gap-2">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  All Workshop Work Orders
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Global repository of active, pending, and completed service tickets
                </p>
              </div>

              {/* Quick CSV Export */}
              <button
                type="button"
                onClick={handleExportCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors self-start sm:self-auto"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>Export Ledger CSV</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-xs text-slate-500 block mb-0.5">Total Orders</span>
                <span className="text-lg font-bold font-mono text-slate-900 dark:text-white tabular-nums">
                  {orders.length}
                </span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-xs text-slate-500 block mb-0.5">Active In-Bench</span>
                <span className="text-lg font-bold font-mono text-blue-600 dark:text-blue-400 tabular-nums">
                  {overallMetrics.activeRepairs}
                </span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-xs text-slate-500 block mb-0.5">Total Estimates</span>
                <span className="text-lg font-bold font-mono text-slate-800 dark:text-slate-200 tabular-nums">
                  {formatCurrency(overallMetrics.totalEst)}
                </span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-xs text-slate-500 block mb-0.5">Outstanding Balance</span>
                <span className="text-lg font-bold font-mono text-amber-600 dark:text-amber-400 tabular-nums">
                  {formatCurrency(overallMetrics.totalBalance)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Live Search and Filters Bar */}
        <SearchAndFilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          priorityFilter={priorityFilter}
          onPriorityFilterChange={setPriorityFilter}
          technicianFilter={technicianFilter}
          onTechnicianFilterChange={setTechnicianFilter}
          techniciansList={technicians}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          filteredCount={filteredOrders.length}
          totalCount={activeNavTab === 'daily' ? dailyCounts.total : orders.length}
        />

        {/* Dynamic Views: Desk Table / Pipeline Kanban / Mobile Field View */}
        {viewMode === 'table' && (
          <DeskTableView
            orders={filteredOrders}
            onEdit={handleOpenEditOrder}
            onViewDetails={(o) => setInspectingOrder(o)}
            onPrint={(o) => setPrintingOrder(o)}
            onWhatsApp={(o) => setWhatsAppOrder(o)}
            onSendBill={(o) => setSendBillOrder(o)}
            onUpdateStatus={handleUpdateStatus}
            onCreateNew={handleOpenNewOrder}
          />
        )}

        {viewMode === 'kanban' && (
          <KanbanBoardView
            orders={filteredOrders}
            onEdit={handleOpenEditOrder}
            onViewDetails={(o) => setInspectingOrder(o)}
            onPrint={(o) => setPrintingOrder(o)}
            onWhatsApp={(o) => setWhatsAppOrder(o)}
            onSendBill={(o) => setSendBillOrder(o)}
            onUpdateStatus={handleUpdateStatus}
            onCreateNew={handleOpenNewOrder}
          />
        )}

        {viewMode === 'mobile_field' && (
          <MobileFieldView
            orders={filteredOrders}
            onEdit={handleOpenEditOrder}
            onViewDetails={(o) => setInspectingOrder(o)}
            onPrint={(o) => setPrintingOrder(o)}
            onWhatsApp={(o) => setWhatsAppOrder(o)}
            onSendBill={(o) => setSendBillOrder(o)}
            onUpdateStatus={handleUpdateStatus}
            onCreateNew={handleOpenNewOrder}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="no-print mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-4 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <div>
            WorkPulse Daily Work Order Management & Dispatch System
          </div>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setIsGoogleDriveModalOpen(true)}
              className="hover:text-blue-600 transition-colors flex items-center gap-1 font-medium"
              title="Change Google Drive for data"
            >
              <span>Drive: {googleDriveSettings.folderName.length > 22 ? googleDriveSettings.folderName.slice(0, 22) + '...' : googleDriveSettings.folderName}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsSupabaseModalOpen(true)}
              className="hover:text-blue-600 transition-colors"
            >
              Supabase SQL
            </button>
            <button
              type="button"
              onClick={handleExportCSV}
              className="hover:text-blue-600 transition-colors"
            >
              Export CSV
            </button>
            <button
              type="button"
              onClick={handleResetData}
              className="hover:text-amber-600 transition-colors"
            >
              Reset Data
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}

      {/* 1. Create / Edit Work Order Modal */}
      <WorkOrderModal
        isOpen={isOrderModalOpen}
        onClose={() => {
          setIsOrderModalOpen(false);
          setOrderToEdit(null);
        }}
        onSave={handleSaveOrder}
        orderToEdit={orderToEdit}
        techniciansList={technicians}
        defaultScheduledDate={selectedDate}
        googleDriveSettings={googleDriveSettings}
        onOpenGoogleDriveSettings={() => setIsGoogleDriveModalOpen(true)}
      />

      {/* 2. Detailed Inspector & Activity Audit Modal */}
      <WorkOrderDetailModal
        isOpen={Boolean(inspectingOrder)}
        onClose={() => setInspectingOrder(null)}
        order={inspectingOrder}
        onEdit={(o) => {
          setInspectingOrder(null);
          handleOpenEditOrder(o);
        }}
        onPrint={(o) => {
          setPrintingOrder(o);
        }}
        onWhatsApp={(o) => {
          setWhatsAppOrder(o);
        }}
        onSendBill={(o) => {
          setSendBillOrder(o);
        }}
        onUpdateStatus={handleUpdateStatus}
        onDelete={handleDeleteOrder}
        googleDriveSettings={googleDriveSettings}
        onOpenGoogleDriveSettings={() => setIsGoogleDriveModalOpen(true)}
      />

      {/* 3. Printable Job Sheet / Receipt Modal */}
      <PrintJobSheetModal
        isOpen={Boolean(printingOrder)}
        onClose={() => setPrintingOrder(null)}
        order={printingOrder}
        onOpenSendBill={(o) => setSendBillOrder(o)}
      />

      {/* 4. Quick WhatsApp Messenger Modal */}
      <WhatsAppModal
        isOpen={Boolean(whatsAppOrder)}
        onClose={() => setWhatsAppOrder(null)}
        order={whatsAppOrder}
      />

      {/* 5. Send Bill Copy Modal (WhatsApp, Email, SMS, Print) */}
      <SendBillModal
        isOpen={Boolean(sendBillOrder)}
        onClose={() => setSendBillOrder(null)}
        order={sendBillOrder}
        onOpenPrintInvoice={(o) => setPrintingOrder(o)}
      />

      {/* 6. Supabase Production PostgreSQL Schema Modal */}
      <SupabaseSchemaModal
        isOpen={isSupabaseModalOpen}
        onClose={() => setIsSupabaseModalOpen(false)}
      />

      {/* 7. Google Drive Configuration & Change Modal */}
      <GoogleDriveSettingsModal
        isOpen={isGoogleDriveModalOpen}
        onClose={() => setIsGoogleDriveModalOpen(false)}
        settings={googleDriveSettings}
        onSaveSettings={(newSettings) => {
          setGoogleDriveSettings(newSettings);
          StorageService.saveGoogleDriveSettings(newSettings);
          showToast(`Google Drive updated to "${newSettings.folderName}".`);
        }}
        orders={orders}
        onImportDriveBackup={(importedOrders) => {
          StorageService.saveAllWorkOrders(importedOrders);
          setOrders(importedOrders);
          showToast(`Restored ${importedOrders.length} work orders from Google Drive backup package.`);
        }}
      />

    </div>
  );
}
