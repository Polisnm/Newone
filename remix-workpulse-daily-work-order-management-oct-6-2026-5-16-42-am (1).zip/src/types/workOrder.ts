export type WorkOrderStatus = 
  | 'pending'
  | 'in_progress'
  | 'waiting_for_parts'
  | 'completed'
  | 'delivered'
  | 'cancelled';

export type PriorityLevel = 'low' | 'normal' | 'high' | 'urgent';

export type ItemType = 
  | 'Laptop'
  | 'Desktop PC'
  | 'Motherboard / Logic Board'
  | 'Smartphone'
  | 'Tablet'
  | 'Printer / Scanner'
  | 'Audio / Console'
  | 'Network Equipment'
  | 'Other Equipment';

export interface CustomerDetails {
  name: string;
  phone: string;
  altPhone?: string;
  email?: string;
  address: string;
}

export interface ItemImage {
  id: string;
  url: string; // Base64 data URL or external URL
  caption: string;
  stage: 'intake' | 'diagnosis' | 'repair' | 'completed';
  createdAt: string;
}

export interface ItemDetails {
  itemType: ItemType;
  brand: string;
  model: string;
  serialNumber: string;
  passcodeOrPattern?: string;
  accessoriesIncluded: string[]; // e.g. ["Power Adapter", "Laptop Bag", "Original Box"]
  cosmeticCondition?: string; // e.g. "Screen minor scratches, dent on bottom left chassis"
  images?: ItemImage[];
}

export interface StatusHistoryEntry {
  status: WorkOrderStatus;
  timestamp: string; // ISO
  note: string;
  updatedBy: string;
}

export interface WorkOrder {
  id: string;
  orderNumber: string; // e.g., 'WO-1001'
  scheduledDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  createdAt: string; // ISO
  updatedAt: string; // ISO
  completedAt?: string;
  status: WorkOrderStatus;
  priority: PriorityLevel;
  customer: CustomerDetails;
  item: ItemDetails;
  problemReported: string;
  preliminaryDiagnosis: string;
  technicianNotes: string;
  assignedTechnician: string;
  estimatedCost: number;
  advancePaid: number;
  balanceDue: number; // estimatedCost - advancePaid
  partsRequired?: string;
  warrantyPeriod?: string; // e.g. "30 Days Warranty on Labor"
  statusHistory?: StatusHistoryEntry[];
}

export interface DailyStatusCounts {
  total: number;
  pending: number;
  in_progress: number;
  waiting_for_parts: number;
  completed: number;
  delivered: number;
  cancelled: number;
  overdue: number;
}

export type ViewMode = 'table' | 'kanban' | 'mobile_field';

export type NavTab = 'daily' | 'all' | 'item_entry' | 'billing' | 'employees';

export interface Employee {
  id: string;
  name: string;
  role: 'Senior Technician' | 'Hardware Specialist' | 'Board-level Micro-solderer' | 'Software & OS Tech' | 'Front Desk Intake' | 'Workshop Manager';
  phone: string;
  email: string;
  specialties: string[];
  status: 'active' | 'on_leave' | 'inactive';
  hourlyRate?: number;
  joinedDate?: string;
  avatarColor?: string;
}

export interface BillLineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface BillModelConfig {
  shopName: string;
  tagline: string;
  taxRegistrationNumber: string; // GST / VAT / Tax ID / EIN
  phone: string;
  email: string;
  website?: string;
  address: string;
  invoicePrefix: string; // e.g. "INV-"
  currencySymbol: string; // e.g. "$", "₹", "€", "£"
  currencyCode: string; // e.g. "USD", "INR", "EUR", "GBP"
  taxRatePercent: number; // e.g. 18 or 10 or 0
  isTaxEnabled: boolean;
  taxLabel: string; // e.g. "GST", "Sales Tax", "VAT"
  termsAndConditions: string;
  warrantyDisclaimer: string;
  bankDetailsOrUPI?: string;
  footerNotes?: string;
  layoutTheme: 'modern' | 'classic' | 'thermal';
  showSignatureBlock: boolean;
  showBarcode: boolean;
}

export interface SavedGoogleDrive {
  id: string;
  name: string;
  url: string;
  folderId?: string;
  description?: string;
}

export interface GoogleDriveSettings {
  folderUrl: string;
  folderName: string;
  folderId?: string;
  lastSyncedAt?: string;
  autoSyncOnSave: boolean;
  syncStatus: 'linked' | 'unlinked' | 'syncing';
  savedDrives?: SavedGoogleDrive[];
}

