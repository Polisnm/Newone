import { 
  WorkOrder, 
  WorkOrderStatus, 
  DailyStatusCounts, 
  GoogleDriveSettings, 
  SavedGoogleDrive,
  Employee,
  BillModelConfig
} from '../types/workOrder';
import { SAMPLE_EQUIPMENT_IMAGES } from '../utils/imageUtils';

const STORAGE_KEY = 'workpulse_work_orders_v1';
const TECH_STORAGE_KEY = 'workpulse_technicians_v1';
const EMPLOYEE_STORAGE_KEY = 'workpulse_employees_v1';
const BILL_CONFIG_STORAGE_KEY = 'workpulse_bill_config_v1';

export const DEFAULT_EMPLOYEES: Employee[] = [
  {
    id: 'emp-1',
    name: 'Alex Rivera',
    role: 'Senior Technician',
    phone: '+1 (555) 301-8819',
    email: 'alex.rivera@workpulse-ops.com',
    specialties: ['Apple MacBook Logic Boards', 'Ultrasonic Cleaning', 'Liquid Damage Repair'],
    status: 'active',
    hourlyRate: 48,
    joinedDate: '2023-01-15',
    avatarColor: 'bg-blue-600'
  },
  {
    id: 'emp-2',
    name: 'David Chen',
    role: 'Board-level Micro-solderer',
    phone: '+1 (555) 301-8822',
    email: 'david.chen@workpulse-ops.com',
    specialties: ['BGA Rework', 'SMD Microsoldering', 'Power Rail Diagnostics'],
    status: 'active',
    hourlyRate: 55,
    joinedDate: '2022-08-10',
    avatarColor: 'bg-emerald-600'
  },
  {
    id: 'emp-3',
    name: 'Sarah Jenkins',
    role: 'Hardware Specialist',
    phone: '+1 (555) 301-8835',
    email: 'sarah.jenkins@workpulse-ops.com',
    specialties: ['Display & Digitizer Replacement', 'Gaming Laptops', 'Hinges & Chassis'],
    status: 'active',
    hourlyRate: 42,
    joinedDate: '2023-06-01',
    avatarColor: 'bg-purple-600'
  },
  {
    id: 'emp-4',
    name: 'Marcus Vance',
    role: 'Software & OS Tech',
    phone: '+1 (555) 301-8840',
    email: 'marcus.vance@workpulse-ops.com',
    specialties: ['Data Recovery', 'Firmware Flashing', 'OS Optimization & Security'],
    status: 'active',
    hourlyRate: 40,
    joinedDate: '2024-02-18',
    avatarColor: 'bg-amber-600'
  },
  {
    id: 'emp-5',
    name: 'Elena Rostova',
    role: 'Workshop Manager',
    phone: '+1 (555) 301-8855',
    email: 'elena.rostova@workpulse-ops.com',
    specialties: ['Dispatch & Bench QC', 'Inventory Parts', 'Customer Billing & Intake'],
    status: 'active',
    hourlyRate: 52,
    joinedDate: '2021-11-05',
    avatarColor: 'bg-rose-600'
  }
];

export const DEFAULT_BILL_MODEL_CONFIG: BillModelConfig = {
  shopName: 'WorkPulse Workshop & Tech Care',
  tagline: 'Precision Hardware Diagnostics, Micro-soldering & Field Dispatch',
  taxRegistrationNumber: 'TAX-REG-8921-US4',
  phone: '+1 (555) 019-9000',
  email: 'billing@workpulse-ops.com',
  website: 'https://workpulse-ops.com',
  address: '104 Industrial Parkway, Workshop Suite 4, San Jose, CA 95112',
  invoicePrefix: 'INV-',
  currencySymbol: '$',
  currencyCode: 'USD',
  taxRatePercent: 8,
  isTaxEnabled: true,
  taxLabel: 'Sales Tax (8%)',
  termsAndConditions: 'All hardware repairs carry 30 to 90 days warranty on replacement parts and labor. Liquid damage board repairs carry 30 days limited warranty. Devices left unclaimed after 45 days of completion may incur storage charges.',
  warrantyDisclaimer: 'Warranty void if warranty seal is tampered with or device incurs physical drop / liquid exposure after service.',
  bankDetailsOrUPI: 'Wire / Zelle / Bank: Chase Tech Business · Acct #9842-1102 · Routing #121000358',
  footerNotes: 'Thank you for your business! For status inquiries, call or WhatsApp +1 (555) 019-9000 with your invoice or work order ID.',
  layoutTheme: 'modern',
  showSignatureBlock: true,
  showBarcode: true
};

export const DEFAULT_TECHNICIANS = [
  'Alex Rivera',
  'David Chen',
  'Sarah Jenkins',
  'Marcus Vance',
  'Elena Rostova'
];

export const ACCESSORY_PRESETS = [
  'Original Charger / Power Adapter',
  'Power Cord',
  'Laptop Carrying Bag / Sleeve',
  'Original Box & Foam',
  'Stylus / Pen',
  'USB Dongle / Adapter',
  'SIM Tray / MicroSD Card',
  'Keyboard & Mouse',
  'Display Cable (HDMI/DP)'
];

function getRelativeDateStr(offsetDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
}

export function getTodayDateStr(): string {
  return new Date().toISOString().split('T')[0];
}

export function formatDateDisplay(dateStr: string): string {
  if (!dateStr) return '';
  try {
    const [year, month, day] = dateStr.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  } catch {
    return dateStr;
  }
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(amount || 0);
}

const INITIAL_SAMPLE_ORDERS: WorkOrder[] = [
  {
    id: 'wo-001',
    orderNumber: 'WO-1001',
    scheduledDate: getRelativeDateStr(0), // Today
    dueDate: getRelativeDateStr(1),
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'in_progress',
    priority: 'urgent',
    customer: {
      name: 'Robert Hastings',
      phone: '+1 555-234-8901',
      altPhone: '+1 555-234-8902',
      email: 'robert.h@apexlogistics.com',
      address: '742 Evergreen Terrace, Suite 300'
    },
    item: {
      itemType: 'Laptop',
      brand: 'Apple',
      model: 'MacBook Pro 16" (M2 Max)',
      serialNumber: 'C02G99XZMD6R',
      accessoriesIncluded: ['Original 140W USB-C Charger', 'Protective Sleeve'],
      cosmeticCondition: 'Minor hairline scratches on top lid, keyboard immaculate.',
      images: SAMPLE_EQUIPMENT_IMAGES['wo-001']
    },
    problemReported: 'Accidental coffee spill on right side of keyboard 2 days ago. Device powers on but displays black screen with chime, cooling fans run at 100%.',
    preliminaryDiagnosis: 'Board-level inspection confirmed corrosion on backlight rail capacitor array C8410. Ultrasonic bath and microsoldering replacement needed.',
    technicianNotes: 'Ultrasound cleaning completed. Currently replacing backlight MOSFET Q8400. Need to test panel output.',
    assignedTechnician: 'Alex Rivera',
    estimatedCost: 320.00,
    advancePaid: 100.00,
    balanceDue: 220.00,
    warrantyPeriod: '60 Days Warranty on Board Repair',
    statusHistory: [
      {
        status: 'pending',
        timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        note: 'Intake completed, device booked for liquid damage inspection.',
        updatedBy: 'Front Desk'
      },
      {
        status: 'in_progress',
        timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
        note: 'Disassembled logic board. Ultrasonic cleaning executed.',
        updatedBy: 'Alex Rivera'
      }
    ]
  },
  {
    id: 'wo-002',
    orderNumber: 'WO-1002',
    scheduledDate: getRelativeDateStr(0), // Today
    dueDate: getRelativeDateStr(2),
    createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    status: 'waiting_for_parts',
    priority: 'high',
    customer: {
      name: 'Samantha Vance',
      phone: '+1 555-891-4562',
      altPhone: '+1 555-891-4500',
      email: 'svance@horizonlabs.io',
      address: '1440 Mission Bay Blvd, Apt 4B'
    },
    item: {
      itemType: 'Laptop',
      brand: 'Dell',
      model: 'XPS 15 9520',
      serialNumber: '8FK91M3',
      accessoriesIncluded: ['130W Type-C AC Adapter'],
      cosmeticCondition: 'Rubber feet missing on bottom chassis; otherwise clean.',
      images: SAMPLE_EQUIPMENT_IMAGES['wo-002']
    },
    problemReported: 'Internal battery swollen; trackpad is physically pushed up and hard to click. Rapid battery discharge (under 30 mins).',
    preliminaryDiagnosis: 'Severe battery cell degradation and swelling. Trackpad mechanism undamaged but requires immediate 86Wh replacement cell.',
    technicianNotes: 'Ordered original OEM Dell 86Wh battery module (Part # 5XJ28). Expected arrival tomorrow noon.',
    assignedTechnician: 'David Chen',
    estimatedCost: 185.00,
    advancePaid: 85.00,
    balanceDue: 100.00,
    partsRequired: 'OEM Dell 86Wh Battery Module #5XJ28',
    warrantyPeriod: '90 Days on OEM Battery',
    statusHistory: [
      {
        status: 'pending',
        timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
        note: 'Intake logged. Warned customer not to charge swollen pack.',
        updatedBy: 'Front Desk'
      },
      {
        status: 'waiting_for_parts',
        timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
        note: 'Old battery safely decoupled and stored in fireproof container. Awaiting part delivery.',
        updatedBy: 'David Chen'
      }
    ]
  },
  {
    id: 'wo-003',
    orderNumber: 'WO-1003',
    scheduledDate: getRelativeDateStr(0), // Today
    dueDate: getRelativeDateStr(0),
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    status: 'pending',
    priority: 'normal',
    customer: {
      name: 'Dr. Michael Ortiz',
      phone: '+1 555-312-7788',
      email: 'm.ortiz@healthgroup.org',
      address: '220 University Ave, Clinical Wing'
    },
    item: {
      itemType: 'Desktop PC',
      brand: 'Custom Build',
      model: 'AMD Ryzen 9 7900X / RTX 4080 Rig',
      serialNumber: 'CB-2024-8812',
      accessoriesIncluded: ['Power Cord'],
      cosmeticCondition: 'Tempered glass side panel clean, slight dust inside intake filters.'
    },
    problemReported: 'Random blue-screen kernel panic crashes under heavy rendering loads. Fans surge repeatedly before shutoff.',
    preliminaryDiagnosis: 'Suspected AIO liquid cooler pump failure or dried thermal paste causing thermal throttling > 95°C.',
    technicianNotes: 'Pending bench mounting for Cinebench + HWMonitor stress logging.',
    assignedTechnician: 'David Chen',
    estimatedCost: 120.00,
    advancePaid: 50.00,
    balanceDue: 70.00,
    warrantyPeriod: '30 Days Service Warranty'
  },
  {
    id: 'wo-004',
    orderNumber: 'WO-1004',
    scheduledDate: getRelativeDateStr(0), // Today
    dueDate: getRelativeDateStr(0),
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    completedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'completed',
    priority: 'normal',
    customer: {
      name: 'Clara Oswald',
      phone: '+1 555-720-9941',
      altPhone: '+1 555-720-9900',
      email: 'clara.design@studio.net',
      address: '88 Art District Way, Loft 12'
    },
    item: {
      itemType: 'Smartphone',
      brand: 'Apple',
      model: 'iPhone 14 Pro 256GB',
      serialNumber: 'F2LZX19VNQ',
      accessoriesIncluded: ['Original Box'],
      cosmeticCondition: 'Front glass shattered across top right notch.',
      images: SAMPLE_EQUIPMENT_IMAGES['wo-004']
    },
    problemReported: 'Screen dropped on tile floor. Touch digitizer unresponsive in upper quadrant; camera face ID still functions.',
    preliminaryDiagnosis: 'OLED front display assembly replacement needed with TrueTone programming.',
    technicianNotes: 'Replaced with OEM-spec Super Retina XDR OLED assembly. TrueTone EEPROM calibrated. Tested Face ID, speaker, proximity sensor - 100% operational.',
    assignedTechnician: 'Sarah Jenkins',
    estimatedCost: 260.00,
    advancePaid: 260.00,
    balanceDue: 0.00,
    warrantyPeriod: '90 Days Screen Replacement Warranty'
  },
  {
    id: 'wo-005',
    orderNumber: 'WO-1005',
    scheduledDate: getRelativeDateStr(0), // Today
    dueDate: getRelativeDateStr(0),
    createdAt: new Date(Date.now() - 3600000 * 30).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    completedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    status: 'delivered',
    priority: 'low',
    customer: {
      name: 'Arthur Pendelton',
      phone: '+1 555-443-1289',
      address: '512 Oakridge Lane'
    },
    item: {
      itemType: 'Printer / Scanner',
      brand: 'HP',
      model: 'LaserJet Pro M404dn',
      serialNumber: 'VNB3B09881',
      accessoriesIncluded: ['Power Cable', 'USB Cable'],
      cosmeticCondition: 'Good condition'
    },
    problemReported: 'Tray 2 multi-sheet pickup jams and paper accordion crinkle.',
    preliminaryDiagnosis: 'Worn pickup roller and separation pad rubber glazing.',
    technicianNotes: 'Replaced pickup roller assembly (RM2-5399) and separation pad. Cleaned feed sensors. Printed 50-page duplex test run with zero jams.',
    assignedTechnician: 'Marcus Vance',
    estimatedCost: 95.00,
    advancePaid: 95.00,
    balanceDue: 0.00,
    warrantyPeriod: '30 Days'
  },
  {
    id: 'wo-006',
    orderNumber: 'WO-1006',
    scheduledDate: getRelativeDateStr(-1), // Yesterday
    dueDate: getRelativeDateStr(-1),
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 20).toISOString(),
    completedAt: new Date(Date.now() - 3600000 * 20).toISOString(),
    status: 'completed',
    priority: 'normal',
    customer: {
      name: 'Liam Neeson',
      phone: '+1 555-908-1122',
      address: '300 River Road'
    },
    item: {
      itemType: 'Motherboard / Logic Board',
      brand: 'ASUS',
      model: 'ROG Strix B650E-F Gaming WiFi',
      serialNumber: 'M9M0CS01294',
      accessoriesIncluded: ['I/O Shield', 'SATA Cables'],
      cosmeticCondition: 'Clean, no burnt traces'
    },
    problemReported: 'Bricked BIOS after power surge during automated Windows firmware update. Q-LED stuck on yellow (DRAM).',
    preliminaryDiagnosis: 'Corrupted SPI Flash chip firmware EEPROM.',
    technicianNotes: 'Reprogrammed flash chip via CH341A external programmer with latest stable AGESA microcode. System booted into BIOS immediately.',
    assignedTechnician: 'David Chen',
    estimatedCost: 110.00,
    advancePaid: 50.00,
    balanceDue: 60.00,
    warrantyPeriod: '30 Days'
  },
  {
    id: 'wo-007',
    orderNumber: 'WO-1007',
    scheduledDate: getRelativeDateStr(1), // Tomorrow
    dueDate: getRelativeDateStr(2),
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    status: 'pending',
    priority: 'urgent',
    customer: {
      name: 'Evelyn Reed',
      phone: '+1 555-667-3490',
      email: 'e.reed@archstudio.com',
      address: '900 Financial Tower, 18th Floor'
    },
    item: {
      itemType: 'Laptop',
      brand: 'Lenovo',
      model: 'ThinkPad P1 Gen 5 Workstation',
      serialNumber: 'PF49A288',
      accessoriesIncluded: ['170W Slim Tip Charger'],
      cosmeticCondition: 'Clean condition'
    },
    problemReported: 'Entire top row of keyboard keys (Esc through F12) not registering. Touchpad works fine.',
    preliminaryDiagnosis: 'Suspected keyboard ribbon cable loose or damaged internal trace.',
    technicianNotes: 'Scheduled for tomorrow morning intake queue.',
    assignedTechnician: 'Alex Rivera',
    estimatedCost: 145.00,
    advancePaid: 0.00,
    balanceDue: 145.00,
    warrantyPeriod: '60 Days'
  }
];

export const StorageService = {
  getWorkOrders(): WorkOrder[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        this.saveAllWorkOrders(INITIAL_SAMPLE_ORDERS);
        return INITIAL_SAMPLE_ORDERS;
      }
      const parsed: WorkOrder[] = JSON.parse(stored);
      return parsed;
    } catch (err) {
      console.error('Failed reading work orders from localStorage:', err);
      return INITIAL_SAMPLE_ORDERS;
    }
  },

  saveAllWorkOrders(orders: WorkOrder[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
    } catch (err) {
      console.error('Failed saving work orders to localStorage:', err);
    }
  },

  getWorkOrderById(id: string): WorkOrder | undefined {
    const orders = this.getWorkOrders();
    return orders.find(o => o.id === id);
  },

  saveWorkOrder(order: WorkOrder): WorkOrder {
    const orders = this.getWorkOrders();
    const existingIndex = orders.findIndex(o => o.id === order.id);

    // Compute balance due
    const balanceDue = Math.max(0, (order.estimatedCost || 0) - (order.advancePaid || 0));
    const updatedOrder: WorkOrder = {
      ...order,
      balanceDue,
      updatedAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      orders[existingIndex] = updatedOrder;
    } else {
      orders.unshift(updatedOrder);
    }

    this.saveAllWorkOrders(orders);
    return updatedOrder;
  },

  deleteWorkOrder(id: string): boolean {
    const orders = this.getWorkOrders();
    const filtered = orders.filter(o => o.id !== id);
    if (filtered.length !== orders.length) {
      this.saveAllWorkOrders(filtered);
      return true;
    }
    return false;
  },

  updateOrderStatus(
    id: string, 
    newStatus: WorkOrderStatus, 
    note?: string, 
    author: string = 'Technician'
  ): WorkOrder | null {
    const orders = this.getWorkOrders();
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return null;

    const current = orders[index];
    const historyEntry = {
      status: newStatus,
      timestamp: new Date().toISOString(),
      note: note || `Status updated from ${current.status} to ${newStatus}`,
      updatedBy: author
    };

    const updated: WorkOrder = {
      ...current,
      status: newStatus,
      updatedAt: new Date().toISOString(),
      completedAt: newStatus === 'completed' || newStatus === 'delivered' 
        ? current.completedAt || new Date().toISOString() 
        : current.completedAt,
      statusHistory: [...(current.statusHistory || []), historyEntry]
    };

    orders[index] = updated;
    this.saveAllWorkOrders(orders);
    return updated;
  },

  getNextOrderNumber(): string {
    const orders = this.getWorkOrders();
    let maxNumber = 1000;
    orders.forEach(o => {
      const match = o.orderNumber.match(/WO-(\d+)/i);
      if (match && match[1]) {
        const num = parseInt(match[1], 10);
        if (num > maxNumber) maxNumber = num;
      }
    });
    return `WO-${maxNumber + 1}`;
  },

  getDailyStats(dateStr: string): DailyStatusCounts {
    const orders = this.getWorkOrders();
    const dayOrders = orders.filter(o => o.scheduledDate === dateStr);

    const counts: DailyStatusCounts = {
      total: dayOrders.length,
      pending: 0,
      in_progress: 0,
      waiting_for_parts: 0,
      completed: 0,
      delivered: 0,
      cancelled: 0,
      overdue: 0
    };

    dayOrders.forEach(o => {
      if (counts[o.status] !== undefined) {
        counts[o.status]++;
      }
      // Check overdue if due date < today and not completed or delivered
      const today = getTodayDateStr();
      if (o.dueDate < today && o.status !== 'completed' && o.status !== 'delivered' && o.status !== 'cancelled') {
        counts.overdue++;
      }
    });

    return counts;
  },

  getTechnicians(): string[] {
    try {
      const emps = this.getEmployees();
      if (emps && emps.length > 0) {
        return emps.filter(e => e.status === 'active').map(e => e.name);
      }
      const stored = localStorage.getItem(TECH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // fallback
    }
    return DEFAULT_TECHNICIANS;
  },

  saveTechnicians(techs: string[]): void {
    localStorage.setItem(TECH_STORAGE_KEY, JSON.stringify(techs));
  },

  getEmployees(): Employee[] {
    try {
      const stored = localStorage.getItem(EMPLOYEE_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    // Seed default employees
    this.saveEmployees(DEFAULT_EMPLOYEES);
    return DEFAULT_EMPLOYEES;
  },

  saveEmployees(employees: Employee[]): void {
    localStorage.setItem(EMPLOYEE_STORAGE_KEY, JSON.stringify(employees));
    // Keep technicians list in sync
    const activeNames = employees.filter(e => e.status === 'active').map(e => e.name);
    localStorage.setItem(TECH_STORAGE_KEY, JSON.stringify(activeNames));
  },

  saveEmployee(employee: Employee): Employee[] {
    const employees = this.getEmployees();
    const idx = employees.findIndex(e => e.id === employee.id);
    let updated: Employee[];
    if (idx >= 0) {
      updated = [...employees];
      updated[idx] = employee;
    } else {
      updated = [...employees, employee];
    }
    this.saveEmployees(updated);
    return updated;
  },

  deleteEmployee(id: string): Employee[] {
    const employees = this.getEmployees();
    const updated = employees.filter(e => e.id !== id);
    this.saveEmployees(updated);
    return updated;
  },

  getBillModelConfig(): BillModelConfig {
    try {
      const stored = localStorage.getItem(BILL_CONFIG_STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_BILL_MODEL_CONFIG, ...JSON.parse(stored) };
      }
    } catch {
      // fallback
    }
    return DEFAULT_BILL_MODEL_CONFIG;
  },

  saveBillModelConfig(config: BillModelConfig): void {
    localStorage.setItem(BILL_CONFIG_STORAGE_KEY, JSON.stringify(config));
  },

  resetToSampleData(): WorkOrder[] {
    this.saveAllWorkOrders(INITIAL_SAMPLE_ORDERS);
    return INITIAL_SAMPLE_ORDERS;
  },

  exportToJSON(): string {
    const orders = this.getWorkOrders();
    return JSON.stringify(orders, null, 2);
  },

  exportToCSV(): string {
    const orders = this.getWorkOrders();
    const headers = [
      'Order Number',
      'Scheduled Date',
      'Due Date',
      'Status',
      'Priority',
      'Customer Name',
      'Customer Phone',
      'Item Type',
      'Brand',
      'Model',
      'Serial Number',
      'Problem Reported',
      'Assigned Technician',
      'Estimated Cost',
      'Advance Paid',
      'Balance Due'
    ];

    const rows = orders.map(o => [
      o.orderNumber,
      o.scheduledDate,
      o.dueDate,
      o.status,
      o.priority,
      `"${(o.customer.name || '').replace(/"/g, '""')}"`,
      `"${(o.customer.phone || '').replace(/"/g, '""')}"`,
      `"${(o.item.itemType || '').replace(/"/g, '""')}"`,
      `"${(o.item.brand || '').replace(/"/g, '""')}"`,
      `"${(o.item.model || '').replace(/"/g, '""')}"`,
      `"${(o.item.serialNumber || '').replace(/"/g, '""')}"`,
      `"${(o.problemReported || '').replace(/"/g, '""')}"`,
      `"${(o.assignedTechnician || '').replace(/"/g, '""')}"`,
      o.estimatedCost.toFixed(2),
      o.advancePaid.toFixed(2),
      o.balanceDue.toFixed(2)
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  },

  importFromJSON(jsonString: string): { success: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!Array.isArray(parsed)) {
        return { success: false, count: 0, error: 'JSON content must be an array of work orders.' };
      }
      this.saveAllWorkOrders(parsed);
      return { success: true, count: parsed.length };
    } catch (err: any) {
      return { success: false, count: 0, error: err.message || 'Invalid JSON format.' };
    }
  },

  getGoogleDriveSettings(): GoogleDriveSettings {
    const defaultSavedDrives: SavedGoogleDrive[] = [
      {
        id: 'drive-main',
        name: 'Main Workshop Master Drive',
        url: 'https://drive.google.com/drive/folders/1BxiMVs0XRA5nFMdKvBHK-workpulse-workshop',
        folderId: '1BxiMVs0XRA5nFMdKvBHK-workpulse-workshop',
        description: 'Primary workshop bench service records and intake photos'
      },
      {
        id: 'drive-field',
        name: 'Field Operations Shared Drive',
        url: 'https://drive.google.com/drive/folders/1-WorkPulse-FieldOps-Mobile',
        folderId: '1-WorkPulse-FieldOps-Mobile',
        description: 'Mobile technician field repairs and onsite inspection photos'
      },
      {
        id: 'drive-archive',
        name: 'Warranty & Archive Storage Drive',
        url: 'https://drive.google.com/drive/folders/1-WorkPulse-Warranty-Archives',
        folderId: '1-WorkPulse-Warranty-Archives',
        description: 'Long-term storage for delivered orders and customer receipts'
      }
    ];

    const defaultSettings: GoogleDriveSettings = {
      folderUrl: 'https://drive.google.com/drive/folders/1BxiMVs0XRA5nFMdKvBHK-workpulse-workshop',
      folderName: 'WorkPulse Workshop Database & Service Images',
      folderId: '1BxiMVs0XRA5nFMdKvBHK-workpulse-workshop',
      lastSyncedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
      autoSyncOnSave: true,
      syncStatus: 'linked',
      savedDrives: defaultSavedDrives
    };

    try {
      const stored = localStorage.getItem('workpulse_gdrive_settings_v1');
      if (stored) {
        const parsed = JSON.parse(stored);
        return { 
          ...defaultSettings, 
          ...parsed,
          savedDrives: parsed.savedDrives && parsed.savedDrives.length > 0 ? parsed.savedDrives : defaultSavedDrives
        };
      }
    } catch {
      // fallback
    }
    return defaultSettings;
  },

  saveGoogleDriveSettings(settings: GoogleDriveSettings): void {
    localStorage.setItem('workpulse_gdrive_settings_v1', JSON.stringify(settings));
  }
};
